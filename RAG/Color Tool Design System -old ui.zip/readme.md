# Color Tool — Design System

**Perceptual color & tonality analysis for artists.** Color Tool is a local-first desktop app (Tauri 2 + Svelte 5 + Rust) that helps painters, colorists, and designers see how an image is built: k-means clustering in OKLab/OKLch, polar hue×chroma charts, cluster histograms, value/notan studies, video frame analysis, batch palettes, and rich exports (PNG/SVG/CSV/.ase/JSON).

This design system captures the app's **current redesign direction**: the original Figma concept ("Colors Tool.fig") sketched a cream, paper-like UI with hand-annotated style notes; the shipped app simplified it, and the team is now working the redesign back in. Treat the codebase tokens + the revised sidebar design as the source of truth, with the .fig as the component inventory.

## Sources

- **Figma**: `Colors Tool.fig` (attached, mounted read-only). One page with 5 frames: Header, Style-Guide (annotated moodboard — scrollbar rules, tab order, "Canonical black = 262626"), UI-Walkthrough (state machine of the original concept: upload → loading → analysis → export, error states), Image, Video. Defines 14 component families (11 icon sets + Slider + Tooltip + Plain Tooltip) and 2 standalone symbols (Image, Video), plus 46 Figma variables (mostly inherited from the "Simple Design System" community library).
- **Codebase**: `color-tool-kmeans/` (attached, read-only) — `tauri-app/src` is the shipped UI: `app.css` (shell), `lib/styles/tokens.css` (semantic tokens, Figma snapshot 2025-09-21), `lib/styles/inputs.css` (range slider), views (`HomeView`, `ValuesView`, `BatchView`, `ExportsView`, `SettingsView`), components (`MediaBucket`, `ContextMenu`, `ZoomOverlay`).
- **Design docs**: `color-tool-kmeans/RAG/` — `global-conventions.md` (binding conventions), `INDEX.md` (EPIC/IMP tracker), `assets/revised-sidebar-design.png` (the current redesign target: window shell, Colors view with polar chart / histogram / hue×lightness, Active Folder + Active Images rails).
- GitHub: https://github.com/animegolem/color-tool-kmeans (public releases).

## Content fundamentals

- **Voice**: terse, instrumental, artist-facing. UI copy is short noun phrases ("Cluster Histogram", "Range finder", "Simplified tones") or short imperatives ("Drop anywhere", "Add media", "Clear pins").
- **Casing**: Title Case for view names and card headings ("Polar Chart", "Hue × Lightness"); sentence case for helper text ("Top clusters by frequency", "This may take a moment", "Select media to view the values analysis.").
- **Person**: no "I"/"we"; the app speaks to the user only implicitly. Errors are factual and calm: "Values analysis failed.", "Please Quit or Reload", "Is the disk full?".
- **Technical honesty**: real units and jargon are embraced, not hidden — "Color merge threshold (ΔE OKLab)", "51 ms · 40 iterations · 170,500 samples", "OKLCH / OKHSV / HSV".
- **Emoji**: none in UI copy. Two unicode glyphs appear as icons (📌 pin, ○ unpinned, × remove, ↓ download, + add).
- **Format lists** are compact and · - separated: "PNG, JPEG, WebP, BMP, GIF, TIFF, MP4" / "PNG · JPEG · WebP".

## Visual foundations

- **Canvas**: warm cream page (`#F5EFE1`) with white panels/cards. Never pure-white pages. Ink is the "canonical black" `#262626` (per Style Guide annotation), not `#000`.
- **Accent**: warm brown `#866051` (active nav pill, segmented-control active state, primary buttons, pinned markers); deeper `#824C32` shows up in the original ribbon/upload motifs and dropzone washes (`rgba(130,76,50,0.06–0.12)`).
- **Cards**: white, radius 12px, soft shadow `0 2px 6px rgba(0,0,0,0.12)`, generous 16–20px padding. Sub-sections inside views use faint ink washes instead: `rgba(33,33,32,0.03–0.04)` fills, 1px `rgba(33,33,32,0.12)` borders, radius 14px.
- **Borders**: hairlines are ink at low alpha (`rgba(33,33,32,0.16)`), not gray hexes. Strong outlines are 1px `#262626` (Figma frames used inset box-shadows for crisp 1px edges).
- **Segmented controls**: pill group on `rgba(33,33,32,0.08)`, radius 999px, active segment = accent bg + white text, inactive = 70% ink.
- **Sliders**: two families. The app's range input: bare 5px line + 22px ring thumb, no track chrome, darkens 25% on hover (color-mix). The Figma capsule slider (Slider component): frosted gray capsule with inset shadows, white translucent fill, heights 12/16/28/44.
- **Scrollbars**: "Simple, minimum chrome. Dark grey black. Never render a track, just a bare slider." — 10px, `#2b2b2b` thumb, radius 6, transparent track.
- **Focus**: visible and rectangular — `outline: 2–3px solid` accent (or `--focus` blue `#2a5adf` on form controls), 2–4px offset. Style Guide: "keyboard movement/focus highlight is a simple even bounded box eg 4px".
- **Hover**: washes, not color shifts — icon buttons get `rgba(33,33,32,0.06)` bg + opacity 0.6→1; outline buttons invert to accent bg + white text; media tiles get ink borders.
- **Motion**: quiet fades and slides only. 0.15–0.2s ease for hover/panel transitions, 120ms fade for overlays, 900ms linear spin for the loader. No bounces. Throbbers spin; error states may "shake — a quick 'no'" (aspirational, from the walkthrough).
- **Overlays**: full-window scrims are light (`rgba(217,217,217,0.4)`), panels are translucent cream (`rgba(245,239,225,0.8)`) with 1px `#3a3737` border, radius 10. Narrow-mode sidebar backdrop is dark (`rgba(26,24,22,0.35)`).
- **Layout**: fixed 44px header, 200px left nav, 200px right library rail; content column max 1120px (Home) / 980px (Values). Grid-based, `gap` everywhere.
- **Imagery**: the user's own art is the imagery. Previews get radius 8–12px, 1px ink border, deep soft shadow (`0 12px 20px rgba(33,33,32,0.12)`). No decorative stock imagery, no gradients except literal data gradients (value ramp black→cream).
- **Charts**: rendered as SVG on white cards; serif axis labels inside chart SVGs; cluster dots at exact pixel colors.

## Iconography

- **App icons**: inline stroked SVGs, `currentColor`, round caps/joins — sidebar toggles (16px, filled panel glyphs), media badges (`media-image.svg`, `media-video.svg`, stroke 3–3.5). Copied to `assets/icons/app/`.
- **Figma icon set**: 12 Feather-style stroke families × 6 sizes (16/20/24/32/40/48): Check, Chevron up, Copy, Download, File text, Image, Loader, Sun, X, X circle, X square. Materialized as one data file + `Icon` wrapper (`components/icons/`). Stroke scales with size; paint via `currentColor`.
- **Unicode-as-icon**: sparing — 📌 (pinned), ○ (unpinned), × (remove), ↓ (download), + (add). This is the only emoji usage in the product.
- **Eyedropper**: a small raster PNG (`assets/icons/app/eyedropper.png`) in the original concept.
- No icon font. No CDN icon set required.

## Logo

The sources define **no logo or wordmark**. Render "Color Tool" in plain type (Fira Sans) wherever a mark would go. Do not invent one.

## Typography

- **Fira Sans** (400/500/700) — all UI text. Body 16px, small 14px, captions 11–12px, h1 24px, card h2 15–18px.
- **Fira Code** (400/500/700) — reserved for "select vertical labels only" (per global-conventions) — e.g. the vertical tab ribbons in the original concept; occasional code-ish accents.
- Fonts are vendored (never CDN) — binaries in `assets/fonts/`, declared in `tokens/fonts.css`.
- The .fig also shows Inter/Roboto/SF Pro (library components) and Gloria Hallelujah (annotation handwriting only — never product UI).

## Components

Built 1:1 from the .fig inventory (nothing invented):

- Icons (`components/icons/`): `Icon` (name-keyed wrapper) plus one component per Figma family — `Check`, `ChevronUp`, `Copy`, `Download`, `FileText`, `Image`, `Loader`, `Sun`, `X`, `XCircle`, `XSquare` — each rendering its 6 authored sizes (16/20/24/32/40/48) from `icon-data.js`.
- `Slider` (alias `SliderDefault`) (`components/controls/`) — interactive port of "Slider - Default" (80 variants: size mini/sm/regular/lg × value × state).
- `Tooltip` (`components/feedback/`) — bordered white tooltip, 4 placements (Top/Bottom/Left/Right).
- `PlainTooltip` (`components/feedback/`) — dark Material-style tooltip, single/multi line.
- `MediaImage`, `MediaVideo` (`components/media/`) — the standalone Image/Video media symbols (renamed from "Image"/"Video" to avoid clashing with the Image icon family).

**Intentional additions**: `Icon` wrapper (one component for 12 icon families — per icon-set convention); `MediaImage`/`MediaVideo` renames. No other additions.

**Figma family coverage — 14 of 14**: `Check`, `Chevron up`, `Copy`, `Download`, `File text`, `Image`, `Loader`, `Sun`, `X`, `X circle`, `X square` → **Icon** (icon-data, all 6 sizes each); `Slider - Default` → **Slider**; `Tooltip` → **Tooltip**; `Plain Tooltip` → **PlainTooltip**. The 11 icon families are deliberately shipped as one `Icon` component + data file rather than 11 separate `.jsx` files.

## UI kit

- `ui_kits/color-tool/` — the shipped desktop app, recreated from the Svelte source: shell (nav / header / library rail), Colors view (image + polar chart + cluster histogram + hue×lightness + parameters), Values view (neutral pair, range finder, simplified tones), Exports view (builder sections), drop-anywhere empty state. Interactive click-through in `index.html`.

## Index

- `styles.css` — global entry (imports everything under `tokens/`)
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`, `base.css`, plus generated `fig-tokens.css` / `fig-typography.css` (Figma variables; mostly SDS-library inherited — prefer the app tokens)
- `components/` — `icons/`, `controls/`, `feedback/`, `media/` (each with card HTML + prompt.md)
- `ui_kits/color-tool/` — app recreation
- `guidelines/` — foundation specimen cards (colors, type, spacing, motifs)
- `assets/` — `fonts/`, `icons/app/`, `media/` (placeholder glyphs), `sample/` (reference artwork from the .fig), `reference/` (revised sidebar design PNG)
- `SKILL.md` — agent skill entry point

## Caveats

- `tokens/fig-tokens.css` carries the .fig's variable collections verbatim, including many theme modes inherited from the "Simple Design System" community library (schemes-inverse-*, Flow Circular wireframe font, etc.). They are kept for fidelity; the app's real tokens live in `tokens/colors.css` et al.
- Figma text styles: the file defines none (0), so typography derives from the codebase.
- The .fig's "Slider - Default"/"Tooltip" families are library kit components (SF Pro/Inter/Roboto); values are ported exactly, faces fall back to system stacks unless those fonts are added.
