/* @ds-bundle: {"format":4,"namespace":"ColorToolDesignSystem_73584b","components":[{"name":"Slider","sourcePath":"components/controls/Slider.jsx"},{"name":"SliderDefault","sourcePath":"components/controls/Slider.jsx"},{"name":"PlainTooltip","sourcePath":"components/feedback/PlainTooltip.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Check","sourcePath":"components/icons/Check.jsx"},{"name":"ChevronUp","sourcePath":"components/icons/ChevronUp.jsx"},{"name":"Copy","sourcePath":"components/icons/Copy.jsx"},{"name":"Download","sourcePath":"components/icons/Download.jsx"},{"name":"FileText","sourcePath":"components/icons/FileText.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"Image","sourcePath":"components/icons/Image.jsx"},{"name":"Loader","sourcePath":"components/icons/Loader.jsx"},{"name":"Sun","sourcePath":"components/icons/Sun.jsx"},{"name":"X","sourcePath":"components/icons/X.jsx"},{"name":"XCircle","sourcePath":"components/icons/XCircle.jsx"},{"name":"XSquare","sourcePath":"components/icons/XSquare.jsx"},{"name":"MediaImage","sourcePath":"components/media/MediaImage.jsx"},{"name":"MediaVideo","sourcePath":"components/media/MediaVideo.jsx"}],"sourceHashes":{"components/controls/Slider.jsx":"57cf9b59afed","components/feedback/PlainTooltip.jsx":"05f8771e47f9","components/feedback/Tooltip.jsx":"a1fae921a86c","components/icons/Check.jsx":"e7370f85e0a4","components/icons/ChevronUp.jsx":"71e58cefa03c","components/icons/Copy.jsx":"ffa0eb98ebf9","components/icons/Download.jsx":"f4f049a9d7d6","components/icons/FileText.jsx":"e3d34adb6b75","components/icons/Icon.jsx":"b81dfc2559d3","components/icons/Image.jsx":"699327ed43ef","components/icons/Loader.jsx":"32e210e87281","components/icons/Sun.jsx":"b4bd03d3ed1c","components/icons/X.jsx":"37968fb8a380","components/icons/XCircle.jsx":"fc71b0237ed4","components/icons/XSquare.jsx":"7c73b9eb504c","components/icons/icon-data.js":"97658d8ffbe7","components/media/MediaImage.jsx":"716af31377fc","components/media/MediaVideo.jsx":"40f0799f4dea","ui_kits/color-tool/AppShell.jsx":"15a4821bc080","ui_kits/color-tool/ColorsView.jsx":"9ad922f5ef5a","ui_kits/color-tool/ExportsView.jsx":"2d5a96f4bbb1","ui_kits/color-tool/KitBits.jsx":"538292cf1937","ui_kits/color-tool/SettingsView.jsx":"6b881ac04d4c","ui_kits/color-tool/ValuesView.jsx":"20777d40fb1e","ui_kits/color-tool/kit-data.js":"aebdfa1af69c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ColorToolDesignSystem_73584b = window.ColorToolDesignSystem_73584b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/controls/Slider.jsx
try { (() => {
const {
  useRef,
  useState,
  useCallback
} = React;
/*
  Slider — faithful interactive port of the .fig "Slider - Default" family
  (figma node 2:4042, 80 variants: Size mini/sm/regular/lg × Value × State).
  Exact geometry & paint lifted from the source variants:
    heights: lg 44 / regular 28 / sm 16 / mini 12, width 288, radius 100
    track:  black 10% over rgba(208,208,208,0.5) + inset highlights/shadows
    fill:   rgba(255,255,255,0.6) capsule, drop-shadow(5px 0 4px rgba(0,0,0,0.18))
    thumb (hover/pinch, lg/regular only): 24px white circle, soft glow
*/
const SLIDER_HEIGHTS = {
  mini: 12,
  sm: 16,
  regular: 28,
  lg: 44
};
const TRACK_BG = 'linear-gradient(rgba(0,0,0,0.1),rgba(0,0,0,0.1)), linear-gradient(rgba(208,208,208,0.5),rgba(208,208,208,0.5))';
const TRACK_INSET = 'inset 0px -0.5px 1px 0px rgba(255,255,255,0.3), inset 0px -0.5px 1px 0px rgba(255,255,255,0.25), inset 1px 1.5px 4px 0px rgba(0,0,0,0.08), inset 1px 1.5px 4px 0px rgba(0,0,0,0.1)';
function Slider({
  size = 'regular',
  value: valueProp,
  defaultValue = 50,
  min = 0,
  max = 100,
  disabled = false,
  onChange,
  symbol,
  style,
  className,
  'aria-label': ariaLabel
}) {
  const [internal, setInternal] = useState(defaultValue);
  const [hover, setHover] = useState(false);
  const [pinch, setPinch] = useState(false);
  const trackRef = useRef(null);
  const value = valueProp !== undefined ? valueProp : internal;
  const h = SLIDER_HEIGHTS[size] || SLIDER_HEIGHTS.regular;
  const pct = max === min ? 0 : (value - min) / (max - min) * 100;
  const setFromEvent = useCallback(e => {
    const el = trackRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const next = Math.round(min + Math.min(1, Math.max(0, x / rect.width)) * (max - min));
    if (valueProp === undefined) setInternal(next);
    if (onChange) onChange(next);
  }, [min, max, onChange, valueProp]);
  const onPointerDown = e => {
    if (disabled) return;
    setPinch(true);
    setFromEvent(e);
    const move = ev => setFromEvent(ev);
    const up = () => {
      setPinch(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  const onKeyDown = e => {
    if (disabled) return;
    const step = e.shiftKey ? 10 : 1;
    let next = value;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') next = Math.max(min, value - step);else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') next = Math.min(max, value + step);else return;
    e.preventDefault();
    if (valueProp === undefined) setInternal(next);
    if (onChange) onChange(next);
  };
  const showThumb = (hover || pinch) && !disabled && (size === 'lg' || size === 'regular');
  return /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    className: className,
    role: "slider",
    tabIndex: disabled ? -1 : 0,
    "aria-label": ariaLabel || 'Slider',
    "aria-valuemin": min,
    "aria-valuemax": max,
    "aria-valuenow": value,
    "aria-disabled": disabled || undefined,
    onPointerDown: onPointerDown,
    onKeyDown: onKeyDown,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 288,
      height: h,
      borderRadius: 100,
      position: 'relative',
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      outline: 'none',
      touchAction: 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      borderRadius: 100,
      background: TRACK_BG,
      boxShadow: TRACK_INSET
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: `${pct}%`,
      minWidth: pct > 0 ? h : 0,
      borderRadius: 100,
      backgroundColor: 'rgba(255,255,255,0.6)',
      boxShadow: '5px 0px 4px 0px rgba(0,0,0,0.18)'
    }
  })), showThumb && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '50%',
      left: `calc(${pct}% )`,
      transform: `translate(${pct > 92 ? '-100%' : pct < 8 ? '0' : '-50%'}, -50%)`,
      width: 24,
      height: 24,
      borderRadius: 100,
      backgroundColor: 'rgb(255,255,255)',
      filter: 'drop-shadow(0px 0px 26px rgba(94,94,94,0.4)) drop-shadow(0px 0px 26px rgba(255,255,255,0.2))',
      pointerEvents: 'none'
    }
  }), symbol && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      width: h,
      height: h,
      display: 'grid',
      placeItems: 'center',
      opacity: 0.15,
      fontFamily: '"SF Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      fontWeight: 510,
      fontSize: 19,
      lineHeight: '22px',
      color: 'rgba(255,255,255,0.96)',
      pointerEvents: 'none'
    }
  }, symbol));
}
// Alias matching the Figma family name "Slider - Default"
const SliderDefault = Slider;
Object.assign(__ds_scope, { Slider, __ds_default_components_controls_Slider_y7gmqo: Slider, SliderDefault });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Slider.jsx", error: String((e && e.message) || e) }); }

// components/feedback/PlainTooltip.jsx
try { (() => {
// figma node: 39:4826 Plain Tooltip (2 variants)
const __venc = v => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = p => "type=" + __venc(p.type);
function PlainTooltip(_p = {}) {
  const props = {
    ..._p,
    type: _p.type ?? "single line",
    supportingText: _p.supportingText ?? "Supporting text"
  };
  const __body0 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      minHeight: 24,
      borderRadius: 4,
      backgroundColor: "var(--schemes-inverse-surface)",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "4px 8px 4px 8px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Roboto, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 12,
      whiteSpace: "nowrap",
      lineHeight: "16px",
      letterSpacing: "0.400px",
      color: "var(--schemes-inverse-on-surface)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.supportingText));
  const __body1 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 200,
      minHeight: 24,
      borderRadius: 4,
      backgroundColor: "var(--schemes-inverse-surface)",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "4px 8px 4px 8px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Roboto, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 12,
      lineHeight: "16px",
      letterSpacing: "0.400px",
      color: "var(--schemes-inverse-on-surface)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.supportingText));
  const __impls = {
    // figma: Type=Single line
    "type=single line": __body0,
    // figma: Type=Multi line
    "type=multi line": __body1
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
Object.assign(__ds_scope, { PlainTooltip, __ds_default_components_feedback_PlainTooltip_1quhi19: PlainTooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/PlainTooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
// figma node: 39:4750 Tooltip (4 variants)
const __venc = v => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = p => "placement=" + __venc(p.placement);
function Tooltip(_p = {}) {
  const props = {
    ..._p,
    placement: _p.placement ?? "top",
    title: _p.title ?? "Title",
    hasBody: _p.hasBody ?? true,
    body: _p.body ?? "Body text"
  };
  const __body0 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,0.707,-0.707,0.707,44,52.050)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--background-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,0.707,-0.707,0.707,44,52.050)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--border-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 600,
      fontSize: 16,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0
    }
  }, props.title), props.hasBody && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.body));
  const __body1 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,-0.707,-0.707,-0.707,44,5.950)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--background-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,-0.707,-0.707,-0.707,44,5.950)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--border-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 600,
      fontSize: 16,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0
    }
  }, props.title), props.hasBody && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.body));
  const __body2 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,0.707,0.707,-0.707,82.050,29)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--background-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,0.707,0.707,-0.707,82.050,29)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--border-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 600,
      fontSize: 16,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0
    }
  }, props.title), props.hasBody && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.body));
  const __body3 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(-0.707,0.707,-0.707,-0.707,5.950,29)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--background-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8,
    height: 8,
    viewBox: "0 0 8 8",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(-0.707,0.707,-0.707,-0.707,5.950,29)",
      transformOrigin: "0 0",
      width: 8,
      height: 8,
      color: "var(--border-default-default)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 600,
      fontSize: 16,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0
    }
  }, props.title), props.hasBody && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: 1.399999976158142,
      color: "rgb(0,0,0)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.body));
  const __impls = {
    // figma: Placement=Top
    "placement=top": __body0,
    // figma: Placement=Bottom
    "placement=bottom": __body1,
    // figma: Placement=Left
    "placement=left": __body2,
    // figma: Placement=Right
    "placement=right": __body3
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
Object.assign(__ds_scope, { Tooltip, __ds_default_components_feedback_Tooltip_1lex2m1: Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/icons/icon-data.js
try { (() => {
// Generated by fig_materialize (moduleFormat: 'icon-data') — 60 icon(s)
// as { viewBox, body } SVG-markup entries. Render via the sibling Icon.jsx
// (<Icon name="CheckSize16" />), or consume the path data directly.
let __ds_default_components_icons_icon_data_12stud1;
try {
  __ds_default_components_icons_icon_data_12stud1 = {
    "CheckSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 11.232 0.566 C 11.545 0.253 11.545 -0.253 11.232 -0.566 C 10.92 -0.878 10.413 -0.878 10.101 -0.566 L 10.667 0 L 11.232 0.566 Z M 3.333 7.333 L 2.768 7.899 C 2.918 8.049 3.121 8.133 3.333 8.133 C 3.546 8.133 3.749 8.049 3.899 7.899 L 3.333 7.333 Z M 0.566 3.434 C 0.253 3.122 -0.253 3.122 -0.566 3.434 C -0.878 3.747 -0.878 4.253 -0.566 4.566 L 0 4 L 0.566 3.434 Z M 10.667 0 L 10.101 -0.566 L 2.768 6.768 L 3.333 7.333 L 3.899 7.899 L 11.232 0.566 L 10.667 0 Z M 3.333 7.333 L 3.899 6.768 L 0.566 3.434 L 0 4 L -0.566 4.566 L 2.768 7.899 L 3.333 7.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 4)\"/>"
    },
    "CheckSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 14.04 0.707 C 14.431 0.317 14.431 -0.317 14.04 -0.707 C 13.65 -1.098 13.017 -1.098 12.626 -0.707 L 13.333 0 L 14.04 0.707 Z M 4.167 9.167 L 3.46 9.874 C 3.85 10.264 4.483 10.264 4.874 9.874 L 4.167 9.167 Z M 0.707 4.293 C 0.317 3.902 -0.317 3.902 -0.707 4.293 C -1.098 4.683 -1.098 5.317 -0.707 5.707 L 0 5 L 0.707 4.293 Z M 13.333 0 L 12.626 -0.707 L 3.46 8.46 L 4.167 9.167 L 4.874 9.874 L 14.04 0.707 L 13.333 0 Z M 4.167 9.167 L 4.874 8.46 L 0.707 4.293 L 0 5 L -0.707 5.707 L 3.46 9.874 L 4.167 9.167 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.333 5)\"/>"
    },
    "CheckSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16.884 0.884 C 17.372 0.396 17.372 -0.396 16.884 -0.884 C 16.396 -1.372 15.604 -1.372 15.116 -0.884 L 16 0 L 16.884 0.884 Z M 5 11 L 4.116 11.884 C 4.604 12.372 5.396 12.372 5.884 11.884 L 5 11 Z M 0.884 5.116 C 0.396 4.628 -0.396 4.628 -0.884 5.116 C -1.372 5.604 -1.372 6.396 -0.884 6.884 L 0 6 L 0.884 5.116 Z M 16 0 L 15.116 -0.884 L 4.116 10.116 L 5 11 L 5.884 11.884 L 16.884 0.884 L 16 0 Z M 5 11 L 5.884 10.116 L 0.884 5.116 L 0 6 L -0.884 6.884 L 4.116 11.884 L 5 11 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 6)\"/>"
    },
    "CheckSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 22.394 1.061 C 22.98 0.475 22.98 -0.475 22.394 -1.061 C 21.808 -1.646 20.858 -1.646 20.273 -1.061 L 21.333 0 L 22.394 1.061 Z M 6.667 14.667 L 5.606 15.727 C 6.192 16.313 7.142 16.313 7.727 15.727 L 6.667 14.667 Z M 1.061 6.939 C 0.475 6.354 -0.475 6.354 -1.061 6.939 C -1.646 7.525 -1.646 8.475 -1.061 9.061 L 0 8 L 1.061 6.939 Z M 21.333 0 L 20.273 -1.061 L 5.606 13.606 L 6.667 14.667 L 7.727 15.727 L 22.394 1.061 L 21.333 0 Z M 6.667 14.667 L 7.727 13.606 L 1.061 6.939 L 0 8 L -1.061 9.061 L 5.606 15.727 L 6.667 14.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.333 8)\"/>"
    },
    "CheckSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 27.904 1.237 C 28.588 0.554 28.588 -0.554 27.904 -1.237 C 27.221 -1.921 26.113 -1.921 25.429 -1.237 L 26.667 0 L 27.904 1.237 Z M 8.333 18.333 L 7.096 19.571 C 7.779 20.254 8.887 20.254 9.571 19.571 L 8.333 18.333 Z M 1.237 8.763 C 0.554 8.079 -0.554 8.079 -1.237 8.763 C -1.921 9.446 -1.921 10.554 -1.237 11.237 L 0 10 L 1.237 8.763 Z M 26.667 0 L 25.429 -1.237 L 7.096 17.096 L 8.333 18.333 L 9.571 19.571 L 27.904 1.237 L 26.667 0 Z M 8.333 18.333 L 9.571 17.096 L 1.237 8.763 L 0 10 L -1.237 11.237 L 7.096 19.571 L 8.333 18.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6.667 10)\"/>"
    },
    "CheckSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 33.414 1.414 C 34.195 0.633 34.195 -0.633 33.414 -1.414 C 32.633 -2.195 31.367 -2.195 30.586 -1.414 L 32 0 L 33.414 1.414 Z M 10 22 L 8.586 23.414 C 9.367 24.195 10.633 24.195 11.414 23.414 L 10 22 Z M 1.414 10.586 C 0.633 9.805 -0.633 9.805 -1.414 10.586 C -2.195 11.367 -2.195 12.633 -1.414 13.414 L 0 12 L 1.414 10.586 Z M 32 0 L 30.586 -1.414 L 8.586 20.586 L 10 22 L 11.414 23.414 L 33.414 1.414 L 32 0 Z M 10 22 L 11.414 20.586 L 1.414 10.586 L 0 12 L -1.414 13.414 L 8.586 23.414 L 10 22 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 12)\"/>"
    },
    "ChevronUpSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 7.434 4.566 C 7.747 4.878 8.253 4.878 8.566 4.566 C 8.878 4.253 8.878 3.747 8.566 3.434 L 8 4 L 7.434 4.566 Z M 4 0 L 4.566 -0.566 C 4.253 -0.878 3.747 -0.878 3.434 -0.566 L 4 0 Z M -0.566 3.434 C -0.878 3.747 -0.878 4.253 -0.566 4.566 C -0.253 4.878 0.253 4.878 0.566 4.566 L 0 4 L -0.566 3.434 Z M 8 4 L 8.566 3.434 L 4.566 -0.566 L 4 0 L 3.434 0.566 L 7.434 4.566 L 8 4 Z M 4 0 L 3.434 -0.566 L -0.566 3.434 L 0 4 L 0.566 4.566 L 4.566 0.566 L 4 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 6)\"/>"
    },
    "ChevronUpSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 9.293 5.707 C 9.683 6.098 10.317 6.098 10.707 5.707 C 11.098 5.317 11.098 4.683 10.707 4.293 L 10 5 L 9.293 5.707 Z M 5 0 L 5.707 -0.707 C 5.317 -1.098 4.683 -1.098 4.293 -0.707 L 5 0 Z M -0.707 4.293 C -1.098 4.683 -1.098 5.317 -0.707 5.707 C -0.317 6.098 0.317 6.098 0.707 5.707 L 0 5 L -0.707 4.293 Z M 10 5 L 10.707 4.293 L 5.707 -0.707 L 5 0 L 4.293 0.707 L 9.293 5.707 L 10 5 Z M 5 0 L 4.293 -0.707 L -0.707 4.293 L 0 5 L 0.707 5.707 L 5.707 0.707 L 5 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 7.500)\"/>"
    },
    "ChevronUpSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11.116 6.884 C 11.604 7.372 12.396 7.372 12.884 6.884 C 13.372 6.396 13.372 5.604 12.884 5.116 L 12 6 L 11.116 6.884 Z M 6 0 L 6.884 -0.884 C 6.396 -1.372 5.604 -1.372 5.116 -0.884 L 6 0 Z M -0.884 5.116 C -1.372 5.604 -1.372 6.396 -0.884 6.884 C -0.396 7.372 0.396 7.372 0.884 6.884 L 0 6 L -0.884 5.116 Z M 12 6 L 12.884 5.116 L 6.884 -0.884 L 6 0 L 5.116 0.884 L 11.116 6.884 L 12 6 Z M 6 0 L 5.116 -0.884 L -0.884 5.116 L 0 6 L 0.884 6.884 L 6.884 0.884 L 6 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 9)\"/>"
    },
    "ChevronUpSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 14.939 9.061 C 15.525 9.646 16.475 9.646 17.061 9.061 C 17.646 8.475 17.646 7.525 17.061 6.939 L 16 8 L 14.939 9.061 Z M 8 0 L 9.061 -1.061 C 8.475 -1.646 7.525 -1.646 6.939 -1.061 L 8 0 Z M -1.061 6.939 C -1.646 7.525 -1.646 8.475 -1.061 9.061 C -0.475 9.646 0.475 9.646 1.061 9.061 L 0 8 L -1.061 6.939 Z M 16 8 L 17.061 6.939 L 9.061 -1.061 L 8 0 L 6.939 1.061 L 14.939 9.061 L 16 8 Z M 8 0 L 6.939 -1.061 L -1.061 6.939 L 0 8 L 1.061 9.061 L 9.061 1.061 L 8 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 12)\"/>"
    },
    "ChevronUpSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 18.763 11.237 C 19.446 11.921 20.554 11.921 21.237 11.237 C 21.921 10.554 21.921 9.446 21.237 8.763 L 20 10 L 18.763 11.237 Z M 10 0 L 11.237 -1.237 C 10.554 -1.921 9.446 -1.921 8.763 -1.237 L 10 0 Z M -1.237 8.763 C -1.921 9.446 -1.921 10.554 -1.237 11.237 C -0.554 11.921 0.554 11.921 1.237 11.237 L 0 10 L -1.237 8.763 Z M 20 10 L 21.237 8.763 L 11.237 -1.237 L 10 0 L 8.763 1.237 L 18.763 11.237 L 20 10 Z M 10 0 L 8.763 -1.237 L -1.237 8.763 L 0 10 L 1.237 11.237 L 11.237 1.237 L 10 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 10 15)\"/>"
    },
    "ChevronUpSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 22.586 13.414 C 23.367 14.195 24.633 14.195 25.414 13.414 C 26.195 12.633 26.195 11.367 25.414 10.586 L 24 12 L 22.586 13.414 Z M 12 0 L 13.414 -1.414 C 12.633 -2.195 11.367 -2.195 10.586 -1.414 L 12 0 Z M -1.414 10.586 C -2.195 11.367 -2.195 12.633 -1.414 13.414 C -0.633 14.195 0.633 14.195 1.414 13.414 L 0 12 L -1.414 10.586 Z M 24 12 L 25.414 10.586 L 13.414 -1.414 L 12 0 L 10.586 1.414 L 22.586 13.414 L 24 12 Z M 12 0 L 10.586 -1.414 L -1.414 10.586 L 0 12 L 1.414 13.414 L 13.414 1.414 L 12 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 12 18)\"/>"
    },
    "CopySize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 2 9.467 C 2.442 9.467 2.8 9.108 2.8 8.667 C 2.8 8.225 2.442 7.867 2 7.867 L 2 8.667 L 2 9.467 Z M 0 7.333 L -0.8 7.333 L 0 7.333 Z M 1.333 0 L 1.333 -0.8 L 1.333 0 Z M 7.333 0 L 7.333 -0.8 L 7.333 0 Z M 7.867 2 C 7.867 2.442 8.225 2.8 8.667 2.8 C 9.108 2.8 9.467 2.442 9.467 2 L 8.667 2 L 7.867 2 Z M 6 4.667 L 6 5.467 L 12 5.467 L 12 4.667 L 12 3.867 L 6 3.867 L 6 4.667 Z M 12 4.667 L 12 5.467 C 12.295 5.467 12.533 5.705 12.533 6 L 13.333 6 L 14.133 6 C 14.133 4.822 13.178 3.867 12 3.867 L 12 4.667 Z M 13.333 6 L 12.533 6 L 12.533 12 L 13.333 12 L 14.133 12 L 14.133 6 L 13.333 6 Z M 13.333 12 L 12.533 12 C 12.533 12.295 12.295 12.533 12 12.533 L 12 13.333 L 12 14.133 C 13.178 14.133 14.133 13.178 14.133 12 L 13.333 12 Z M 12 13.333 L 12 12.533 L 6 12.533 L 6 13.333 L 6 14.133 L 12 14.133 L 12 13.333 Z M 6 13.333 L 6 12.533 C 5.705 12.533 5.467 12.295 5.467 12 L 4.667 12 L 3.867 12 C 3.867 13.178 4.822 14.133 6 14.133 L 6 13.333 Z M 4.667 12 L 5.467 12 L 5.467 6 L 4.667 6 L 3.867 6 L 3.867 12 L 4.667 12 Z M 4.667 6 L 5.467 6 C 5.467 5.705 5.705 5.467 6 5.467 L 6 4.667 L 6 3.867 C 4.822 3.867 3.867 4.822 3.867 6 L 4.667 6 Z M 2 8.667 L 2 7.867 L 1.333 7.867 L 1.333 8.667 L 1.333 9.467 L 2 9.467 L 2 8.667 Z M 1.333 8.667 L 1.333 7.867 C 1.192 7.867 1.056 7.81 0.956 7.71 L 0.391 8.276 L -0.175 8.842 C 0.225 9.242 0.768 9.467 1.333 9.467 L 1.333 8.667 Z M 0.391 8.276 L 0.956 7.71 C 0.856 7.61 0.8 7.475 0.8 7.333 L 0 7.333 L -0.8 7.333 C -0.8 7.899 -0.575 8.442 -0.175 8.842 L 0.391 8.276 Z M 0 7.333 L 0.8 7.333 L 0.8 1.333 L 0 1.333 L -0.8 1.333 L -0.8 7.333 L 0 7.333 Z M 0 1.333 L 0.8 1.333 C 0.8 1.192 0.856 1.056 0.956 0.956 L 0.391 0.391 L -0.175 -0.175 C -0.575 0.225 -0.8 0.768 -0.8 1.333 L 0 1.333 Z M 0.391 0.391 L 0.956 0.956 C 1.056 0.856 1.192 0.8 1.333 0.8 L 1.333 0 L 1.333 -0.8 C 0.768 -0.8 0.225 -0.575 -0.175 -0.175 L 0.391 0.391 Z M 1.333 0 L 1.333 0.8 L 7.333 0.8 L 7.333 0 L 7.333 -0.8 L 1.333 -0.8 L 1.333 0 Z M 7.333 0 L 7.333 0.8 C 7.475 0.8 7.61 0.856 7.71 0.956 L 8.276 0.391 L 8.842 -0.175 C 8.442 -0.575 7.899 -0.8 7.333 -0.8 L 7.333 0 Z M 8.276 0.391 L 7.71 0.956 C 7.81 1.056 7.867 1.192 7.867 1.333 L 8.667 1.333 L 9.467 1.333 C 9.467 0.768 9.242 0.225 8.842 -0.175 L 8.276 0.391 Z M 8.667 1.333 L 7.867 1.333 L 7.867 2 L 8.667 2 L 9.467 2 L 9.467 1.333 L 8.667 1.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333)\"/>"
    },
    "CopySize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 2.5 11.833 C 3.052 11.833 3.5 11.386 3.5 10.833 C 3.5 10.281 3.052 9.833 2.5 9.833 L 2.5 10.833 L 2.5 11.833 Z M 0 9.167 L -1 9.167 L 0 9.167 Z M 1.667 0 L 1.667 -1 L 1.667 0 Z M 9.167 0 L 9.167 -1 L 9.167 0 Z M 9.833 2.5 C 9.833 3.052 10.281 3.5 10.833 3.5 C 11.386 3.5 11.833 3.052 11.833 2.5 L 10.833 2.5 L 9.833 2.5 Z M 7.5 5.833 L 7.5 6.833 L 15 6.833 L 15 5.833 L 15 4.833 L 7.5 4.833 L 7.5 5.833 Z M 15 5.833 L 15 6.833 C 15.368 6.833 15.667 7.132 15.667 7.5 L 16.667 7.5 L 17.667 7.5 C 17.667 6.027 16.473 4.833 15 4.833 L 15 5.833 Z M 16.667 7.5 L 15.667 7.5 L 15.667 15 L 16.667 15 L 17.667 15 L 17.667 7.5 L 16.667 7.5 Z M 16.667 15 L 15.667 15 C 15.667 15.368 15.368 15.667 15 15.667 L 15 16.667 L 15 17.667 C 16.473 17.667 17.667 16.473 17.667 15 L 16.667 15 Z M 15 16.667 L 15 15.667 L 7.5 15.667 L 7.5 16.667 L 7.5 17.667 L 15 17.667 L 15 16.667 Z M 7.5 16.667 L 7.5 15.667 C 7.132 15.667 6.833 15.368 6.833 15 L 5.833 15 L 4.833 15 C 4.833 16.473 6.027 17.667 7.5 17.667 L 7.5 16.667 Z M 5.833 15 L 6.833 15 L 6.833 7.5 L 5.833 7.5 L 4.833 7.5 L 4.833 15 L 5.833 15 Z M 5.833 7.5 L 6.833 7.5 C 6.833 7.132 7.132 6.833 7.5 6.833 L 7.5 5.833 L 7.5 4.833 C 6.027 4.833 4.833 6.027 4.833 7.5 L 5.833 7.5 Z M 2.5 10.833 L 2.5 9.833 L 1.667 9.833 L 1.667 10.833 L 1.667 11.833 L 2.5 11.833 L 2.5 10.833 Z M 1.667 10.833 L 1.667 9.833 C 1.49 9.833 1.32 9.763 1.195 9.638 L 0.488 10.345 L -0.219 11.052 C 0.281 11.552 0.959 11.833 1.667 11.833 L 1.667 10.833 Z M 0.488 10.345 L 1.195 9.638 C 1.07 9.513 1 9.343 1 9.167 L 0 9.167 L -1 9.167 C -1 9.874 -0.719 10.552 -0.219 11.052 L 0.488 10.345 Z M 0 9.167 L 1 9.167 L 1 1.667 L 0 1.667 L -1 1.667 L -1 9.167 L 0 9.167 Z M 0 1.667 L 1 1.667 C 1 1.49 1.07 1.32 1.195 1.195 L 0.488 0.488 L -0.219 -0.219 C -0.719 0.281 -1 0.959 -1 1.667 L 0 1.667 Z M 0.488 0.488 L 1.195 1.195 C 1.32 1.07 1.49 1 1.667 1 L 1.667 0 L 1.667 -1 C 0.959 -1 0.281 -0.719 -0.219 -0.219 L 0.488 0.488 Z M 1.667 0 L 1.667 1 L 9.167 1 L 9.167 0 L 9.167 -1 L 1.667 -1 L 1.667 0 Z M 9.167 0 L 9.167 1 C 9.343 1 9.513 1.07 9.638 1.195 L 10.345 0.488 L 11.052 -0.219 C 10.552 -0.719 9.874 -1 9.167 -1 L 9.167 0 Z M 10.345 0.488 L 9.638 1.195 C 9.763 1.32 9.833 1.49 9.833 1.667 L 10.833 1.667 L 11.833 1.667 C 11.833 0.959 11.552 0.281 11.052 -0.219 L 10.345 0.488 Z M 10.833 1.667 L 9.833 1.667 L 9.833 2.5 L 10.833 2.5 L 11.833 2.5 L 11.833 1.667 L 10.833 1.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "CopySize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 3 14.25 C 3.69 14.25 4.25 13.69 4.25 13 C 4.25 12.31 3.69 11.75 3 11.75 L 3 13 L 3 14.25 Z M 0 11 L -1.25 11 L 0 11 Z M 2 0 L 2 -1.25 L 2 0 Z M 11 0 L 11 -1.25 L 11 0 Z M 11.75 3 C 11.75 3.69 12.31 4.25 13 4.25 C 13.69 4.25 14.25 3.69 14.25 3 L 13 3 L 11.75 3 Z M 9 7 L 9 8.25 L 18 8.25 L 18 7 L 18 5.75 L 9 5.75 L 9 7 Z M 18 7 L 18 8.25 C 18.414 8.25 18.75 8.586 18.75 9 L 20 9 L 21.25 9 C 21.25 7.205 19.795 5.75 18 5.75 L 18 7 Z M 20 9 L 18.75 9 L 18.75 18 L 20 18 L 21.25 18 L 21.25 9 L 20 9 Z M 20 18 L 18.75 18 C 18.75 18.414 18.414 18.75 18 18.75 L 18 20 L 18 21.25 C 19.795 21.25 21.25 19.795 21.25 18 L 20 18 Z M 18 20 L 18 18.75 L 9 18.75 L 9 20 L 9 21.25 L 18 21.25 L 18 20 Z M 9 20 L 9 18.75 C 8.586 18.75 8.25 18.414 8.25 18 L 7 18 L 5.75 18 C 5.75 19.795 7.205 21.25 9 21.25 L 9 20 Z M 7 18 L 8.25 18 L 8.25 9 L 7 9 L 5.75 9 L 5.75 18 L 7 18 Z M 7 9 L 8.25 9 C 8.25 8.586 8.586 8.25 9 8.25 L 9 7 L 9 5.75 C 7.205 5.75 5.75 7.205 5.75 9 L 7 9 Z M 3 13 L 3 11.75 L 2 11.75 L 2 13 L 2 14.25 L 3 14.25 L 3 13 Z M 2 13 L 2 11.75 C 1.801 11.75 1.61 11.671 1.47 11.53 L 0.586 12.414 L -0.298 13.298 C 0.311 13.908 1.138 14.25 2 14.25 L 2 13 Z M 0.586 12.414 L 1.47 11.53 C 1.329 11.39 1.25 11.199 1.25 11 L 0 11 L -1.25 11 C -1.25 11.862 -0.908 12.689 -0.298 13.298 L 0.586 12.414 Z M 0 11 L 1.25 11 L 1.25 2 L 0 2 L -1.25 2 L -1.25 11 L 0 11 Z M 0 2 L 1.25 2 C 1.25 1.801 1.329 1.61 1.47 1.47 L 0.586 0.586 L -0.298 -0.298 C -0.908 0.311 -1.25 1.138 -1.25 2 L 0 2 Z M 0.586 0.586 L 1.47 1.47 C 1.61 1.329 1.801 1.25 2 1.25 L 2 0 L 2 -1.25 C 1.138 -1.25 0.311 -0.908 -0.298 -0.298 L 0.586 0.586 Z M 2 0 L 2 1.25 L 11 1.25 L 11 0 L 11 -1.25 L 2 -1.25 L 2 0 Z M 11 0 L 11 1.25 C 11.199 1.25 11.39 1.329 11.53 1.47 L 12.414 0.586 L 13.298 -0.298 C 12.689 -0.908 11.862 -1.25 11 -1.25 L 11 0 Z M 12.414 0.586 L 11.53 1.47 C 11.671 1.61 11.75 1.801 11.75 2 L 13 2 L 14.25 2 C 14.25 1.138 13.908 0.311 13.298 -0.298 L 12.414 0.586 Z M 13 2 L 11.75 2 L 11.75 3 L 13 3 L 14.25 3 L 14.25 2 L 13 2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "CopySize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 4 18.833 C 4.828 18.833 5.5 18.162 5.5 17.333 C 5.5 16.505 4.828 15.833 4 15.833 L 4 17.333 L 4 18.833 Z M 0 14.667 L -1.5 14.667 L 0 14.667 Z M 2.667 0 L 2.667 -1.5 L 2.667 0 Z M 14.667 0 L 14.667 -1.5 L 14.667 0 Z M 15.833 4 C 15.833 4.828 16.505 5.5 17.333 5.5 C 18.162 5.5 18.833 4.828 18.833 4 L 17.333 4 L 15.833 4 Z M 12 9.333 L 12 10.833 L 24 10.833 L 24 9.333 L 24 7.833 L 12 7.833 L 12 9.333 Z M 24 9.333 L 24 10.833 C 24.644 10.833 25.167 11.356 25.167 12 L 26.667 12 L 28.167 12 C 28.167 9.699 26.301 7.833 24 7.833 L 24 9.333 Z M 26.667 12 L 25.167 12 L 25.167 24 L 26.667 24 L 28.167 24 L 28.167 12 L 26.667 12 Z M 26.667 24 L 25.167 24 C 25.167 24.644 24.644 25.167 24 25.167 L 24 26.667 L 24 28.167 C 26.301 28.167 28.167 26.301 28.167 24 L 26.667 24 Z M 24 26.667 L 24 25.167 L 12 25.167 L 12 26.667 L 12 28.167 L 24 28.167 L 24 26.667 Z M 12 26.667 L 12 25.167 C 11.356 25.167 10.833 24.644 10.833 24 L 9.333 24 L 7.833 24 C 7.833 26.301 9.699 28.167 12 28.167 L 12 26.667 Z M 9.333 24 L 10.833 24 L 10.833 12 L 9.333 12 L 7.833 12 L 7.833 24 L 9.333 24 Z M 9.333 12 L 10.833 12 C 10.833 11.356 11.356 10.833 12 10.833 L 12 9.333 L 12 7.833 C 9.699 7.833 7.833 9.699 7.833 12 L 9.333 12 Z M 4 17.333 L 4 15.833 L 2.667 15.833 L 2.667 17.333 L 2.667 18.833 L 4 18.833 L 4 17.333 Z M 2.667 17.333 L 2.667 15.833 C 2.357 15.833 2.061 15.71 1.842 15.492 L 0.781 16.552 L -0.28 17.613 C 0.502 18.394 1.562 18.833 2.667 18.833 L 2.667 17.333 Z M 0.781 16.552 L 1.842 15.492 C 1.623 15.273 1.5 14.976 1.5 14.667 L 0 14.667 L -1.5 14.667 C -1.5 15.772 -1.061 16.832 -0.28 17.613 L 0.781 16.552 Z M 0 14.667 L 1.5 14.667 L 1.5 2.667 L 0 2.667 L -1.5 2.667 L -1.5 14.667 L 0 14.667 Z M 0 2.667 L 1.5 2.667 C 1.5 2.357 1.623 2.061 1.842 1.842 L 0.781 0.781 L -0.28 -0.28 C -1.061 0.502 -1.5 1.562 -1.5 2.667 L 0 2.667 Z M 0.781 0.781 L 1.842 1.842 C 2.061 1.623 2.357 1.5 2.667 1.5 L 2.667 0 L 2.667 -1.5 C 1.562 -1.5 0.502 -1.061 -0.28 -0.28 L 0.781 0.781 Z M 2.667 0 L 2.667 1.5 L 14.667 1.5 L 14.667 0 L 14.667 -1.5 L 2.667 -1.5 L 2.667 0 Z M 14.667 0 L 14.667 1.5 C 14.976 1.5 15.273 1.623 15.492 1.842 L 16.552 0.781 L 17.613 -0.28 C 16.832 -1.061 15.772 -1.5 14.667 -1.5 L 14.667 0 Z M 16.552 0.781 L 15.492 1.842 C 15.71 2.061 15.833 2.357 15.833 2.667 L 17.333 2.667 L 18.833 2.667 C 18.833 1.562 18.394 0.502 17.613 -0.28 L 16.552 0.781 Z M 17.333 2.667 L 15.833 2.667 L 15.833 4 L 17.333 4 L 18.833 4 L 18.833 2.667 L 17.333 2.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 2.667)\"/>"
    },
    "CopySize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 5 23.417 C 5.966 23.417 6.75 22.633 6.75 21.667 C 6.75 20.7 5.966 19.917 5 19.917 L 5 21.667 L 5 23.417 Z M 0 18.333 L -1.75 18.333 L 0 18.333 Z M 3.333 0 L 3.333 -1.75 L 3.333 0 Z M 18.333 0 L 18.333 -1.75 L 18.333 0 Z M 19.917 5 C 19.917 5.966 20.7 6.75 21.667 6.75 C 22.633 6.75 23.417 5.966 23.417 5 L 21.667 5 L 19.917 5 Z M 15 11.667 L 15 13.417 L 30 13.417 L 30 11.667 L 30 9.917 L 15 9.917 L 15 11.667 Z M 30 11.667 L 30 13.417 C 30.874 13.417 31.583 14.126 31.583 15 L 33.333 15 L 35.083 15 C 35.083 12.193 32.807 9.917 30 9.917 L 30 11.667 Z M 33.333 15 L 31.583 15 L 31.583 30 L 33.333 30 L 35.083 30 L 35.083 15 L 33.333 15 Z M 33.333 30 L 31.583 30 C 31.583 30.874 30.874 31.583 30 31.583 L 30 33.333 L 30 35.083 C 32.807 35.083 35.083 32.807 35.083 30 L 33.333 30 Z M 30 33.333 L 30 31.583 L 15 31.583 L 15 33.333 L 15 35.083 L 30 35.083 L 30 33.333 Z M 15 33.333 L 15 31.583 C 14.126 31.583 13.417 30.874 13.417 30 L 11.667 30 L 9.917 30 C 9.917 32.807 12.193 35.083 15 35.083 L 15 33.333 Z M 11.667 30 L 13.417 30 L 13.417 15 L 11.667 15 L 9.917 15 L 9.917 30 L 11.667 30 Z M 11.667 15 L 13.417 15 C 13.417 14.126 14.126 13.417 15 13.417 L 15 11.667 L 15 9.917 C 12.193 9.917 9.917 12.193 9.917 15 L 11.667 15 Z M 5 21.667 L 5 19.917 L 3.333 19.917 L 3.333 21.667 L 3.333 23.417 L 5 23.417 L 5 21.667 Z M 3.333 21.667 L 3.333 19.917 C 2.913 19.917 2.511 19.75 2.214 19.453 L 0.976 20.69 L -0.261 21.928 C 0.692 22.881 1.985 23.417 3.333 23.417 L 3.333 21.667 Z M 0.976 20.69 L 2.214 19.453 C 1.917 19.156 1.75 18.753 1.75 18.333 L 0 18.333 L -1.75 18.333 C -1.75 19.682 -1.214 20.974 -0.261 21.928 L 0.976 20.69 Z M 0 18.333 L 1.75 18.333 L 1.75 3.333 L 0 3.333 L -1.75 3.333 L -1.75 18.333 L 0 18.333 Z M 0 3.333 L 1.75 3.333 C 1.75 2.913 1.917 2.511 2.214 2.214 L 0.976 0.976 L -0.261 -0.261 C -1.214 0.692 -1.75 1.985 -1.75 3.333 L 0 3.333 Z M 0.976 0.976 L 2.214 2.214 C 2.511 1.917 2.913 1.75 3.333 1.75 L 3.333 0 L 3.333 -1.75 C 1.985 -1.75 0.692 -1.214 -0.261 -0.261 L 0.976 0.976 Z M 3.333 0 L 3.333 1.75 L 18.333 1.75 L 18.333 0 L 18.333 -1.75 L 3.333 -1.75 L 3.333 0 Z M 18.333 0 L 18.333 1.75 C 18.753 1.75 19.156 1.917 19.453 2.214 L 20.69 0.976 L 21.928 -0.261 C 20.974 -1.214 19.682 -1.75 18.333 -1.75 L 18.333 0 Z M 20.69 0.976 L 19.453 2.214 C 19.75 2.511 19.917 2.913 19.917 3.333 L 21.667 3.333 L 23.417 3.333 C 23.417 1.985 22.881 0.692 21.928 -0.261 L 20.69 0.976 Z M 21.667 3.333 L 19.917 3.333 L 19.917 5 L 21.667 5 L 23.417 5 L 23.417 3.333 L 21.667 3.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.333 3.333)\"/>"
    },
    "CopySize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 6 28 C 7.105 28 8 27.105 8 26 C 8 24.895 7.105 24 6 24 L 6 26 L 6 28 Z M 0 22 L -2 22 L 0 22 Z M 4 0 L 4 -2 L 4 0 Z M 22 0 L 22 -2 L 22 0 Z M 24 6 C 24 7.105 24.895 8 26 8 C 27.105 8 28 7.105 28 6 L 26 6 L 24 6 Z M 18 14 L 18 16 L 36 16 L 36 14 L 36 12 L 18 12 L 18 14 Z M 36 14 L 36 16 C 37.105 16 38 16.895 38 18 L 40 18 L 42 18 C 42 14.686 39.314 12 36 12 L 36 14 Z M 40 18 L 38 18 L 38 36 L 40 36 L 42 36 L 42 18 L 40 18 Z M 40 36 L 38 36 C 38 37.105 37.105 38 36 38 L 36 40 L 36 42 C 39.314 42 42 39.314 42 36 L 40 36 Z M 36 40 L 36 38 L 18 38 L 18 40 L 18 42 L 36 42 L 36 40 Z M 18 40 L 18 38 C 16.895 38 16 37.105 16 36 L 14 36 L 12 36 C 12 39.314 14.686 42 18 42 L 18 40 Z M 14 36 L 16 36 L 16 18 L 14 18 L 12 18 L 12 36 L 14 36 Z M 14 18 L 16 18 C 16 16.895 16.895 16 18 16 L 18 14 L 18 12 C 14.686 12 12 14.686 12 18 L 14 18 Z M 6 26 L 6 24 L 4 24 L 4 26 L 4 28 L 6 28 L 6 26 Z M 4 26 L 4 24 C 3.47 24 2.961 23.789 2.586 23.414 L 1.172 24.828 L -0.243 26.243 C 0.883 27.368 2.409 28 4 28 L 4 26 Z M 1.172 24.828 L 2.586 23.414 C 2.211 23.039 2 22.53 2 22 L 0 22 L -2 22 C -2 23.591 -1.368 25.117 -0.243 26.243 L 1.172 24.828 Z M 0 22 L 2 22 L 2 4 L 0 4 L -2 4 L -2 22 L 0 22 Z M 0 4 L 2 4 C 2 3.47 2.211 2.961 2.586 2.586 L 1.172 1.172 L -0.243 -0.243 C -1.368 0.883 -2 2.409 -2 4 L 0 4 Z M 1.172 1.172 L 2.586 2.586 C 2.961 2.211 3.47 2 4 2 L 4 0 L 4 -2 C 2.409 -2 0.883 -1.368 -0.243 -0.243 L 1.172 1.172 Z M 4 0 L 4 2 L 22 2 L 22 0 L 22 -2 L 4 -2 L 4 0 Z M 22 0 L 22 2 C 22.53 2 23.039 2.211 23.414 2.586 L 24.828 1.172 L 26.243 -0.243 C 25.117 -1.368 23.591 -2 22 -2 L 22 0 Z M 24.828 1.172 L 23.414 2.586 C 23.789 2.961 24 3.47 24 4 L 26 4 L 28 4 C 28 2.409 27.368 0.883 26.243 -0.243 L 24.828 1.172 Z M 26 4 L 24 4 L 24 6 L 26 6 L 28 6 L 28 4 L 26 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "DownloadSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 12.8 8 C 12.8 7.558 12.442 7.2 12 7.2 C 11.558 7.2 11.2 7.558 11.2 8 L 12 8 L 12.8 8 Z M 0 10.667 L -0.8 10.667 L 0 10.667 Z M 0.8 8 C 0.8 7.558 0.442 7.2 0 7.2 C -0.442 7.2 -0.8 7.558 -0.8 8 L 0 8 L 0.8 8 Z M 3.232 4.101 C 2.92 3.789 2.413 3.789 2.101 4.101 C 1.789 4.413 1.789 4.92 2.101 5.232 L 2.667 4.667 L 3.232 4.101 Z M 6 8 L 5.434 8.566 C 5.747 8.878 6.253 8.878 6.566 8.566 L 6 8 Z M 9.899 5.232 C 10.211 4.92 10.211 4.413 9.899 4.101 C 9.587 3.789 9.08 3.789 8.768 4.101 L 9.333 4.667 L 9.899 5.232 Z M 6.8 0 C 6.8 -0.442 6.442 -0.8 6 -0.8 C 5.558 -0.8 5.2 -0.442 5.2 0 L 6 0 L 6.8 0 Z M 12 8 L 11.2 8 L 11.2 10.667 L 12 10.667 L 12.8 10.667 L 12.8 8 L 12 8 Z M 12 10.667 L 11.2 10.667 C 11.2 10.808 11.144 10.944 11.044 11.044 L 11.609 11.609 L 12.175 12.175 C 12.575 11.775 12.8 11.232 12.8 10.667 L 12 10.667 Z M 11.609 11.609 L 11.044 11.044 C 10.944 11.144 10.808 11.2 10.667 11.2 L 10.667 12 L 10.667 12.8 C 11.232 12.8 11.775 12.575 12.175 12.175 L 11.609 11.609 Z M 10.667 12 L 10.667 11.2 L 1.333 11.2 L 1.333 12 L 1.333 12.8 L 10.667 12.8 L 10.667 12 Z M 1.333 12 L 1.333 11.2 C 1.192 11.2 1.056 11.144 0.956 11.044 L 0.391 11.609 L -0.175 12.175 C 0.225 12.575 0.768 12.8 1.333 12.8 L 1.333 12 Z M 0.391 11.609 L 0.956 11.044 C 0.856 10.944 0.8 10.808 0.8 10.667 L 0 10.667 L -0.8 10.667 C -0.8 11.232 -0.575 11.775 -0.175 12.175 L 0.391 11.609 Z M 0 10.667 L 0.8 10.667 L 0.8 8 L 0 8 L -0.8 8 L -0.8 10.667 L 0 10.667 Z M 2.667 4.667 L 2.101 5.232 L 5.434 8.566 L 6 8 L 6.566 7.434 L 3.232 4.101 L 2.667 4.667 Z M 6 8 L 6.566 8.566 L 9.899 5.232 L 9.333 4.667 L 8.768 4.101 L 5.434 7.434 L 6 8 Z M 6 8 L 6.8 8 L 6.8 0 L 6 0 L 5.2 0 L 5.2 8 L 6 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "DownloadSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 16 10 C 16 9.448 15.552 9 15 9 C 14.448 9 14 9.448 14 10 L 15 10 L 16 10 Z M 0 13.333 L -1 13.333 L 0 13.333 Z M 1 10 C 1 9.448 0.552 9 0 9 C -0.552 9 -1 9.448 -1 10 L 0 10 L 1 10 Z M 4.04 5.126 C 3.65 4.736 3.017 4.736 2.626 5.126 C 2.236 5.517 2.236 6.15 2.626 6.54 L 3.333 5.833 L 4.04 5.126 Z M 7.5 10 L 6.793 10.707 C 7.183 11.098 7.817 11.098 8.207 10.707 L 7.5 10 Z M 12.374 6.54 C 12.764 6.15 12.764 5.517 12.374 5.126 C 11.983 4.736 11.35 4.736 10.96 5.126 L 11.667 5.833 L 12.374 6.54 Z M 8.5 0 C 8.5 -0.552 8.052 -1 7.5 -1 C 6.948 -1 6.5 -0.552 6.5 0 L 7.5 0 L 8.5 0 Z M 15 10 L 14 10 L 14 13.333 L 15 13.333 L 16 13.333 L 16 10 L 15 10 Z M 15 13.333 L 14 13.333 C 14 13.51 13.93 13.68 13.805 13.805 L 14.512 14.512 L 15.219 15.219 C 15.719 14.719 16 14.041 16 13.333 L 15 13.333 Z M 14.512 14.512 L 13.805 13.805 C 13.68 13.93 13.51 14 13.333 14 L 13.333 15 L 13.333 16 C 14.041 16 14.719 15.719 15.219 15.219 L 14.512 14.512 Z M 13.333 15 L 13.333 14 L 1.667 14 L 1.667 15 L 1.667 16 L 13.333 16 L 13.333 15 Z M 1.667 15 L 1.667 14 C 1.49 14 1.32 13.93 1.195 13.805 L 0.488 14.512 L -0.219 15.219 C 0.281 15.719 0.959 16 1.667 16 L 1.667 15 Z M 0.488 14.512 L 1.195 13.805 C 1.07 13.68 1 13.51 1 13.333 L 0 13.333 L -1 13.333 C -1 14.041 -0.719 14.719 -0.219 15.219 L 0.488 14.512 Z M 0 13.333 L 1 13.333 L 1 10 L 0 10 L -1 10 L -1 13.333 L 0 13.333 Z M 3.333 5.833 L 2.626 6.54 L 6.793 10.707 L 7.5 10 L 8.207 9.293 L 4.04 5.126 L 3.333 5.833 Z M 7.5 10 L 8.207 10.707 L 12.374 6.54 L 11.667 5.833 L 10.96 5.126 L 6.793 9.293 L 7.5 10 Z M 7.5 10 L 8.5 10 L 8.5 0 L 7.5 0 L 6.5 0 L 6.5 10 L 7.5 10 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.500 2.500)\"/>"
    },
    "DownloadSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 19.25 12 C 19.25 11.31 18.69 10.75 18 10.75 C 17.31 10.75 16.75 11.31 16.75 12 L 18 12 L 19.25 12 Z M 0 16 L -1.25 16 L 0 16 Z M 1.25 12 C 1.25 11.31 0.69 10.75 0 10.75 C -0.69 10.75 -1.25 11.31 -1.25 12 L 0 12 L 1.25 12 Z M 4.884 6.116 C 4.396 5.628 3.604 5.628 3.116 6.116 C 2.628 6.604 2.628 7.396 3.116 7.884 L 4 7 L 4.884 6.116 Z M 9 12 L 8.116 12.884 C 8.604 13.372 9.396 13.372 9.884 12.884 L 9 12 Z M 14.884 7.884 C 15.372 7.396 15.372 6.604 14.884 6.116 C 14.396 5.628 13.604 5.628 13.116 6.116 L 14 7 L 14.884 7.884 Z M 10.25 0 C 10.25 -0.69 9.69 -1.25 9 -1.25 C 8.31 -1.25 7.75 -0.69 7.75 0 L 9 0 L 10.25 0 Z M 18 12 L 16.75 12 L 16.75 16 L 18 16 L 19.25 16 L 19.25 12 L 18 12 Z M 18 16 L 16.75 16 C 16.75 16.199 16.671 16.39 16.53 16.53 L 17.414 17.414 L 18.298 18.298 C 18.908 17.689 19.25 16.862 19.25 16 L 18 16 Z M 17.414 17.414 L 16.53 16.53 C 16.39 16.671 16.199 16.75 16 16.75 L 16 18 L 16 19.25 C 16.862 19.25 17.689 18.908 18.298 18.298 L 17.414 17.414 Z M 16 18 L 16 16.75 L 2 16.75 L 2 18 L 2 19.25 L 16 19.25 L 16 18 Z M 2 18 L 2 16.75 C 1.801 16.75 1.61 16.671 1.47 16.53 L 0.586 17.414 L -0.298 18.298 C 0.311 18.908 1.138 19.25 2 19.25 L 2 18 Z M 0.586 17.414 L 1.47 16.53 C 1.329 16.39 1.25 16.199 1.25 16 L 0 16 L -1.25 16 C -1.25 16.862 -0.908 17.689 -0.298 18.298 L 0.586 17.414 Z M 0 16 L 1.25 16 L 1.25 12 L 0 12 L -1.25 12 L -1.25 16 L 0 16 Z M 4 7 L 3.116 7.884 L 8.116 12.884 L 9 12 L 9.884 11.116 L 4.884 6.116 L 4 7 Z M 9 12 L 9.884 12.884 L 14.884 7.884 L 14 7 L 13.116 6.116 L 8.116 11.116 L 9 12 Z M 9 12 L 10.25 12 L 10.25 0 L 9 0 L 7.75 0 L 7.75 12 L 9 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "DownloadSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 25.5 16 C 25.5 15.172 24.828 14.5 24 14.5 C 23.172 14.5 22.5 15.172 22.5 16 L 24 16 L 25.5 16 Z M 0 21.333 L -1.5 21.333 L 0 21.333 Z M 1.5 16 C 1.5 15.172 0.828 14.5 0 14.5 C -0.828 14.5 -1.5 15.172 -1.5 16 L 0 16 L 1.5 16 Z M 6.394 8.273 C 5.808 7.687 4.858 7.687 4.273 8.273 C 3.687 8.858 3.687 9.808 4.273 10.394 L 5.333 9.333 L 6.394 8.273 Z M 12 16 L 10.939 17.061 C 11.525 17.646 12.475 17.646 13.061 17.061 L 12 16 Z M 19.727 10.394 C 20.313 9.808 20.313 8.858 19.727 8.273 C 19.142 7.687 18.192 7.687 17.606 8.273 L 18.667 9.333 L 19.727 10.394 Z M 13.5 0 C 13.5 -0.828 12.828 -1.5 12 -1.5 C 11.172 -1.5 10.5 -0.828 10.5 0 L 12 0 L 13.5 0 Z M 24 16 L 22.5 16 L 22.5 21.333 L 24 21.333 L 25.5 21.333 L 25.5 16 L 24 16 Z M 24 21.333 L 22.5 21.333 C 22.5 21.643 22.377 21.94 22.158 22.158 L 23.219 23.219 L 24.28 24.28 C 25.061 23.498 25.5 22.438 25.5 21.333 L 24 21.333 Z M 23.219 23.219 L 22.158 22.158 C 21.94 22.377 21.643 22.5 21.333 22.5 L 21.333 24 L 21.333 25.5 C 22.438 25.5 23.498 25.061 24.28 24.28 L 23.219 23.219 Z M 21.333 24 L 21.333 22.5 L 2.667 22.5 L 2.667 24 L 2.667 25.5 L 21.333 25.5 L 21.333 24 Z M 2.667 24 L 2.667 22.5 C 2.357 22.5 2.061 22.377 1.842 22.158 L 0.781 23.219 L -0.28 24.28 C 0.502 25.061 1.562 25.5 2.667 25.5 L 2.667 24 Z M 0.781 23.219 L 1.842 22.158 C 1.623 21.939 1.5 21.643 1.5 21.333 L 0 21.333 L -1.5 21.333 C -1.5 22.438 -1.061 23.498 -0.28 24.28 L 0.781 23.219 Z M 0 21.333 L 1.5 21.333 L 1.5 16 L 0 16 L -1.5 16 L -1.5 21.333 L 0 21.333 Z M 5.333 9.333 L 4.273 10.394 L 10.939 17.061 L 12 16 L 13.061 14.939 L 6.394 8.273 L 5.333 9.333 Z M 12 16 L 13.061 17.061 L 19.727 10.394 L 18.667 9.333 L 17.606 8.273 L 10.939 14.939 L 12 16 Z M 12 16 L 13.5 16 L 13.5 0 L 12 0 L 10.5 0 L 10.5 16 L 12 16 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "DownloadSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 31.75 20 C 31.75 19.034 30.966 18.25 30 18.25 C 29.034 18.25 28.25 19.034 28.25 20 L 30 20 L 31.75 20 Z M 0 26.667 L -1.75 26.667 L 0 26.667 Z M 1.75 20 C 1.75 19.034 0.966 18.25 0 18.25 C -0.966 18.25 -1.75 19.034 -1.75 20 L 0 20 L 1.75 20 Z M 7.904 10.429 C 7.221 9.746 6.113 9.746 5.429 10.429 C 4.746 11.113 4.746 12.221 5.429 12.904 L 6.667 11.667 L 7.904 10.429 Z M 15 20 L 13.763 21.237 C 14.446 21.921 15.554 21.921 16.237 21.237 L 15 20 Z M 24.571 12.904 C 25.254 12.221 25.254 11.113 24.571 10.429 C 23.887 9.746 22.779 9.746 22.096 10.429 L 23.333 11.667 L 24.571 12.904 Z M 16.75 0 C 16.75 -0.966 15.966 -1.75 15 -1.75 C 14.034 -1.75 13.25 -0.966 13.25 0 L 15 0 L 16.75 0 Z M 30 20 L 28.25 20 L 28.25 26.667 L 30 26.667 L 31.75 26.667 L 31.75 20 L 30 20 Z M 30 26.667 L 28.25 26.667 C 28.25 27.087 28.083 27.489 27.786 27.786 L 29.024 29.024 L 30.261 30.261 C 31.214 29.308 31.75 28.015 31.75 26.667 L 30 26.667 Z M 29.024 29.024 L 27.786 27.786 C 27.489 28.083 27.087 28.25 26.667 28.25 L 26.667 30 L 26.667 31.75 C 28.015 31.75 29.308 31.214 30.261 30.261 L 29.024 29.024 Z M 26.667 30 L 26.667 28.25 L 3.333 28.25 L 3.333 30 L 3.333 31.75 L 26.667 31.75 L 26.667 30 Z M 3.333 30 L 3.333 28.25 C 2.913 28.25 2.511 28.083 2.214 27.786 L 0.976 29.024 L -0.261 30.261 C 0.692 31.214 1.985 31.75 3.333 31.75 L 3.333 30 Z M 0.976 29.024 L 2.214 27.786 C 1.917 27.489 1.75 27.087 1.75 26.667 L 0 26.667 L -1.75 26.667 C -1.75 28.015 -1.214 29.308 -0.261 30.261 L 0.976 29.024 Z M 0 26.667 L 1.75 26.667 L 1.75 20 L 0 20 L -1.75 20 L -1.75 26.667 L 0 26.667 Z M 6.667 11.667 L 5.429 12.904 L 13.763 21.237 L 15 20 L 16.237 18.763 L 7.904 10.429 L 6.667 11.667 Z M 15 20 L 16.237 21.237 L 24.571 12.904 L 23.333 11.667 L 22.096 10.429 L 13.763 18.763 L 15 20 Z M 15 20 L 16.75 20 L 16.75 0 L 15 0 L 13.25 0 L 13.25 20 L 15 20 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "DownloadSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 38 24 C 38 22.895 37.105 22 36 22 C 34.895 22 34 22.895 34 24 L 36 24 L 38 24 Z M 0 32 L -2 32 L 0 32 Z M 2 24 C 2 22.895 1.105 22 0 22 C -1.105 22 -2 22.895 -2 24 L 0 24 L 2 24 Z M 9.414 12.586 C 8.633 11.805 7.367 11.805 6.586 12.586 C 5.805 13.367 5.805 14.633 6.586 15.414 L 8 14 L 9.414 12.586 Z M 18 24 L 16.586 25.414 C 17.367 26.195 18.633 26.195 19.414 25.414 L 18 24 Z M 29.414 15.414 C 30.195 14.633 30.195 13.367 29.414 12.586 C 28.633 11.805 27.367 11.805 26.586 12.586 L 28 14 L 29.414 15.414 Z M 20 0 C 20 -1.105 19.105 -2 18 -2 C 16.895 -2 16 -1.105 16 0 L 18 0 L 20 0 Z M 36 24 L 34 24 L 34 32 L 36 32 L 38 32 L 38 24 L 36 24 Z M 36 32 L 34 32 C 34 32.53 33.789 33.039 33.414 33.414 L 34.828 34.828 L 36.243 36.243 C 37.368 35.117 38 33.591 38 32 L 36 32 Z M 34.828 34.828 L 33.414 33.414 C 33.039 33.789 32.53 34 32 34 L 32 36 L 32 38 C 33.591 38 35.117 37.368 36.243 36.243 L 34.828 34.828 Z M 32 36 L 32 34 L 4 34 L 4 36 L 4 38 L 32 38 L 32 36 Z M 4 36 L 4 34 C 3.47 34 2.961 33.789 2.586 33.414 L 1.172 34.828 L -0.243 36.243 C 0.883 37.368 2.409 38 4 38 L 4 36 Z M 1.172 34.828 L 2.586 33.414 C 2.211 33.039 2 32.53 2 32 L 0 32 L -2 32 C -2 33.591 -1.368 35.117 -0.243 36.243 L 1.172 34.828 Z M 0 32 L 2 32 L 2 24 L 0 24 L -2 24 L -2 32 L 0 32 Z M 8 14 L 6.586 15.414 L 16.586 25.414 L 18 24 L 19.414 22.586 L 9.414 12.586 L 8 14 Z M 18 24 L 19.414 25.414 L 29.414 15.414 L 28 14 L 26.586 12.586 L 16.586 22.586 L 18 24 Z M 18 24 L 20 24 L 20 0 L 18 0 L 16 0 L 16 24 L 18 24 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    },
    "FileTextSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 6.667 0 L 7.232 -0.566 C 7.082 -0.716 6.879 -0.8 6.667 -0.8 L 6.667 0 Z M 1.333 0 L 1.333 -0.8 L 1.333 0 Z M 0 1.333 L -0.8 1.333 L 0 1.333 Z M 0 12 L -0.8 12 L 0 12 Z M 10.667 4 L 11.467 4 C 11.467 3.788 11.382 3.584 11.232 3.434 L 10.667 4 Z M 6.667 4 L 5.867 4 C 5.867 4.442 6.225 4.8 6.667 4.8 L 6.667 4 Z M 8 8.133 C 8.442 8.133 8.8 7.775 8.8 7.333 C 8.8 6.892 8.442 6.533 8 6.533 L 8 7.333 L 8 8.133 Z M 2.667 6.533 C 2.225 6.533 1.867 6.892 1.867 7.333 C 1.867 7.775 2.225 8.133 2.667 8.133 L 2.667 7.333 L 2.667 6.533 Z M 8 10.8 C 8.442 10.8 8.8 10.442 8.8 10 C 8.8 9.558 8.442 9.2 8 9.2 L 8 10 L 8 10.8 Z M 2.667 9.2 C 2.225 9.2 1.867 9.558 1.867 10 C 1.867 10.442 2.225 10.8 2.667 10.8 L 2.667 10 L 2.667 9.2 Z M 4 5.467 C 4.442 5.467 4.8 5.108 4.8 4.667 C 4.8 4.225 4.442 3.867 4 3.867 L 4 4.667 L 4 5.467 Z M 2.667 3.867 C 2.225 3.867 1.867 4.225 1.867 4.667 C 1.867 5.108 2.225 5.467 2.667 5.467 L 2.667 4.667 L 2.667 3.867 Z M 6.667 0 L 6.667 -0.8 L 1.333 -0.8 L 1.333 0 L 1.333 0.8 L 6.667 0.8 L 6.667 0 Z M 1.333 0 L 1.333 -0.8 C 0.768 -0.8 0.225 -0.575 -0.175 -0.175 L 0.391 0.391 L 0.956 0.956 C 1.056 0.856 1.192 0.8 1.333 0.8 L 1.333 0 Z M 0.391 0.391 L -0.175 -0.175 C -0.575 0.225 -0.8 0.768 -0.8 1.333 L 0 1.333 L 0.8 1.333 C 0.8 1.192 0.856 1.056 0.956 0.956 L 0.391 0.391 Z M 0 1.333 L -0.8 1.333 L -0.8 12 L 0 12 L 0.8 12 L 0.8 1.333 L 0 1.333 Z M 0 12 L -0.8 12 C -0.8 12.566 -0.575 13.108 -0.175 13.508 L 0.391 12.943 L 0.956 12.377 C 0.856 12.277 0.8 12.141 0.8 12 L 0 12 Z M 0.391 12.943 L -0.175 13.508 C 0.225 13.909 0.768 14.133 1.333 14.133 L 1.333 13.333 L 1.333 12.533 C 1.192 12.533 1.056 12.477 0.956 12.377 L 0.391 12.943 Z M 1.333 13.333 L 1.333 14.133 L 9.333 14.133 L 9.333 13.333 L 9.333 12.533 L 1.333 12.533 L 1.333 13.333 Z M 9.333 13.333 L 9.333 14.133 C 9.899 14.133 10.442 13.909 10.842 13.508 L 10.276 12.943 L 9.71 12.377 C 9.61 12.477 9.475 12.533 9.333 12.533 L 9.333 13.333 Z M 10.276 12.943 L 10.842 13.508 C 11.242 13.108 11.467 12.566 11.467 12 L 10.667 12 L 9.867 12 C 9.867 12.141 9.81 12.277 9.71 12.377 L 10.276 12.943 Z M 10.667 12 L 11.467 12 L 11.467 4 L 10.667 4 L 9.867 4 L 9.867 12 L 10.667 12 Z M 10.667 4 L 11.232 3.434 L 7.232 -0.566 L 6.667 0 L 6.101 0.566 L 10.101 4.566 L 10.667 4 Z M 6.667 0 L 5.867 0 L 5.867 4 L 6.667 4 L 7.467 4 L 7.467 0 L 6.667 0 Z M 6.667 4 L 6.667 4.8 L 10.667 4.8 L 10.667 4 L 10.667 3.2 L 6.667 3.2 L 6.667 4 Z M 8 7.333 L 8 6.533 L 2.667 6.533 L 2.667 7.333 L 2.667 8.133 L 8 8.133 L 8 7.333 Z M 8 10 L 8 9.2 L 2.667 9.2 L 2.667 10 L 2.667 10.8 L 8 10.8 L 8 10 Z M 4 4.667 L 4 3.867 L 2.667 3.867 L 2.667 4.667 L 2.667 5.467 L 4 5.467 L 4 4.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 1.333)\"/>"
    },
    "FileTextSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 8.333 0 L 9.04 -0.707 C 8.853 -0.895 8.599 -1 8.333 -1 L 8.333 0 Z M 1.667 0 L 1.667 -1 L 1.667 0 Z M 0 1.667 L -1 1.667 L 0 1.667 Z M 0 15 L -1 15 L 0 15 Z M 13.333 5 L 14.333 5 C 14.333 4.735 14.228 4.48 14.04 4.293 L 13.333 5 Z M 8.333 5 L 7.333 5 C 7.333 5.552 7.781 6 8.333 6 L 8.333 5 Z M 10 10.167 C 10.552 10.167 11 9.719 11 9.167 C 11 8.614 10.552 8.167 10 8.167 L 10 9.167 L 10 10.167 Z M 3.333 8.167 C 2.781 8.167 2.333 8.614 2.333 9.167 C 2.333 9.719 2.781 10.167 3.333 10.167 L 3.333 9.167 L 3.333 8.167 Z M 10 13.5 C 10.552 13.5 11 13.052 11 12.5 C 11 11.948 10.552 11.5 10 11.5 L 10 12.5 L 10 13.5 Z M 3.333 11.5 C 2.781 11.5 2.333 11.948 2.333 12.5 C 2.333 13.052 2.781 13.5 3.333 13.5 L 3.333 12.5 L 3.333 11.5 Z M 5 6.833 C 5.552 6.833 6 6.386 6 5.833 C 6 5.281 5.552 4.833 5 4.833 L 5 5.833 L 5 6.833 Z M 3.333 4.833 C 2.781 4.833 2.333 5.281 2.333 5.833 C 2.333 6.386 2.781 6.833 3.333 6.833 L 3.333 5.833 L 3.333 4.833 Z M 8.333 0 L 8.333 -1 L 1.667 -1 L 1.667 0 L 1.667 1 L 8.333 1 L 8.333 0 Z M 1.667 0 L 1.667 -1 C 0.959 -1 0.281 -0.719 -0.219 -0.219 L 0.488 0.488 L 1.195 1.195 C 1.32 1.07 1.49 1 1.667 1 L 1.667 0 Z M 0.488 0.488 L -0.219 -0.219 C -0.719 0.281 -1 0.959 -1 1.667 L 0 1.667 L 1 1.667 C 1 1.49 1.07 1.32 1.195 1.195 L 0.488 0.488 Z M 0 1.667 L -1 1.667 L -1 15 L 0 15 L 1 15 L 1 1.667 L 0 1.667 Z M 0 15 L -1 15 C -1 15.707 -0.719 16.386 -0.219 16.886 L 0.488 16.179 L 1.195 15.471 C 1.07 15.346 1 15.177 1 15 L 0 15 Z M 0.488 16.179 L -0.219 16.886 C 0.281 17.386 0.959 17.667 1.667 17.667 L 1.667 16.667 L 1.667 15.667 C 1.49 15.667 1.32 15.596 1.195 15.471 L 0.488 16.179 Z M 1.667 16.667 L 1.667 17.667 L 11.667 17.667 L 11.667 16.667 L 11.667 15.667 L 1.667 15.667 L 1.667 16.667 Z M 11.667 16.667 L 11.667 17.667 C 12.374 17.667 13.052 17.386 13.552 16.886 L 12.845 16.179 L 12.138 15.471 C 12.013 15.596 11.843 15.667 11.667 15.667 L 11.667 16.667 Z M 12.845 16.179 L 13.552 16.886 C 14.052 16.386 14.333 15.707 14.333 15 L 13.333 15 L 12.333 15 C 12.333 15.177 12.263 15.346 12.138 15.471 L 12.845 16.179 Z M 13.333 15 L 14.333 15 L 14.333 5 L 13.333 5 L 12.333 5 L 12.333 15 L 13.333 15 Z M 13.333 5 L 14.04 4.293 L 9.04 -0.707 L 8.333 0 L 7.626 0.707 L 12.626 5.707 L 13.333 5 Z M 8.333 0 L 7.333 0 L 7.333 5 L 8.333 5 L 9.333 5 L 9.333 0 L 8.333 0 Z M 8.333 5 L 8.333 6 L 13.333 6 L 13.333 5 L 13.333 4 L 8.333 4 L 8.333 5 Z M 10 9.167 L 10 8.167 L 3.333 8.167 L 3.333 9.167 L 3.333 10.167 L 10 10.167 L 10 9.167 Z M 10 12.5 L 10 11.5 L 3.333 11.5 L 3.333 12.5 L 3.333 13.5 L 10 13.5 L 10 12.5 Z M 5 5.833 L 5 4.833 L 3.333 4.833 L 3.333 5.833 L 3.333 6.833 L 5 6.833 L 5 5.833 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.333 1.667)\"/>"
    },
    "FileTextSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 L 10.884 -0.884 C 10.649 -1.118 10.332 -1.25 10 -1.25 L 10 0 Z M 2 0 L 2 -1.25 L 2 0 Z M 0 2 L -1.25 2 L 0 2 Z M 0 18 L -1.25 18 L 0 18 Z M 16 6 L 17.25 6 C 17.25 5.668 17.118 5.351 16.884 5.116 L 16 6 Z M 10 6 L 8.75 6 C 8.75 6.69 9.31 7.25 10 7.25 L 10 6 Z M 12 12.25 C 12.69 12.25 13.25 11.69 13.25 11 C 13.25 10.31 12.69 9.75 12 9.75 L 12 11 L 12 12.25 Z M 4 9.75 C 3.31 9.75 2.75 10.31 2.75 11 C 2.75 11.69 3.31 12.25 4 12.25 L 4 11 L 4 9.75 Z M 12 16.25 C 12.69 16.25 13.25 15.69 13.25 15 C 13.25 14.31 12.69 13.75 12 13.75 L 12 15 L 12 16.25 Z M 4 13.75 C 3.31 13.75 2.75 14.31 2.75 15 C 2.75 15.69 3.31 16.25 4 16.25 L 4 15 L 4 13.75 Z M 6 8.25 C 6.69 8.25 7.25 7.69 7.25 7 C 7.25 6.31 6.69 5.75 6 5.75 L 6 7 L 6 8.25 Z M 4 5.75 C 3.31 5.75 2.75 6.31 2.75 7 C 2.75 7.69 3.31 8.25 4 8.25 L 4 7 L 4 5.75 Z M 10 0 L 10 -1.25 L 2 -1.25 L 2 0 L 2 1.25 L 10 1.25 L 10 0 Z M 2 0 L 2 -1.25 C 1.138 -1.25 0.311 -0.908 -0.298 -0.298 L 0.586 0.586 L 1.47 1.47 C 1.61 1.329 1.801 1.25 2 1.25 L 2 0 Z M 0.586 0.586 L -0.298 -0.298 C -0.908 0.311 -1.25 1.138 -1.25 2 L 0 2 L 1.25 2 C 1.25 1.801 1.329 1.61 1.47 1.47 L 0.586 0.586 Z M 0 2 L -1.25 2 L -1.25 18 L 0 18 L 1.25 18 L 1.25 2 L 0 2 Z M 0 18 L -1.25 18 C -1.25 18.862 -0.908 19.689 -0.298 20.298 L 0.586 19.414 L 1.47 18.53 C 1.329 18.39 1.25 18.199 1.25 18 L 0 18 Z M 0.586 19.414 L -0.298 20.298 C 0.311 20.908 1.138 21.25 2 21.25 L 2 20 L 2 18.75 C 1.801 18.75 1.61 18.671 1.47 18.53 L 0.586 19.414 Z M 2 20 L 2 21.25 L 14 21.25 L 14 20 L 14 18.75 L 2 18.75 L 2 20 Z M 14 20 L 14 21.25 C 14.862 21.25 15.689 20.908 16.298 20.298 L 15.414 19.414 L 14.53 18.53 C 14.39 18.671 14.199 18.75 14 18.75 L 14 20 Z M 15.414 19.414 L 16.298 20.298 C 16.908 19.689 17.25 18.862 17.25 18 L 16 18 L 14.75 18 C 14.75 18.199 14.671 18.39 14.53 18.53 L 15.414 19.414 Z M 16 18 L 17.25 18 L 17.25 6 L 16 6 L 14.75 6 L 14.75 18 L 16 18 Z M 16 6 L 16.884 5.116 L 10.884 -0.884 L 10 0 L 9.116 0.884 L 15.116 6.884 L 16 6 Z M 10 0 L 8.75 0 L 8.75 6 L 10 6 L 11.25 6 L 11.25 0 L 10 0 Z M 10 6 L 10 7.25 L 16 7.25 L 16 6 L 16 4.75 L 10 4.75 L 10 6 Z M 12 11 L 12 9.75 L 4 9.75 L 4 11 L 4 12.25 L 12 12.25 L 12 11 Z M 12 15 L 12 13.75 L 4 13.75 L 4 15 L 4 16.25 L 12 16.25 L 12 15 Z M 6 7 L 6 5.75 L 4 5.75 L 4 7 L 4 8.25 L 6 8.25 L 6 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2)\"/>"
    },
    "FileTextSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 13.333 0 L 14.394 -1.061 C 14.113 -1.342 13.731 -1.5 13.333 -1.5 L 13.333 0 Z M 2.667 0 L 2.667 -1.5 L 2.667 0 Z M 0 2.667 L -1.5 2.667 L 0 2.667 Z M 0 24 L -1.5 24 L 0 24 Z M 21.333 8 L 22.833 8 C 22.833 7.602 22.675 7.221 22.394 6.939 L 21.333 8 Z M 13.333 8 L 11.833 8 C 11.833 8.398 11.991 8.779 12.273 9.061 C 12.554 9.342 12.936 9.5 13.333 9.5 L 13.333 8 Z M 16 16.167 C 16.828 16.167 17.5 15.495 17.5 14.667 C 17.5 13.838 16.828 13.167 16 13.167 L 16 14.667 L 16 16.167 Z M 5.333 13.167 C 4.505 13.167 3.833 13.838 3.833 14.667 C 3.833 15.495 4.505 16.167 5.333 16.167 L 5.333 14.667 L 5.333 13.167 Z M 16 21.5 C 16.828 21.5 17.5 20.828 17.5 20 C 17.5 19.172 16.828 18.5 16 18.5 L 16 20 L 16 21.5 Z M 5.333 18.5 C 4.505 18.5 3.833 19.172 3.833 20 C 3.833 20.828 4.505 21.5 5.333 21.5 L 5.333 20 L 5.333 18.5 Z M 8 10.833 C 8.828 10.833 9.5 10.162 9.5 9.333 C 9.5 8.505 8.828 7.833 8 7.833 L 8 9.333 L 8 10.833 Z M 5.333 7.833 C 4.505 7.833 3.833 8.505 3.833 9.333 C 3.833 10.162 4.505 10.833 5.333 10.833 L 5.333 9.333 L 5.333 7.833 Z M 13.333 0 L 13.333 -1.5 L 2.667 -1.5 L 2.667 0 L 2.667 1.5 L 13.333 1.5 L 13.333 0 Z M 2.667 0 L 2.667 -1.5 C 1.562 -1.5 0.502 -1.061 -0.28 -0.28 L 0.781 0.781 L 1.842 1.842 C 2.061 1.623 2.357 1.5 2.667 1.5 L 2.667 0 Z M 0.781 0.781 L -0.28 -0.28 C -1.061 0.502 -1.5 1.562 -1.5 2.667 L 0 2.667 L 1.5 2.667 C 1.5 2.357 1.623 2.061 1.842 1.842 L 0.781 0.781 Z M 0 2.667 L -1.5 2.667 L -1.5 24 L 0 24 L 1.5 24 L 1.5 2.667 L 0 2.667 Z M 0 24 L -1.5 24 C -1.5 25.105 -1.061 26.165 -0.28 26.946 L 0.781 25.886 L 1.842 24.825 C 1.623 24.606 1.5 24.309 1.5 24 L 0 24 Z M 0.781 25.886 L -0.28 26.946 C 0.502 27.728 1.562 28.167 2.667 28.167 L 2.667 26.667 L 2.667 25.167 C 2.357 25.167 2.061 25.044 1.842 24.825 L 0.781 25.886 Z M 2.667 26.667 L 2.667 28.167 L 18.667 28.167 L 18.667 26.667 L 18.667 25.167 L 2.667 25.167 L 2.667 26.667 Z M 18.667 26.667 L 18.667 28.167 C 19.772 28.167 20.832 27.728 21.613 26.946 L 20.552 25.886 L 19.492 24.825 C 19.273 25.044 18.976 25.167 18.667 25.167 L 18.667 26.667 Z M 20.552 25.886 L 21.613 26.946 C 22.394 26.165 22.833 25.105 22.833 24 L 21.333 24 L 19.833 24 C 19.833 24.309 19.71 24.606 19.492 24.825 L 20.552 25.886 Z M 21.333 24 L 22.833 24 L 22.833 8 L 21.333 8 L 19.833 8 L 19.833 24 L 21.333 24 Z M 21.333 8 L 22.394 6.939 L 14.394 -1.061 L 13.333 0 L 12.273 1.061 L 20.273 9.061 L 21.333 8 Z M 13.333 0 L 11.833 0 L 11.833 8 L 13.333 8 L 14.833 8 L 14.833 0 L 13.333 0 Z M 13.333 8 L 13.333 9.5 L 21.333 9.5 L 21.333 8 L 21.333 6.5 L 13.333 6.5 L 13.333 8 Z M 16 14.667 L 16 13.167 L 5.333 13.167 L 5.333 14.667 L 5.333 16.167 L 16 16.167 L 16 14.667 Z M 16 20 L 16 18.5 L 5.333 18.5 L 5.333 20 L 5.333 21.5 L 16 21.5 L 16 20 Z M 8 9.333 L 8 7.833 L 5.333 7.833 L 5.333 9.333 L 5.333 10.833 L 8 10.833 L 8 9.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.333 2.667)\"/>"
    },
    "FileTextSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 16.667 0 L 17.904 -1.237 C 17.576 -1.566 17.131 -1.75 16.667 -1.75 L 16.667 0 Z M 3.333 0 L 3.333 -1.75 L 3.333 0 Z M 0 3.333 L -1.75 3.333 L 0 3.333 Z M 0 30 L -1.75 30 L 0 30 Z M 26.667 10 L 28.417 10 C 28.417 9.536 28.232 9.091 27.904 8.763 L 26.667 10 Z M 16.667 10 L 14.917 10 C 14.917 10.966 15.7 11.75 16.667 11.75 L 16.667 10 Z M 20 20.083 C 20.966 20.083 21.75 19.3 21.75 18.333 C 21.75 17.367 20.966 16.583 20 16.583 L 20 18.333 L 20 20.083 Z M 6.667 16.583 C 5.7 16.583 4.917 17.367 4.917 18.333 C 4.917 19.3 5.7 20.083 6.667 20.083 L 6.667 18.333 L 6.667 16.583 Z M 20 26.75 C 20.966 26.75 21.75 25.966 21.75 25 C 21.75 24.034 20.966 23.25 20 23.25 L 20 25 L 20 26.75 Z M 6.667 23.25 C 5.7 23.25 4.917 24.034 4.917 25 C 4.917 25.966 5.7 26.75 6.667 26.75 L 6.667 25 L 6.667 23.25 Z M 10 13.417 C 10.966 13.417 11.75 12.633 11.75 11.667 C 11.75 10.7 10.966 9.917 10 9.917 L 10 11.667 L 10 13.417 Z M 6.667 9.917 C 5.7 9.917 4.917 10.7 4.917 11.667 C 4.917 12.633 5.7 13.417 6.667 13.417 L 6.667 11.667 L 6.667 9.917 Z M 16.667 0 L 16.667 -1.75 L 3.333 -1.75 L 3.333 0 L 3.333 1.75 L 16.667 1.75 L 16.667 0 Z M 3.333 0 L 3.333 -1.75 C 1.985 -1.75 0.692 -1.214 -0.261 -0.261 L 0.976 0.976 L 2.214 2.214 C 2.511 1.917 2.913 1.75 3.333 1.75 L 3.333 0 Z M 0.976 0.976 L -0.261 -0.261 C -1.214 0.692 -1.75 1.985 -1.75 3.333 L 0 3.333 L 1.75 3.333 C 1.75 2.913 1.917 2.511 2.214 2.214 L 0.976 0.976 Z M 0 3.333 L -1.75 3.333 L -1.75 30 L 0 30 L 1.75 30 L 1.75 3.333 L 0 3.333 Z M 0 30 L -1.75 30 C -1.75 31.348 -1.214 32.641 -0.261 33.594 L 0.976 32.357 L 2.214 31.12 C 1.917 30.823 1.75 30.42 1.75 30 L 0 30 Z M 0.976 32.357 L -0.261 33.594 C 0.692 34.548 1.985 35.083 3.333 35.083 L 3.333 33.333 L 3.333 31.583 C 2.913 31.583 2.511 31.417 2.214 31.12 L 0.976 32.357 Z M 3.333 33.333 L 3.333 35.083 L 23.333 35.083 L 23.333 33.333 L 23.333 31.583 L 3.333 31.583 L 3.333 33.333 Z M 23.333 33.333 L 23.333 35.083 C 24.682 35.083 25.974 34.548 26.928 33.594 L 25.69 32.357 L 24.453 31.12 C 24.156 31.417 23.753 31.583 23.333 31.583 L 23.333 33.333 Z M 25.69 32.357 L 26.928 33.594 C 27.881 32.641 28.417 31.348 28.417 30 L 26.667 30 L 24.917 30 C 24.917 30.42 24.75 30.823 24.453 31.12 L 25.69 32.357 Z M 26.667 30 L 28.417 30 L 28.417 10 L 26.667 10 L 24.917 10 L 24.917 30 L 26.667 30 Z M 26.667 10 L 27.904 8.763 L 17.904 -1.237 L 16.667 0 L 15.429 1.237 L 25.429 11.237 L 26.667 10 Z M 16.667 0 L 14.917 0 L 14.917 10 L 16.667 10 L 18.417 10 L 18.417 0 L 16.667 0 Z M 16.667 10 L 16.667 11.75 L 26.667 11.75 L 26.667 10 L 26.667 8.25 L 16.667 8.25 L 16.667 10 Z M 20 18.333 L 20 16.583 L 6.667 16.583 L 6.667 18.333 L 6.667 20.083 L 20 20.083 L 20 18.333 Z M 20 25 L 20 23.25 L 6.667 23.25 L 6.667 25 L 6.667 26.75 L 20 26.75 L 20 25 Z M 10 11.667 L 10 9.917 L 6.667 9.917 L 6.667 11.667 L 6.667 13.417 L 10 13.417 L 10 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6.667 3.333)\"/>"
    },
    "FileTextSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 20 0 L 21.414 -1.414 C 21.039 -1.789 20.53 -2 20 -2 L 20 0 Z M 4 0 L 4 -2 L 4 0 Z M 0 4 L -2 4 L 0 4 Z M 0 36 L -2 36 L 0 36 Z M 32 12 L 34 12 C 34 11.47 33.789 10.961 33.414 10.586 L 32 12 Z M 20 12 L 18 12 C 18 13.105 18.895 14 20 14 L 20 12 Z M 24 24 C 25.105 24 26 23.105 26 22 C 26 20.895 25.105 20 24 20 L 24 22 L 24 24 Z M 8 20 C 6.895 20 6 20.895 6 22 C 6 23.105 6.895 24 8 24 L 8 22 L 8 20 Z M 24 32 C 25.105 32 26 31.105 26 30 C 26 28.895 25.105 28 24 28 L 24 30 L 24 32 Z M 8 28 C 6.895 28 6 28.895 6 30 C 6 31.105 6.895 32 8 32 L 8 30 L 8 28 Z M 12 16 C 13.105 16 14 15.105 14 14 C 14 12.895 13.105 12 12 12 L 12 14 L 12 16 Z M 8 12 C 6.895 12 6 12.895 6 14 C 6 15.105 6.895 16 8 16 L 8 14 L 8 12 Z M 20 0 L 20 -2 L 4 -2 L 4 0 L 4 2 L 20 2 L 20 0 Z M 4 0 L 4 -2 C 2.409 -2 0.883 -1.368 -0.243 -0.243 L 1.172 1.172 L 2.586 2.586 C 2.961 2.211 3.47 2 4 2 L 4 0 Z M 1.172 1.172 L -0.243 -0.243 C -1.368 0.883 -2 2.409 -2 4 L 0 4 L 2 4 C 2 3.47 2.211 2.961 2.586 2.586 L 1.172 1.172 Z M 0 4 L -2 4 L -2 36 L 0 36 L 2 36 L 2 4 L 0 4 Z M 0 36 L -2 36 C -2 37.591 -1.368 39.117 -0.243 40.243 L 1.172 38.828 L 2.586 37.414 C 2.211 37.039 2 36.53 2 36 L 0 36 Z M 1.172 38.828 L -0.243 40.243 C 0.883 41.368 2.409 42 4 42 L 4 40 L 4 38 C 3.47 38 2.961 37.789 2.586 37.414 L 1.172 38.828 Z M 4 40 L 4 42 L 28 42 L 28 40 L 28 38 L 4 38 L 4 40 Z M 28 40 L 28 42 C 29.591 42 31.117 41.368 32.243 40.243 L 30.828 38.828 L 29.414 37.414 C 29.039 37.789 28.53 38 28 38 L 28 40 Z M 30.828 38.828 L 32.243 40.243 C 33.368 39.117 34 37.591 34 36 L 32 36 L 30 36 C 30 36.53 29.789 37.039 29.414 37.414 L 30.828 38.828 Z M 32 36 L 34 36 L 34 12 L 32 12 L 30 12 L 30 36 L 32 36 Z M 32 12 L 33.414 10.586 L 21.414 -1.414 L 20 0 L 18.586 1.414 L 30.586 13.414 L 32 12 Z M 20 0 L 18 0 L 18 12 L 20 12 L 22 12 L 22 0 L 20 0 Z M 20 12 L 20 14 L 32 14 L 32 12 L 32 10 L 20 10 L 20 12 Z M 24 22 L 24 20 L 8 20 L 8 22 L 8 24 L 24 24 L 24 22 Z M 24 30 L 24 28 L 8 28 L 8 30 L 8 32 L 24 32 L 24 30 Z M 12 14 L 12 12 L 8 12 L 8 14 L 8 16 L 12 16 L 12 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 4)\"/>"
    },
    "LoaderSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 7.467 0 C 7.467 -0.442 7.108 -0.8 6.667 -0.8 C 6.225 -0.8 5.867 -0.442 5.867 0 L 6.667 0 L 7.467 0 Z M 5.867 2.667 C 5.867 3.108 6.225 3.467 6.667 3.467 C 7.108 3.467 7.467 3.108 7.467 2.667 L 6.667 2.667 L 5.867 2.667 Z M 7.467 10.667 C 7.467 10.225 7.108 9.867 6.667 9.867 C 6.225 9.867 5.867 10.225 5.867 10.667 L 6.667 10.667 L 7.467 10.667 Z M 5.867 13.333 C 5.867 13.775 6.225 14.133 6.667 14.133 C 7.108 14.133 7.467 13.775 7.467 13.333 L 6.667 13.333 L 5.867 13.333 Z M 2.519 1.388 C 2.207 1.075 1.7 1.075 1.388 1.388 C 1.075 1.7 1.075 2.207 1.388 2.519 L 1.953 1.953 L 2.519 1.388 Z M 3.274 4.406 C 3.587 4.718 4.093 4.718 4.406 4.406 C 4.718 4.093 4.718 3.587 4.406 3.274 L 3.84 3.84 L 3.274 4.406 Z M 10.059 8.928 C 9.747 8.615 9.24 8.615 8.928 8.928 C 8.615 9.24 8.615 9.747 8.928 10.059 L 9.493 9.493 L 10.059 8.928 Z M 10.814 11.946 C 11.127 12.258 11.633 12.258 11.946 11.946 C 12.258 11.633 12.258 11.127 11.946 10.814 L 11.38 11.38 L 10.814 11.946 Z M 0 5.867 C -0.442 5.867 -0.8 6.225 -0.8 6.667 C -0.8 7.108 -0.442 7.467 0 7.467 L 0 6.667 L 0 5.867 Z M 2.667 7.467 C 3.108 7.467 3.467 7.108 3.467 6.667 C 3.467 6.225 3.108 5.867 2.667 5.867 L 2.667 6.667 L 2.667 7.467 Z M 10.667 5.867 C 10.225 5.867 9.867 6.225 9.867 6.667 C 9.867 7.108 10.225 7.467 10.667 7.467 L 10.667 6.667 L 10.667 5.867 Z M 13.333 7.467 C 13.775 7.467 14.133 7.108 14.133 6.667 C 14.133 6.225 13.775 5.867 13.333 5.867 L 13.333 6.667 L 13.333 7.467 Z M 1.388 10.814 C 1.075 11.127 1.075 11.633 1.388 11.946 C 1.7 12.258 2.207 12.258 2.519 11.946 L 1.953 11.38 L 1.388 10.814 Z M 4.406 10.059 C 4.718 9.747 4.718 9.24 4.406 8.928 C 4.093 8.615 3.587 8.615 3.274 8.928 L 3.84 9.493 L 4.406 10.059 Z M 8.928 3.274 C 8.615 3.587 8.615 4.093 8.928 4.406 C 9.24 4.718 9.747 4.718 10.059 4.406 L 9.493 3.84 L 8.928 3.274 Z M 11.946 2.519 C 12.258 2.207 12.258 1.7 11.946 1.388 C 11.633 1.075 11.127 1.075 10.814 1.388 L 11.38 1.953 L 11.946 2.519 Z M 6.667 0 L 5.867 0 L 5.867 2.667 L 6.667 2.667 L 7.467 2.667 L 7.467 0 L 6.667 0 Z M 6.667 10.667 L 5.867 10.667 L 5.867 13.333 L 6.667 13.333 L 7.467 13.333 L 7.467 10.667 L 6.667 10.667 Z M 1.953 1.953 L 1.388 2.519 L 3.274 4.406 L 3.84 3.84 L 4.406 3.274 L 2.519 1.388 L 1.953 1.953 Z M 9.493 9.493 L 8.928 10.059 L 10.814 11.946 L 11.38 11.38 L 11.946 10.814 L 10.059 8.928 L 9.493 9.493 Z M 0 6.667 L 0 7.467 L 2.667 7.467 L 2.667 6.667 L 2.667 5.867 L 0 5.867 L 0 6.667 Z M 10.667 6.667 L 10.667 7.467 L 13.333 7.467 L 13.333 6.667 L 13.333 5.867 L 10.667 5.867 L 10.667 6.667 Z M 1.953 11.38 L 2.519 11.946 L 4.406 10.059 L 3.84 9.493 L 3.274 8.928 L 1.388 10.814 L 1.953 11.38 Z M 9.493 3.84 L 10.059 4.406 L 11.946 2.519 L 11.38 1.953 L 10.814 1.388 L 8.928 3.274 L 9.493 3.84 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333)\"/>"
    },
    "LoaderSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 9.333 0 C 9.333 -0.552 8.886 -1 8.333 -1 C 7.781 -1 7.333 -0.552 7.333 0 L 8.333 0 L 9.333 0 Z M 7.333 3.333 C 7.333 3.886 7.781 4.333 8.333 4.333 C 8.886 4.333 9.333 3.886 9.333 3.333 L 8.333 3.333 L 7.333 3.333 Z M 9.333 13.333 C 9.333 12.781 8.886 12.333 8.333 12.333 C 7.781 12.333 7.333 12.781 7.333 13.333 L 8.333 13.333 L 9.333 13.333 Z M 7.333 16.667 C 7.333 17.219 7.781 17.667 8.333 17.667 C 8.886 17.667 9.333 17.219 9.333 16.667 L 8.333 16.667 L 7.333 16.667 Z M 3.149 1.735 C 2.758 1.344 2.125 1.344 1.735 1.735 C 1.344 2.125 1.344 2.758 1.735 3.149 L 2.442 2.442 L 3.149 1.735 Z M 4.093 5.507 C 4.483 5.898 5.117 5.898 5.507 5.507 C 5.898 5.117 5.898 4.483 5.507 4.093 L 4.8 4.8 L 4.093 5.507 Z M 12.574 11.16 C 12.183 10.769 11.55 10.769 11.16 11.16 C 10.769 11.55 10.769 12.183 11.16 12.574 L 11.867 11.867 L 12.574 11.16 Z M 13.518 14.932 C 13.908 15.323 14.542 15.323 14.932 14.932 C 15.323 14.542 15.323 13.908 14.932 13.518 L 14.225 14.225 L 13.518 14.932 Z M 0 7.333 C -0.552 7.333 -1 7.781 -1 8.333 C -1 8.886 -0.552 9.333 0 9.333 L 0 8.333 L 0 7.333 Z M 3.333 9.333 C 3.886 9.333 4.333 8.886 4.333 8.333 C 4.333 7.781 3.886 7.333 3.333 7.333 L 3.333 8.333 L 3.333 9.333 Z M 13.333 7.333 C 12.781 7.333 12.333 7.781 12.333 8.333 C 12.333 8.886 12.781 9.333 13.333 9.333 L 13.333 8.333 L 13.333 7.333 Z M 16.667 9.333 C 17.219 9.333 17.667 8.886 17.667 8.333 C 17.667 7.781 17.219 7.333 16.667 7.333 L 16.667 8.333 L 16.667 9.333 Z M 1.735 13.518 C 1.344 13.908 1.344 14.542 1.735 14.932 C 2.125 15.323 2.758 15.323 3.149 14.932 L 2.442 14.225 L 1.735 13.518 Z M 5.507 12.574 C 5.898 12.183 5.898 11.55 5.507 11.16 C 5.117 10.769 4.483 10.769 4.093 11.16 L 4.8 11.867 L 5.507 12.574 Z M 11.16 4.093 C 10.769 4.483 10.769 5.117 11.16 5.507 C 11.55 5.898 12.183 5.898 12.574 5.507 L 11.867 4.8 L 11.16 4.093 Z M 14.932 3.149 C 15.323 2.758 15.323 2.125 14.932 1.735 C 14.542 1.344 13.908 1.344 13.518 1.735 L 14.225 2.442 L 14.932 3.149 Z M 8.333 0 L 7.333 0 L 7.333 3.333 L 8.333 3.333 L 9.333 3.333 L 9.333 0 L 8.333 0 Z M 8.333 13.333 L 7.333 13.333 L 7.333 16.667 L 8.333 16.667 L 9.333 16.667 L 9.333 13.333 L 8.333 13.333 Z M 2.442 2.442 L 1.735 3.149 L 4.093 5.507 L 4.8 4.8 L 5.507 4.093 L 3.149 1.735 L 2.442 2.442 Z M 11.867 11.867 L 11.16 12.574 L 13.518 14.932 L 14.225 14.225 L 14.932 13.518 L 12.574 11.16 L 11.867 11.867 Z M 0 8.333 L 0 9.333 L 3.333 9.333 L 3.333 8.333 L 3.333 7.333 L 0 7.333 L 0 8.333 Z M 13.333 8.333 L 13.333 9.333 L 16.667 9.333 L 16.667 8.333 L 16.667 7.333 L 13.333 7.333 L 13.333 8.333 Z M 2.442 14.225 L 3.149 14.932 L 5.507 12.574 L 4.8 11.867 L 4.093 11.16 L 1.735 13.518 L 2.442 14.225 Z M 11.867 4.8 L 12.574 5.507 L 14.932 3.149 L 14.225 2.442 L 13.518 1.735 L 11.16 4.093 L 11.867 4.8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "LoaderSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11.25 0 C 11.25 -0.69 10.69 -1.25 10 -1.25 C 9.31 -1.25 8.75 -0.69 8.75 0 L 10 0 L 11.25 0 Z M 8.75 4 C 8.75 4.69 9.31 5.25 10 5.25 C 10.69 5.25 11.25 4.69 11.25 4 L 10 4 L 8.75 4 Z M 11.25 16 C 11.25 15.31 10.69 14.75 10 14.75 C 9.31 14.75 8.75 15.31 8.75 16 L 10 16 L 11.25 16 Z M 8.75 20 C 8.75 20.69 9.31 21.25 10 21.25 C 10.69 21.25 11.25 20.69 11.25 20 L 10 20 L 8.75 20 Z M 3.814 2.046 C 3.326 1.558 2.534 1.558 2.046 2.046 C 1.558 2.534 1.558 3.326 2.046 3.814 L 2.93 2.93 L 3.814 2.046 Z M 4.876 6.644 C 5.364 7.132 6.156 7.132 6.644 6.644 C 7.132 6.156 7.132 5.364 6.644 4.876 L 5.76 5.76 L 4.876 6.644 Z M 15.124 13.356 C 14.636 12.868 13.844 12.868 13.356 13.356 C 12.868 13.844 12.868 14.636 13.356 15.124 L 14.24 14.24 L 15.124 13.356 Z M 16.186 17.954 C 16.674 18.442 17.466 18.442 17.954 17.954 C 18.442 17.466 18.442 16.674 17.954 16.186 L 17.07 17.07 L 16.186 17.954 Z M 0 8.75 C -0.69 8.75 -1.25 9.31 -1.25 10 C -1.25 10.69 -0.69 11.25 0 11.25 L 0 10 L 0 8.75 Z M 4 11.25 C 4.69 11.25 5.25 10.69 5.25 10 C 5.25 9.31 4.69 8.75 4 8.75 L 4 10 L 4 11.25 Z M 16 8.75 C 15.31 8.75 14.75 9.31 14.75 10 C 14.75 10.69 15.31 11.25 16 11.25 L 16 10 L 16 8.75 Z M 20 11.25 C 20.69 11.25 21.25 10.69 21.25 10 C 21.25 9.31 20.69 8.75 20 8.75 L 20 10 L 20 11.25 Z M 2.046 16.186 C 1.558 16.674 1.558 17.466 2.046 17.954 C 2.534 18.442 3.326 18.442 3.814 17.954 L 2.93 17.07 L 2.046 16.186 Z M 6.644 15.124 C 7.132 14.636 7.132 13.844 6.644 13.356 C 6.156 12.868 5.364 12.868 4.876 13.356 L 5.76 14.24 L 6.644 15.124 Z M 13.356 4.876 C 12.868 5.364 12.868 6.156 13.356 6.644 C 13.844 7.132 14.636 7.132 15.124 6.644 L 14.24 5.76 L 13.356 4.876 Z M 17.954 3.814 C 18.442 3.326 18.442 2.534 17.954 2.046 C 17.466 1.558 16.674 1.558 16.186 2.046 L 17.07 2.93 L 17.954 3.814 Z M 10 0 L 8.75 0 L 8.75 4 L 10 4 L 11.25 4 L 11.25 0 L 10 0 Z M 10 16 L 8.75 16 L 8.75 20 L 10 20 L 11.25 20 L 11.25 16 L 10 16 Z M 2.93 2.93 L 2.046 3.814 L 4.876 6.644 L 5.76 5.76 L 6.644 4.876 L 3.814 2.046 L 2.93 2.93 Z M 14.24 14.24 L 13.356 15.124 L 16.186 17.954 L 17.07 17.07 L 17.954 16.186 L 15.124 13.356 L 14.24 14.24 Z M 0 10 L 0 11.25 L 4 11.25 L 4 10 L 4 8.75 L 0 8.75 L 0 10 Z M 16 10 L 16 11.25 L 20 11.25 L 20 10 L 20 8.75 L 16 8.75 L 16 10 Z M 2.93 17.07 L 3.814 17.954 L 6.644 15.124 L 5.76 14.24 L 4.876 13.356 L 2.046 16.186 L 2.93 17.07 Z M 14.24 5.76 L 15.124 6.644 L 17.954 3.814 L 17.07 2.93 L 16.186 2.046 L 13.356 4.876 L 14.24 5.76 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "LoaderSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 14.833 0 C 14.833 -0.828 14.162 -1.5 13.333 -1.5 C 12.505 -1.5 11.833 -0.828 11.833 0 L 13.333 0 L 14.833 0 Z M 11.833 5.333 C 11.833 6.162 12.505 6.833 13.333 6.833 C 14.162 6.833 14.833 6.162 14.833 5.333 L 13.333 5.333 L 11.833 5.333 Z M 14.833 21.333 C 14.833 20.505 14.162 19.833 13.333 19.833 C 12.505 19.833 11.833 20.505 11.833 21.333 L 13.333 21.333 L 14.833 21.333 Z M 11.833 26.667 C 11.833 27.495 12.505 28.167 13.333 28.167 C 14.162 28.167 14.833 27.495 14.833 26.667 L 13.333 26.667 L 11.833 26.667 Z M 4.967 2.846 C 4.382 2.26 3.432 2.26 2.846 2.846 C 2.26 3.432 2.26 4.382 2.846 4.967 L 3.907 3.907 L 4.967 2.846 Z M 6.619 8.741 C 7.205 9.326 8.155 9.326 8.741 8.741 C 9.326 8.155 9.326 7.205 8.741 6.619 L 7.68 7.68 L 6.619 8.741 Z M 20.047 17.926 C 19.462 17.34 18.512 17.34 17.926 17.926 C 17.34 18.512 17.34 19.462 17.926 20.047 L 18.987 18.987 L 20.047 17.926 Z M 21.699 23.821 C 22.285 24.406 23.235 24.406 23.821 23.821 C 24.406 23.235 24.406 22.285 23.821 21.699 L 22.76 22.76 L 21.699 23.821 Z M 0 11.833 C -0.828 11.833 -1.5 12.505 -1.5 13.333 C -1.5 14.162 -0.828 14.833 0 14.833 L 0 13.333 L 0 11.833 Z M 5.333 14.833 C 6.162 14.833 6.833 14.162 6.833 13.333 C 6.833 12.505 6.162 11.833 5.333 11.833 L 5.333 13.333 L 5.333 14.833 Z M 21.333 11.833 C 20.505 11.833 19.833 12.505 19.833 13.333 C 19.833 14.162 20.505 14.833 21.333 14.833 L 21.333 13.333 L 21.333 11.833 Z M 26.667 14.833 C 27.495 14.833 28.167 14.162 28.167 13.333 C 28.167 12.505 27.495 11.833 26.667 11.833 L 26.667 13.333 L 26.667 14.833 Z M 2.846 21.699 C 2.26 22.285 2.26 23.235 2.846 23.821 C 3.432 24.406 4.382 24.406 4.967 23.821 L 3.907 22.76 L 2.846 21.699 Z M 8.741 20.047 C 9.326 19.462 9.326 18.512 8.741 17.926 C 8.155 17.34 7.205 17.34 6.619 17.926 L 7.68 18.987 L 8.741 20.047 Z M 17.926 6.619 C 17.34 7.205 17.34 8.155 17.926 8.741 C 18.512 9.326 19.462 9.326 20.047 8.741 L 18.987 7.68 L 17.926 6.619 Z M 23.821 4.967 C 24.406 4.382 24.406 3.432 23.821 2.846 C 23.235 2.26 22.285 2.26 21.699 2.846 L 22.76 3.907 L 23.821 4.967 Z M 13.333 0 L 11.833 0 L 11.833 5.333 L 13.333 5.333 L 14.833 5.333 L 14.833 0 L 13.333 0 Z M 13.333 21.333 L 11.833 21.333 L 11.833 26.667 L 13.333 26.667 L 14.833 26.667 L 14.833 21.333 L 13.333 21.333 Z M 3.907 3.907 L 2.846 4.967 L 6.619 8.741 L 7.68 7.68 L 8.741 6.619 L 4.967 2.846 L 3.907 3.907 Z M 18.987 18.987 L 17.926 20.047 L 21.699 23.821 L 22.76 22.76 L 23.821 21.699 L 20.047 17.926 L 18.987 18.987 Z M 0 13.333 L 0 14.833 L 5.333 14.833 L 5.333 13.333 L 5.333 11.833 L 0 11.833 L 0 13.333 Z M 21.333 13.333 L 21.333 14.833 L 26.667 14.833 L 26.667 13.333 L 26.667 11.833 L 21.333 11.833 L 21.333 13.333 Z M 3.907 22.76 L 4.967 23.821 L 8.741 20.047 L 7.68 18.987 L 6.619 17.926 L 2.846 21.699 L 3.907 22.76 Z M 18.987 7.68 L 20.047 8.741 L 23.821 4.967 L 22.76 3.907 L 21.699 2.846 L 17.926 6.619 L 18.987 7.68 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 2.667)\"/>"
    },
    "LoaderSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 18.417 0 C 18.417 -0.966 17.633 -1.75 16.667 -1.75 C 15.7 -1.75 14.917 -0.966 14.917 0 L 16.667 0 L 18.417 0 Z M 14.917 6.667 C 14.917 7.633 15.7 8.417 16.667 8.417 C 17.633 8.417 18.417 7.633 18.417 6.667 L 16.667 6.667 L 14.917 6.667 Z M 18.417 26.667 C 18.417 25.7 17.633 24.917 16.667 24.917 C 15.7 24.917 14.917 25.7 14.917 26.667 L 16.667 26.667 L 18.417 26.667 Z M 14.917 33.333 C 14.917 34.3 15.7 35.083 16.667 35.083 C 17.633 35.083 18.417 34.3 18.417 33.333 L 16.667 33.333 L 14.917 33.333 Z M 6.121 3.646 C 5.437 2.962 4.329 2.962 3.646 3.646 C 2.962 4.329 2.962 5.437 3.646 6.121 L 4.883 4.883 L 6.121 3.646 Z M 8.363 10.837 C 9.046 11.521 10.154 11.521 10.837 10.837 C 11.521 10.154 11.521 9.046 10.837 8.363 L 9.6 9.6 L 8.363 10.837 Z M 24.971 22.496 C 24.287 21.812 23.179 21.812 22.496 22.496 C 21.812 23.179 21.812 24.287 22.496 24.971 L 23.733 23.733 L 24.971 22.496 Z M 27.213 29.687 C 27.896 30.371 29.004 30.371 29.687 29.687 C 30.371 29.004 30.371 27.896 29.687 27.213 L 28.45 28.45 L 27.213 29.687 Z M 0 14.917 C -0.966 14.917 -1.75 15.7 -1.75 16.667 C -1.75 17.633 -0.966 18.417 0 18.417 L 0 16.667 L 0 14.917 Z M 6.667 18.417 C 7.633 18.417 8.417 17.633 8.417 16.667 C 8.417 15.7 7.633 14.917 6.667 14.917 L 6.667 16.667 L 6.667 18.417 Z M 26.667 14.917 C 25.7 14.917 24.917 15.7 24.917 16.667 C 24.917 17.633 25.7 18.417 26.667 18.417 L 26.667 16.667 L 26.667 14.917 Z M 33.333 18.417 C 34.3 18.417 35.083 17.633 35.083 16.667 C 35.083 15.7 34.3 14.917 33.333 14.917 L 33.333 16.667 L 33.333 18.417 Z M 3.646 27.213 C 2.962 27.896 2.962 29.004 3.646 29.687 C 4.329 30.371 5.437 30.371 6.121 29.687 L 4.883 28.45 L 3.646 27.213 Z M 10.837 24.971 C 11.521 24.287 11.521 23.179 10.837 22.496 C 10.154 21.812 9.046 21.812 8.363 22.496 L 9.6 23.733 L 10.837 24.971 Z M 22.496 8.363 C 21.812 9.046 21.812 10.154 22.496 10.837 C 23.179 11.521 24.287 11.521 24.971 10.837 L 23.733 9.6 L 22.496 8.363 Z M 29.687 6.121 C 30.371 5.437 30.371 4.329 29.687 3.646 C 29.004 2.962 27.896 2.962 27.213 3.646 L 28.45 4.883 L 29.687 6.121 Z M 16.667 0 L 14.917 0 L 14.917 6.667 L 16.667 6.667 L 18.417 6.667 L 18.417 0 L 16.667 0 Z M 16.667 26.667 L 14.917 26.667 L 14.917 33.333 L 16.667 33.333 L 18.417 33.333 L 18.417 26.667 L 16.667 26.667 Z M 4.883 4.883 L 3.646 6.121 L 8.363 10.837 L 9.6 9.6 L 10.837 8.363 L 6.121 3.646 L 4.883 4.883 Z M 23.733 23.733 L 22.496 24.971 L 27.213 29.687 L 28.45 28.45 L 29.687 27.213 L 24.971 22.496 L 23.733 23.733 Z M 0 16.667 L 0 18.417 L 6.667 18.417 L 6.667 16.667 L 6.667 14.917 L 0 14.917 L 0 16.667 Z M 26.667 16.667 L 26.667 18.417 L 33.333 18.417 L 33.333 16.667 L 33.333 14.917 L 26.667 14.917 L 26.667 16.667 Z M 4.883 28.45 L 6.121 29.687 L 10.837 24.971 L 9.6 23.733 L 8.363 22.496 L 3.646 27.213 L 4.883 28.45 Z M 23.733 9.6 L 24.971 10.837 L 29.687 6.121 L 28.45 4.883 L 27.213 3.646 L 22.496 8.363 L 23.733 9.6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.333 3.333)\"/>"
    },
    "LoaderSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 22 0 C 22 -1.105 21.105 -2 20 -2 C 18.895 -2 18 -1.105 18 0 L 20 0 L 22 0 Z M 18 8 C 18 9.105 18.895 10 20 10 C 21.105 10 22 9.105 22 8 L 20 8 L 18 8 Z M 22 32 C 22 30.895 21.105 30 20 30 C 18.895 30 18 30.895 18 32 L 20 32 L 22 32 Z M 18 40 C 18 41.105 18.895 42 20 42 C 21.105 42 22 41.105 22 40 L 20 40 L 18 40 Z M 7.274 4.446 C 6.493 3.665 5.227 3.665 4.446 4.446 C 3.665 5.227 3.665 6.493 4.446 7.274 L 5.86 5.86 L 7.274 4.446 Z M 10.106 12.934 C 10.887 13.715 12.153 13.715 12.934 12.934 C 13.715 12.153 13.715 10.887 12.934 10.106 L 11.52 11.52 L 10.106 12.934 Z M 29.894 27.066 C 29.113 26.285 27.847 26.285 27.066 27.066 C 26.285 27.847 26.285 29.113 27.066 29.894 L 28.48 28.48 L 29.894 27.066 Z M 32.726 35.554 C 33.507 36.335 34.773 36.335 35.554 35.554 C 36.335 34.773 36.335 33.507 35.554 32.726 L 34.14 34.14 L 32.726 35.554 Z M 0 18 C -1.105 18 -2 18.895 -2 20 C -2 21.105 -1.105 22 0 22 L 0 20 L 0 18 Z M 8 22 C 9.105 22 10 21.105 10 20 C 10 18.895 9.105 18 8 18 L 8 20 L 8 22 Z M 32 18 C 30.895 18 30 18.895 30 20 C 30 21.105 30.895 22 32 22 L 32 20 L 32 18 Z M 40 22 C 41.105 22 42 21.105 42 20 C 42 18.895 41.105 18 40 18 L 40 20 L 40 22 Z M 4.446 32.726 C 3.665 33.507 3.665 34.773 4.446 35.554 C 5.227 36.335 6.493 36.335 7.274 35.554 L 5.86 34.14 L 4.446 32.726 Z M 12.934 29.894 C 13.715 29.113 13.715 27.847 12.934 27.066 C 12.153 26.285 10.887 26.285 10.106 27.066 L 11.52 28.48 L 12.934 29.894 Z M 27.066 10.106 C 26.285 10.887 26.285 12.153 27.066 12.934 C 27.847 13.715 29.113 13.715 29.894 12.934 L 28.48 11.52 L 27.066 10.106 Z M 35.554 7.274 C 36.335 6.493 36.335 5.227 35.554 4.446 C 34.773 3.665 33.507 3.665 32.726 4.446 L 34.14 5.86 L 35.554 7.274 Z M 20 0 L 18 0 L 18 8 L 20 8 L 22 8 L 22 0 L 20 0 Z M 20 32 L 18 32 L 18 40 L 20 40 L 22 40 L 22 32 L 20 32 Z M 5.86 5.86 L 4.446 7.274 L 10.106 12.934 L 11.52 11.52 L 12.934 10.106 L 7.274 4.446 L 5.86 5.86 Z M 28.48 28.48 L 27.066 29.894 L 32.726 35.554 L 34.14 34.14 L 35.554 32.726 L 29.894 27.066 L 28.48 28.48 Z M 0 20 L 0 22 L 8 22 L 8 20 L 8 18 L 0 18 L 0 20 Z M 32 20 L 32 22 L 40 22 L 40 20 L 40 18 L 32 18 L 32 20 Z M 5.86 34.14 L 7.274 35.554 L 12.934 29.894 L 11.52 28.48 L 10.106 27.066 L 4.446 32.726 L 5.86 34.14 Z M 28.48 11.52 L 29.894 12.934 L 35.554 7.274 L 34.14 5.86 L 32.726 4.446 L 27.066 10.106 L 28.48 11.52 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "SunSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 8.133 0 C 8.133 -0.442 7.775 -0.8 7.333 -0.8 C 6.892 -0.8 6.533 -0.442 6.533 0 L 7.333 0 L 8.133 0 Z M 6.533 1.333 C 6.533 1.775 6.892 2.133 7.333 2.133 C 7.775 2.133 8.133 1.775 8.133 1.333 L 7.333 1.333 L 6.533 1.333 Z M 8.133 13.333 C 8.133 12.892 7.775 12.533 7.333 12.533 C 6.892 12.533 6.533 12.892 6.533 13.333 L 7.333 13.333 L 8.133 13.333 Z M 6.533 14.667 C 6.533 15.108 6.892 15.467 7.333 15.467 C 7.775 15.467 8.133 15.108 8.133 14.667 L 7.333 14.667 L 6.533 14.667 Z M 2.712 1.581 C 2.4 1.269 1.893 1.269 1.581 1.581 C 1.269 1.893 1.269 2.4 1.581 2.712 L 2.147 2.147 L 2.712 1.581 Z M 2.528 3.659 C 2.84 3.971 3.347 3.971 3.659 3.659 C 3.971 3.347 3.971 2.84 3.659 2.528 L 3.093 3.093 L 2.528 3.659 Z M 12.139 11.008 C 11.827 10.695 11.32 10.695 11.008 11.008 C 10.695 11.32 10.695 11.827 11.008 12.139 L 11.573 11.573 L 12.139 11.008 Z M 11.954 13.086 C 12.267 13.398 12.773 13.398 13.086 13.086 C 13.398 12.773 13.398 12.267 13.086 11.954 L 12.52 12.52 L 11.954 13.086 Z M 0 6.533 C -0.442 6.533 -0.8 6.892 -0.8 7.333 C -0.8 7.775 -0.442 8.133 0 8.133 L 0 7.333 L 0 6.533 Z M 1.333 8.133 C 1.775 8.133 2.133 7.775 2.133 7.333 C 2.133 6.892 1.775 6.533 1.333 6.533 L 1.333 7.333 L 1.333 8.133 Z M 13.333 6.533 C 12.892 6.533 12.533 6.892 12.533 7.333 C 12.533 7.775 12.892 8.133 13.333 8.133 L 13.333 7.333 L 13.333 6.533 Z M 14.667 8.133 C 15.108 8.133 15.467 7.775 15.467 7.333 C 15.467 6.892 15.108 6.533 14.667 6.533 L 14.667 7.333 L 14.667 8.133 Z M 1.581 11.954 C 1.269 12.267 1.269 12.773 1.581 13.086 C 1.893 13.398 2.4 13.398 2.712 13.086 L 2.147 12.52 L 1.581 11.954 Z M 3.659 12.139 C 3.971 11.827 3.971 11.32 3.659 11.008 C 3.347 10.695 2.84 10.695 2.528 11.008 L 3.093 11.573 L 3.659 12.139 Z M 11.008 2.528 C 10.695 2.84 10.695 3.347 11.008 3.659 C 11.32 3.971 11.827 3.971 12.139 3.659 L 11.573 3.093 L 11.008 2.528 Z M 13.086 2.712 C 13.398 2.4 13.398 1.893 13.086 1.581 C 12.773 1.269 12.267 1.269 11.954 1.581 L 12.52 2.147 L 13.086 2.712 Z M 10.667 7.333 L 9.867 7.333 C 9.867 8.732 8.732 9.867 7.333 9.867 L 7.333 10.667 L 7.333 11.467 C 9.616 11.467 11.467 9.616 11.467 7.333 L 10.667 7.333 Z M 7.333 10.667 L 7.333 9.867 C 5.934 9.867 4.8 8.732 4.8 7.333 L 4 7.333 L 3.2 7.333 C 3.2 9.616 5.051 11.467 7.333 11.467 L 7.333 10.667 Z M 4 7.333 L 4.8 7.333 C 4.8 5.934 5.934 4.8 7.333 4.8 L 7.333 4 L 7.333 3.2 C 5.051 3.2 3.2 5.051 3.2 7.333 L 4 7.333 Z M 7.333 4 L 7.333 4.8 C 8.732 4.8 9.867 5.934 9.867 7.333 L 10.667 7.333 L 11.467 7.333 C 11.467 5.051 9.616 3.2 7.333 3.2 L 7.333 4 Z M 7.333 0 L 6.533 0 L 6.533 1.333 L 7.333 1.333 L 8.133 1.333 L 8.133 0 L 7.333 0 Z M 7.333 13.333 L 6.533 13.333 L 6.533 14.667 L 7.333 14.667 L 8.133 14.667 L 8.133 13.333 L 7.333 13.333 Z M 2.147 2.147 L 1.581 2.712 L 2.528 3.659 L 3.093 3.093 L 3.659 2.528 L 2.712 1.581 L 2.147 2.147 Z M 11.573 11.573 L 11.008 12.139 L 11.954 13.086 L 12.52 12.52 L 13.086 11.954 L 12.139 11.008 L 11.573 11.573 Z M 0 7.333 L 0 8.133 L 1.333 8.133 L 1.333 7.333 L 1.333 6.533 L 0 6.533 L 0 7.333 Z M 13.333 7.333 L 13.333 8.133 L 14.667 8.133 L 14.667 7.333 L 14.667 6.533 L 13.333 6.533 L 13.333 7.333 Z M 2.147 12.52 L 2.712 13.086 L 3.659 12.139 L 3.093 11.573 L 2.528 11.008 L 1.581 11.954 L 2.147 12.52 Z M 11.573 3.093 L 12.139 3.659 L 13.086 2.712 L 12.52 2.147 L 11.954 1.581 L 11.008 2.528 L 11.573 3.093 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 0.667 0.667)\"/>"
    },
    "SunSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 10.167 0 C 10.167 -0.552 9.719 -1 9.167 -1 C 8.614 -1 8.167 -0.552 8.167 0 L 9.167 0 L 10.167 0 Z M 8.167 1.667 C 8.167 2.219 8.614 2.667 9.167 2.667 C 9.719 2.667 10.167 2.219 10.167 1.667 L 9.167 1.667 L 8.167 1.667 Z M 10.167 16.667 C 10.167 16.114 9.719 15.667 9.167 15.667 C 8.614 15.667 8.167 16.114 8.167 16.667 L 9.167 16.667 L 10.167 16.667 Z M 8.167 18.333 C 8.167 18.886 8.614 19.333 9.167 19.333 C 9.719 19.333 10.167 18.886 10.167 18.333 L 9.167 18.333 L 8.167 18.333 Z M 3.39 1.976 C 3 1.586 2.367 1.586 1.976 1.976 C 1.586 2.367 1.586 3 1.976 3.39 L 2.683 2.683 L 3.39 1.976 Z M 3.16 4.574 C 3.55 4.964 4.183 4.964 4.574 4.574 C 4.964 4.183 4.964 3.55 4.574 3.16 L 3.867 3.867 L 3.16 4.574 Z M 15.174 13.76 C 14.783 13.369 14.15 13.369 13.76 13.76 C 13.369 14.15 13.369 14.783 13.76 15.174 L 14.467 14.467 L 15.174 13.76 Z M 14.943 16.357 C 15.333 16.748 15.967 16.748 16.357 16.357 C 16.748 15.967 16.748 15.333 16.357 14.943 L 15.65 15.65 L 14.943 16.357 Z M 0 8.167 C -0.552 8.167 -1 8.614 -1 9.167 C -1 9.719 -0.552 10.167 0 10.167 L 0 9.167 L 0 8.167 Z M 1.667 10.167 C 2.219 10.167 2.667 9.719 2.667 9.167 C 2.667 8.614 2.219 8.167 1.667 8.167 L 1.667 9.167 L 1.667 10.167 Z M 16.667 8.167 C 16.114 8.167 15.667 8.614 15.667 9.167 C 15.667 9.719 16.114 10.167 16.667 10.167 L 16.667 9.167 L 16.667 8.167 Z M 18.333 10.167 C 18.886 10.167 19.333 9.719 19.333 9.167 C 19.333 8.614 18.886 8.167 18.333 8.167 L 18.333 9.167 L 18.333 10.167 Z M 1.976 14.943 C 1.586 15.333 1.586 15.967 1.976 16.357 C 2.367 16.748 3 16.748 3.39 16.357 L 2.683 15.65 L 1.976 14.943 Z M 4.574 15.174 C 4.964 14.783 4.964 14.15 4.574 13.76 C 4.183 13.369 3.55 13.369 3.16 13.76 L 3.867 14.467 L 4.574 15.174 Z M 13.76 3.16 C 13.369 3.55 13.369 4.183 13.76 4.574 C 14.15 4.964 14.783 4.964 15.174 4.574 L 14.467 3.867 L 13.76 3.16 Z M 16.357 3.39 C 16.748 3 16.748 2.367 16.357 1.976 C 15.967 1.586 15.333 1.586 14.943 1.976 L 15.65 2.683 L 16.357 3.39 Z M 13.333 9.167 L 12.333 9.167 C 12.333 10.916 10.916 12.333 9.167 12.333 L 9.167 13.333 L 9.167 14.333 C 12.02 14.333 14.333 12.02 14.333 9.167 L 13.333 9.167 Z M 9.167 13.333 L 9.167 12.333 C 7.418 12.333 6 10.916 6 9.167 L 5 9.167 L 4 9.167 C 4 12.02 6.313 14.333 9.167 14.333 L 9.167 13.333 Z M 5 9.167 L 6 9.167 C 6 7.418 7.418 6 9.167 6 L 9.167 5 L 9.167 4 C 6.313 4 4 6.313 4 9.167 L 5 9.167 Z M 9.167 5 L 9.167 6 C 10.916 6 12.333 7.418 12.333 9.167 L 13.333 9.167 L 14.333 9.167 C 14.333 6.313 12.02 4 9.167 4 L 9.167 5 Z M 9.167 0 L 8.167 0 L 8.167 1.667 L 9.167 1.667 L 10.167 1.667 L 10.167 0 L 9.167 0 Z M 9.167 16.667 L 8.167 16.667 L 8.167 18.333 L 9.167 18.333 L 10.167 18.333 L 10.167 16.667 L 9.167 16.667 Z M 2.683 2.683 L 1.976 3.39 L 3.16 4.574 L 3.867 3.867 L 4.574 3.16 L 3.39 1.976 L 2.683 2.683 Z M 14.467 14.467 L 13.76 15.174 L 14.943 16.357 L 15.65 15.65 L 16.357 14.943 L 15.174 13.76 L 14.467 14.467 Z M 0 9.167 L 0 10.167 L 1.667 10.167 L 1.667 9.167 L 1.667 8.167 L 0 8.167 L 0 9.167 Z M 16.667 9.167 L 16.667 10.167 L 18.333 10.167 L 18.333 9.167 L 18.333 8.167 L 16.667 8.167 L 16.667 9.167 Z M 2.683 15.65 L 3.39 16.357 L 4.574 15.174 L 3.867 14.467 L 3.16 13.76 L 1.976 14.943 L 2.683 15.65 Z M 14.467 3.867 L 15.174 4.574 L 16.357 3.39 L 15.65 2.683 L 14.943 1.976 L 13.76 3.16 L 14.467 3.867 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 0.833 0.833)\"/>"
    },
    "SunSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12.25 0 C 12.25 -0.69 11.69 -1.25 11 -1.25 C 10.31 -1.25 9.75 -0.69 9.75 0 L 11 0 L 12.25 0 Z M 9.75 2 C 9.75 2.69 10.31 3.25 11 3.25 C 11.69 3.25 12.25 2.69 12.25 2 L 11 2 L 9.75 2 Z M 12.25 20 C 12.25 19.31 11.69 18.75 11 18.75 C 10.31 18.75 9.75 19.31 9.75 20 L 11 20 L 12.25 20 Z M 9.75 22 C 9.75 22.69 10.31 23.25 11 23.25 C 11.69 23.25 12.25 22.69 12.25 22 L 11 22 L 9.75 22 Z M 4.104 2.336 C 3.616 1.848 2.824 1.848 2.336 2.336 C 1.848 2.824 1.848 3.616 2.336 4.104 L 3.22 3.22 L 4.104 2.336 Z M 3.756 5.524 C 4.244 6.012 5.036 6.012 5.524 5.524 C 6.012 5.036 6.012 4.244 5.524 3.756 L 4.64 4.64 L 3.756 5.524 Z M 18.244 16.476 C 17.756 15.988 16.964 15.988 16.476 16.476 C 15.988 16.964 15.988 17.756 16.476 18.244 L 17.36 17.36 L 18.244 16.476 Z M 17.896 19.664 C 18.384 20.152 19.176 20.152 19.664 19.664 C 20.152 19.176 20.152 18.384 19.664 17.896 L 18.78 18.78 L 17.896 19.664 Z M 0 9.75 C -0.69 9.75 -1.25 10.31 -1.25 11 C -1.25 11.69 -0.69 12.25 0 12.25 L 0 11 L 0 9.75 Z M 2 12.25 C 2.69 12.25 3.25 11.69 3.25 11 C 3.25 10.31 2.69 9.75 2 9.75 L 2 11 L 2 12.25 Z M 20 9.75 C 19.31 9.75 18.75 10.31 18.75 11 C 18.75 11.69 19.31 12.25 20 12.25 L 20 11 L 20 9.75 Z M 22 12.25 C 22.69 12.25 23.25 11.69 23.25 11 C 23.25 10.31 22.69 9.75 22 9.75 L 22 11 L 22 12.25 Z M 2.336 17.896 C 1.848 18.384 1.848 19.176 2.336 19.664 C 2.824 20.152 3.616 20.152 4.104 19.664 L 3.22 18.78 L 2.336 17.896 Z M 5.524 18.244 C 6.012 17.756 6.012 16.964 5.524 16.476 C 5.036 15.988 4.244 15.988 3.756 16.476 L 4.64 17.36 L 5.524 18.244 Z M 16.476 3.756 C 15.988 4.244 15.988 5.036 16.476 5.524 C 16.964 6.012 17.756 6.012 18.244 5.524 L 17.36 4.64 L 16.476 3.756 Z M 19.664 4.104 C 20.152 3.616 20.152 2.824 19.664 2.336 C 19.176 1.848 18.384 1.848 17.896 2.336 L 18.78 3.22 L 19.664 4.104 Z M 16 11 L 14.75 11 C 14.75 13.071 13.071 14.75 11 14.75 L 11 16 L 11 17.25 C 14.452 17.25 17.25 14.452 17.25 11 L 16 11 Z M 11 16 L 11 14.75 C 8.929 14.75 7.25 13.071 7.25 11 L 6 11 L 4.75 11 C 4.75 14.452 7.548 17.25 11 17.25 L 11 16 Z M 6 11 L 7.25 11 C 7.25 8.929 8.929 7.25 11 7.25 L 11 6 L 11 4.75 C 7.548 4.75 4.75 7.548 4.75 11 L 6 11 Z M 11 6 L 11 7.25 C 13.071 7.25 14.75 8.929 14.75 11 L 16 11 L 17.25 11 C 17.25 7.548 14.452 4.75 11 4.75 L 11 6 Z M 11 0 L 9.75 0 L 9.75 2 L 11 2 L 12.25 2 L 12.25 0 L 11 0 Z M 11 20 L 9.75 20 L 9.75 22 L 11 22 L 12.25 22 L 12.25 20 L 11 20 Z M 3.22 3.22 L 2.336 4.104 L 3.756 5.524 L 4.64 4.64 L 5.524 3.756 L 4.104 2.336 L 3.22 3.22 Z M 17.36 17.36 L 16.476 18.244 L 17.896 19.664 L 18.78 18.78 L 19.664 17.896 L 18.244 16.476 L 17.36 17.36 Z M 0 11 L 0 12.25 L 2 12.25 L 2 11 L 2 9.75 L 0 9.75 L 0 11 Z M 20 11 L 20 12.25 L 22 12.25 L 22 11 L 22 9.75 L 20 9.75 L 20 11 Z M 3.22 18.78 L 4.104 19.664 L 5.524 18.244 L 4.64 17.36 L 3.756 16.476 L 2.336 17.896 L 3.22 18.78 Z M 17.36 4.64 L 18.244 5.524 L 19.664 4.104 L 18.78 3.22 L 17.896 2.336 L 16.476 3.756 L 17.36 4.64 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 1)\"/>"
    },
    "SunSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 16.167 0 C 16.167 -0.828 15.495 -1.5 14.667 -1.5 C 13.838 -1.5 13.167 -0.828 13.167 0 L 14.667 0 L 16.167 0 Z M 13.167 2.667 C 13.167 3.495 13.838 4.167 14.667 4.167 C 15.495 4.167 16.167 3.495 16.167 2.667 L 14.667 2.667 L 13.167 2.667 Z M 16.167 26.667 C 16.167 25.838 15.495 25.167 14.667 25.167 C 13.838 25.167 13.167 25.838 13.167 26.667 L 14.667 26.667 L 16.167 26.667 Z M 13.167 29.333 C 13.167 30.162 13.838 30.833 14.667 30.833 C 15.495 30.833 16.167 30.162 16.167 29.333 L 14.667 29.333 L 13.167 29.333 Z M 5.354 3.233 C 4.768 2.647 3.818 2.647 3.233 3.233 C 2.647 3.818 2.647 4.768 3.233 5.354 L 4.293 4.293 L 5.354 3.233 Z M 5.126 7.247 C 5.712 7.833 6.662 7.833 7.247 7.247 C 7.833 6.662 7.833 5.712 7.247 5.126 L 6.187 6.187 L 5.126 7.247 Z M 24.207 22.086 C 23.622 21.5 22.672 21.5 22.086 22.086 C 21.5 22.672 21.5 23.622 22.086 24.207 L 23.147 23.147 L 24.207 22.086 Z M 23.979 26.101 C 24.565 26.686 25.515 26.686 26.101 26.101 C 26.686 25.515 26.686 24.565 26.101 23.979 L 25.04 25.04 L 23.979 26.101 Z M 0 13.167 C -0.828 13.167 -1.5 13.838 -1.5 14.667 C -1.5 15.495 -0.828 16.167 0 16.167 L 0 14.667 L 0 13.167 Z M 2.667 16.167 C 3.495 16.167 4.167 15.495 4.167 14.667 C 4.167 13.838 3.495 13.167 2.667 13.167 L 2.667 14.667 L 2.667 16.167 Z M 26.667 13.167 C 25.838 13.167 25.167 13.838 25.167 14.667 C 25.167 15.495 25.838 16.167 26.667 16.167 L 26.667 14.667 L 26.667 13.167 Z M 29.333 16.167 C 30.162 16.167 30.833 15.495 30.833 14.667 C 30.833 13.838 30.162 13.167 29.333 13.167 L 29.333 14.667 L 29.333 16.167 Z M 3.233 23.979 C 2.647 24.565 2.647 25.515 3.233 26.101 C 3.818 26.686 4.768 26.686 5.354 26.101 L 4.293 25.04 L 3.233 23.979 Z M 7.247 24.207 C 7.833 23.622 7.833 22.672 7.247 22.086 C 6.662 21.5 5.712 21.5 5.126 22.086 L 6.187 23.147 L 7.247 24.207 Z M 22.086 5.126 C 21.5 5.712 21.5 6.662 22.086 7.247 C 22.672 7.833 23.622 7.833 24.207 7.247 L 23.147 6.187 L 22.086 5.126 Z M 26.101 5.354 C 26.686 4.768 26.686 3.818 26.101 3.233 C 25.515 2.647 24.565 2.647 23.979 3.233 L 25.04 4.293 L 26.101 5.354 Z M 21.333 14.667 L 19.833 14.667 C 19.833 17.52 17.52 19.833 14.667 19.833 L 14.667 21.333 L 14.667 22.833 C 19.177 22.833 22.833 19.177 22.833 14.667 L 21.333 14.667 Z M 14.667 21.333 L 14.667 19.833 C 11.813 19.833 9.5 17.52 9.5 14.667 L 8 14.667 L 6.5 14.667 C 6.5 19.177 10.156 22.833 14.667 22.833 L 14.667 21.333 Z M 8 14.667 L 9.5 14.667 C 9.5 11.813 11.813 9.5 14.667 9.5 L 14.667 8 L 14.667 6.5 C 10.156 6.5 6.5 10.156 6.5 14.667 L 8 14.667 Z M 14.667 8 L 14.667 9.5 C 17.52 9.5 19.833 11.813 19.833 14.667 L 21.333 14.667 L 22.833 14.667 C 22.833 10.156 19.177 6.5 14.667 6.5 L 14.667 8 Z M 14.667 0 L 13.167 0 L 13.167 2.667 L 14.667 2.667 L 16.167 2.667 L 16.167 0 L 14.667 0 Z M 14.667 26.667 L 13.167 26.667 L 13.167 29.333 L 14.667 29.333 L 16.167 29.333 L 16.167 26.667 L 14.667 26.667 Z M 4.293 4.293 L 3.233 5.354 L 5.126 7.247 L 6.187 6.187 L 7.247 5.126 L 5.354 3.233 L 4.293 4.293 Z M 23.147 23.147 L 22.086 24.207 L 23.979 26.101 L 25.04 25.04 L 26.101 23.979 L 24.207 22.086 L 23.147 23.147 Z M 0 14.667 L 0 16.167 L 2.667 16.167 L 2.667 14.667 L 2.667 13.167 L 0 13.167 L 0 14.667 Z M 26.667 14.667 L 26.667 16.167 L 29.333 16.167 L 29.333 14.667 L 29.333 13.167 L 26.667 13.167 L 26.667 14.667 Z M 4.293 25.04 L 5.354 26.101 L 7.247 24.207 L 6.187 23.147 L 5.126 22.086 L 3.233 23.979 L 4.293 25.04 Z M 23.147 6.187 L 24.207 7.247 L 26.101 5.354 L 25.04 4.293 L 23.979 3.233 L 22.086 5.126 L 23.147 6.187 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333)\"/>"
    },
    "SunSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 20.083 0 C 20.083 -0.966 19.3 -1.75 18.333 -1.75 C 17.367 -1.75 16.583 -0.966 16.583 0 L 18.333 0 L 20.083 0 Z M 16.583 3.333 C 16.583 4.3 17.367 5.083 18.333 5.083 C 19.3 5.083 20.083 4.3 20.083 3.333 L 18.333 3.333 L 16.583 3.333 Z M 20.083 33.333 C 20.083 32.367 19.3 31.583 18.333 31.583 C 17.367 31.583 16.583 32.367 16.583 33.333 L 18.333 33.333 L 20.083 33.333 Z M 16.583 36.667 C 16.583 37.633 17.367 38.417 18.333 38.417 C 19.3 38.417 20.083 37.633 20.083 36.667 L 18.333 36.667 L 16.583 36.667 Z M 6.604 4.129 C 5.921 3.446 4.813 3.446 4.129 4.129 C 3.446 4.813 3.446 5.921 4.129 6.604 L 5.367 5.367 L 6.604 4.129 Z M 6.496 8.971 C 7.179 9.654 8.287 9.654 8.971 8.971 C 9.654 8.287 9.654 7.179 8.971 6.496 L 7.733 7.733 L 6.496 8.971 Z M 30.171 27.696 C 29.487 27.012 28.379 27.012 27.696 27.696 C 27.012 28.379 27.012 29.487 27.696 30.171 L 28.933 28.933 L 30.171 27.696 Z M 30.063 32.537 C 30.746 33.221 31.854 33.221 32.537 32.537 C 33.221 31.854 33.221 30.746 32.537 30.063 L 31.3 31.3 L 30.063 32.537 Z M 0 16.583 C -0.966 16.583 -1.75 17.367 -1.75 18.333 C -1.75 19.3 -0.966 20.083 0 20.083 L 0 18.333 L 0 16.583 Z M 3.333 20.083 C 4.3 20.083 5.083 19.3 5.083 18.333 C 5.083 17.367 4.3 16.583 3.333 16.583 L 3.333 18.333 L 3.333 20.083 Z M 33.333 16.583 C 32.367 16.583 31.583 17.367 31.583 18.333 C 31.583 19.3 32.367 20.083 33.333 20.083 L 33.333 18.333 L 33.333 16.583 Z M 36.667 20.083 C 37.633 20.083 38.417 19.3 38.417 18.333 C 38.417 17.367 37.633 16.583 36.667 16.583 L 36.667 18.333 L 36.667 20.083 Z M 4.129 30.063 C 3.446 30.746 3.446 31.854 4.129 32.537 C 4.813 33.221 5.921 33.221 6.604 32.537 L 5.367 31.3 L 4.129 30.063 Z M 8.971 30.171 C 9.654 29.487 9.654 28.379 8.971 27.696 C 8.287 27.012 7.179 27.012 6.496 27.696 L 7.733 28.933 L 8.971 30.171 Z M 27.696 6.496 C 27.012 7.179 27.012 8.287 27.696 8.971 C 28.379 9.654 29.487 9.654 30.171 8.971 L 28.933 7.733 L 27.696 6.496 Z M 32.537 6.604 C 33.221 5.921 33.221 4.813 32.537 4.129 C 31.854 3.446 30.746 3.446 30.063 4.129 L 31.3 5.367 L 32.537 6.604 Z M 26.667 18.333 L 24.917 18.333 C 24.917 21.969 21.969 24.917 18.333 24.917 L 18.333 26.667 L 18.333 28.417 C 23.902 28.417 28.417 23.902 28.417 18.333 L 26.667 18.333 Z M 18.333 26.667 L 18.333 24.917 C 14.697 24.917 11.75 21.969 11.75 18.333 L 10 18.333 L 8.25 18.333 C 8.25 23.902 12.764 28.417 18.333 28.417 L 18.333 26.667 Z M 10 18.333 L 11.75 18.333 C 11.75 14.697 14.697 11.75 18.333 11.75 L 18.333 10 L 18.333 8.25 C 12.764 8.25 8.25 12.764 8.25 18.333 L 10 18.333 Z M 18.333 10 L 18.333 11.75 C 21.969 11.75 24.917 14.697 24.917 18.333 L 26.667 18.333 L 28.417 18.333 C 28.417 12.764 23.902 8.25 18.333 8.25 L 18.333 10 Z M 18.333 0 L 16.583 0 L 16.583 3.333 L 18.333 3.333 L 20.083 3.333 L 20.083 0 L 18.333 0 Z M 18.333 33.333 L 16.583 33.333 L 16.583 36.667 L 18.333 36.667 L 20.083 36.667 L 20.083 33.333 L 18.333 33.333 Z M 5.367 5.367 L 4.129 6.604 L 6.496 8.971 L 7.733 7.733 L 8.971 6.496 L 6.604 4.129 L 5.367 5.367 Z M 28.933 28.933 L 27.696 30.171 L 30.063 32.537 L 31.3 31.3 L 32.537 30.063 L 30.171 27.696 L 28.933 28.933 Z M 0 18.333 L 0 20.083 L 3.333 20.083 L 3.333 18.333 L 3.333 16.583 L 0 16.583 L 0 18.333 Z M 33.333 18.333 L 33.333 20.083 L 36.667 20.083 L 36.667 18.333 L 36.667 16.583 L 33.333 16.583 L 33.333 18.333 Z M 5.367 31.3 L 6.604 32.537 L 8.971 30.171 L 7.733 28.933 L 6.496 27.696 L 4.129 30.063 L 5.367 31.3 Z M 28.933 7.733 L 30.171 8.971 L 32.537 6.604 L 31.3 5.367 L 30.063 4.129 L 27.696 6.496 L 28.933 7.733 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "SunSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 24 0 C 24 -1.105 23.105 -2 22 -2 C 20.895 -2 20 -1.105 20 0 L 22 0 L 24 0 Z M 20 4 C 20 5.105 20.895 6 22 6 C 23.105 6 24 5.105 24 4 L 22 4 L 20 4 Z M 24 40 C 24 38.895 23.105 38 22 38 C 20.895 38 20 38.895 20 40 L 22 40 L 24 40 Z M 20 44 C 20 45.105 20.895 46 22 46 C 23.105 46 24 45.105 24 44 L 22 44 L 20 44 Z M 7.854 5.026 C 7.073 4.245 5.807 4.245 5.026 5.026 C 4.245 5.807 4.245 7.073 5.026 7.854 L 6.44 6.44 L 7.854 5.026 Z M 7.866 10.694 C 8.647 11.475 9.913 11.475 10.694 10.694 C 11.475 9.913 11.475 8.647 10.694 7.866 L 9.28 9.28 L 7.866 10.694 Z M 36.134 33.306 C 35.353 32.525 34.087 32.525 33.306 33.306 C 32.525 34.087 32.525 35.353 33.306 36.134 L 34.72 34.72 L 36.134 33.306 Z M 36.146 38.974 C 36.927 39.755 38.193 39.755 38.974 38.974 C 39.755 38.193 39.755 36.927 38.974 36.146 L 37.56 37.56 L 36.146 38.974 Z M 0 20 C -1.105 20 -2 20.895 -2 22 C -2 23.105 -1.105 24 0 24 L 0 22 L 0 20 Z M 4 24 C 5.105 24 6 23.105 6 22 C 6 20.895 5.105 20 4 20 L 4 22 L 4 24 Z M 40 20 C 38.895 20 38 20.895 38 22 C 38 23.105 38.895 24 40 24 L 40 22 L 40 20 Z M 44 24 C 45.105 24 46 23.105 46 22 C 46 20.895 45.105 20 44 20 L 44 22 L 44 24 Z M 5.026 36.146 C 4.245 36.927 4.245 38.193 5.026 38.974 C 5.807 39.755 7.073 39.755 7.854 38.974 L 6.44 37.56 L 5.026 36.146 Z M 10.694 36.134 C 11.475 35.353 11.475 34.087 10.694 33.306 C 9.913 32.525 8.647 32.525 7.866 33.306 L 9.28 34.72 L 10.694 36.134 Z M 33.306 7.866 C 32.525 8.647 32.525 9.913 33.306 10.694 C 34.087 11.475 35.353 11.475 36.134 10.694 L 34.72 9.28 L 33.306 7.866 Z M 38.974 7.854 C 39.755 7.073 39.755 5.807 38.974 5.026 C 38.193 4.245 36.927 4.245 36.146 5.026 L 37.56 6.44 L 38.974 7.854 Z M 32 22 L 30 22 C 30 26.418 26.418 30 22 30 L 22 32 L 22 34 C 28.627 34 34 28.627 34 22 L 32 22 Z M 22 32 L 22 30 C 17.582 30 14 26.418 14 22 L 12 22 L 10 22 C 10 28.627 15.373 34 22 34 L 22 32 Z M 12 22 L 14 22 C 14 17.582 17.582 14 22 14 L 22 12 L 22 10 C 15.373 10 10 15.373 10 22 L 12 22 Z M 22 12 L 22 14 C 26.418 14 30 17.582 30 22 L 32 22 L 34 22 C 34 15.373 28.627 10 22 10 L 22 12 Z M 22 0 L 20 0 L 20 4 L 22 4 L 24 4 L 24 0 L 22 0 Z M 22 40 L 20 40 L 20 44 L 22 44 L 24 44 L 24 40 L 22 40 Z M 6.44 6.44 L 5.026 7.854 L 7.866 10.694 L 9.28 9.28 L 10.694 7.866 L 7.854 5.026 L 6.44 6.44 Z M 34.72 34.72 L 33.306 36.134 L 36.146 38.974 L 37.56 37.56 L 38.974 36.146 L 36.134 33.306 L 34.72 34.72 Z M 0 22 L 0 24 L 4 24 L 4 22 L 4 20 L 0 20 L 0 22 Z M 40 22 L 40 24 L 44 24 L 44 22 L 44 20 L 40 20 L 40 22 Z M 6.44 37.56 L 7.854 38.974 L 10.694 36.134 L 9.28 34.72 L 7.866 33.306 L 5.026 36.146 L 6.44 37.56 Z M 34.72 9.28 L 36.134 10.694 L 38.974 7.854 L 37.56 6.44 L 36.146 5.026 L 33.306 7.866 L 34.72 9.28 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "XCircleSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 9.232 5.232 C 9.545 4.92 9.545 4.413 9.232 4.101 C 8.92 3.789 8.413 3.789 8.101 4.101 L 8.667 4.667 L 9.232 5.232 Z M 4.101 8.101 C 3.789 8.413 3.789 8.92 4.101 9.232 C 4.413 9.545 4.92 9.545 5.232 9.232 L 4.667 8.667 L 4.101 8.101 Z M 5.232 4.101 C 4.92 3.789 4.413 3.789 4.101 4.101 C 3.789 4.413 3.789 4.92 4.101 5.232 L 4.667 4.667 L 5.232 4.101 Z M 8.101 9.232 C 8.413 9.545 8.92 9.545 9.232 9.232 C 9.545 8.92 9.545 8.413 9.232 8.101 L 8.667 8.667 L 8.101 9.232 Z M 13.333 6.667 L 12.533 6.667 C 12.533 9.907 9.907 12.533 6.667 12.533 L 6.667 13.333 L 6.667 14.133 C 10.79 14.133 14.133 10.79 14.133 6.667 L 13.333 6.667 Z M 6.667 13.333 L 6.667 12.533 C 3.427 12.533 0.8 9.907 0.8 6.667 L 0 6.667 L -0.8 6.667 C -0.8 10.79 2.543 14.133 6.667 14.133 L 6.667 13.333 Z M 0 6.667 L 0.8 6.667 C 0.8 3.427 3.427 0.8 6.667 0.8 L 6.667 0 L 6.667 -0.8 C 2.543 -0.8 -0.8 2.543 -0.8 6.667 L 0 6.667 Z M 6.667 0 L 6.667 0.8 C 9.907 0.8 12.533 3.427 12.533 6.667 L 13.333 6.667 L 14.133 6.667 C 14.133 2.543 10.79 -0.8 6.667 -0.8 L 6.667 0 Z M 8.667 4.667 L 8.101 4.101 L 4.101 8.101 L 4.667 8.667 L 5.232 9.232 L 9.232 5.232 L 8.667 4.667 Z M 4.667 4.667 L 4.101 5.232 L 8.101 9.232 L 8.667 8.667 L 9.232 8.101 L 5.232 4.101 L 4.667 4.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333)\"/>"
    },
    "XCircleSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 11.54 6.54 C 11.931 6.15 11.931 5.517 11.54 5.126 C 11.15 4.736 10.517 4.736 10.126 5.126 L 10.833 5.833 L 11.54 6.54 Z M 5.126 10.126 C 4.736 10.517 4.736 11.15 5.126 11.54 C 5.517 11.931 6.15 11.931 6.54 11.54 L 5.833 10.833 L 5.126 10.126 Z M 6.54 5.126 C 6.15 4.736 5.517 4.736 5.126 5.126 C 4.736 5.517 4.736 6.15 5.126 6.54 L 5.833 5.833 L 6.54 5.126 Z M 10.126 11.54 C 10.517 11.931 11.15 11.931 11.54 11.54 C 11.931 11.15 11.931 10.517 11.54 10.126 L 10.833 10.833 L 10.126 11.54 Z M 16.667 8.333 L 15.667 8.333 C 15.667 12.383 12.383 15.667 8.333 15.667 L 8.333 16.667 L 8.333 17.667 C 13.488 17.667 17.667 13.488 17.667 8.333 L 16.667 8.333 Z M 8.333 16.667 L 8.333 15.667 C 4.283 15.667 1 12.383 1 8.333 L 0 8.333 L -1 8.333 C -1 13.488 3.179 17.667 8.333 17.667 L 8.333 16.667 Z M 0 8.333 L 1 8.333 C 1 4.283 4.283 1 8.333 1 L 8.333 0 L 8.333 -1 C 3.179 -1 -1 3.179 -1 8.333 L 0 8.333 Z M 8.333 0 L 8.333 1 C 12.383 1 15.667 4.283 15.667 8.333 L 16.667 8.333 L 17.667 8.333 C 17.667 3.179 13.488 -1 8.333 -1 L 8.333 0 Z M 10.833 5.833 L 10.126 5.126 L 5.126 10.126 L 5.833 10.833 L 6.54 11.54 L 11.54 6.54 L 10.833 5.833 Z M 5.833 5.833 L 5.126 6.54 L 10.126 11.54 L 10.833 10.833 L 11.54 10.126 L 6.54 5.126 L 5.833 5.833 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "XCircleSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 13.884 7.884 C 14.372 7.396 14.372 6.604 13.884 6.116 C 13.396 5.628 12.604 5.628 12.116 6.116 L 13 7 L 13.884 7.884 Z M 6.116 12.116 C 5.628 12.604 5.628 13.396 6.116 13.884 C 6.604 14.372 7.396 14.372 7.884 13.884 L 7 13 L 6.116 12.116 Z M 7.884 6.116 C 7.396 5.628 6.604 5.628 6.116 6.116 C 5.628 6.604 5.628 7.396 6.116 7.884 L 7 7 L 7.884 6.116 Z M 12.116 13.884 C 12.604 14.372 13.396 14.372 13.884 13.884 C 14.372 13.396 14.372 12.604 13.884 12.116 L 13 13 L 12.116 13.884 Z M 20 10 L 18.75 10 C 18.75 14.832 14.832 18.75 10 18.75 L 10 20 L 10 21.25 C 16.213 21.25 21.25 16.213 21.25 10 L 20 10 Z M 10 20 L 10 18.75 C 5.168 18.75 1.25 14.832 1.25 10 L 0 10 L -1.25 10 C -1.25 16.213 3.787 21.25 10 21.25 L 10 20 Z M 0 10 L 1.25 10 C 1.25 5.168 5.168 1.25 10 1.25 L 10 0 L 10 -1.25 C 3.787 -1.25 -1.25 3.787 -1.25 10 L 0 10 Z M 10 0 L 10 1.25 C 14.832 1.25 18.75 5.168 18.75 10 L 20 10 L 21.25 10 C 21.25 3.787 16.213 -1.25 10 -1.25 L 10 0 Z M 13 7 L 12.116 6.116 L 6.116 12.116 L 7 13 L 7.884 13.884 L 13.884 7.884 L 13 7 Z M 7 7 L 6.116 7.884 L 12.116 13.884 L 13 13 L 13.884 12.116 L 7.884 6.116 L 7 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "XCircleSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 18.394 10.394 C 18.98 9.808 18.98 8.858 18.394 8.273 C 17.808 7.687 16.858 7.687 16.273 8.273 L 17.333 9.333 L 18.394 10.394 Z M 8.273 16.273 C 7.687 16.858 7.687 17.808 8.273 18.394 C 8.858 18.98 9.808 18.98 10.394 18.394 L 9.333 17.333 L 8.273 16.273 Z M 10.394 8.273 C 9.808 7.687 8.858 7.687 8.273 8.273 C 7.687 8.858 7.687 9.808 8.273 10.394 L 9.333 9.333 L 10.394 8.273 Z M 16.273 18.394 C 16.858 18.98 17.808 18.98 18.394 18.394 C 18.98 17.808 18.98 16.858 18.394 16.273 L 17.333 17.333 L 16.273 18.394 Z M 26.667 13.333 L 25.167 13.333 C 25.167 19.869 19.869 25.167 13.333 25.167 L 13.333 26.667 L 13.333 28.167 C 21.526 28.167 28.167 21.526 28.167 13.333 L 26.667 13.333 Z M 13.333 26.667 L 13.333 25.167 C 6.798 25.167 1.5 19.869 1.5 13.333 L 0 13.333 L -1.5 13.333 C -1.5 21.526 5.141 28.167 13.333 28.167 L 13.333 26.667 Z M 0 13.333 L 1.5 13.333 C 1.5 6.798 6.798 1.5 13.333 1.5 L 13.333 0 L 13.333 -1.5 C 5.141 -1.5 -1.5 5.141 -1.5 13.333 L 0 13.333 Z M 13.333 0 L 13.333 1.5 C 19.869 1.5 25.167 6.798 25.167 13.333 L 26.667 13.333 L 28.167 13.333 C 28.167 5.141 21.526 -1.5 13.333 -1.5 L 13.333 0 Z M 17.333 9.333 L 16.273 8.273 L 8.273 16.273 L 9.333 17.333 L 10.394 18.394 L 18.394 10.394 L 17.333 9.333 Z M 9.333 9.333 L 8.273 10.394 L 16.273 18.394 L 17.333 17.333 L 18.394 16.273 L 10.394 8.273 L 9.333 9.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 2.667)\"/>"
    },
    "XCircleSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 22.904 12.904 C 23.588 12.221 23.588 11.113 22.904 10.429 C 22.221 9.746 21.113 9.746 20.429 10.429 L 21.667 11.667 L 22.904 12.904 Z M 10.429 20.429 C 9.746 21.113 9.746 22.221 10.429 22.904 C 11.113 23.588 12.221 23.588 12.904 22.904 L 11.667 21.667 L 10.429 20.429 Z M 12.904 10.429 C 12.221 9.746 11.113 9.746 10.429 10.429 C 9.746 11.113 9.746 12.221 10.429 12.904 L 11.667 11.667 L 12.904 10.429 Z M 20.429 22.904 C 21.113 23.588 22.221 23.588 22.904 22.904 C 23.588 22.221 23.588 21.113 22.904 20.429 L 21.667 21.667 L 20.429 22.904 Z M 33.333 16.667 L 31.583 16.667 C 31.583 24.905 24.905 31.583 16.667 31.583 L 16.667 33.333 L 16.667 35.083 C 26.838 35.083 35.083 26.838 35.083 16.667 L 33.333 16.667 Z M 16.667 33.333 L 16.667 31.583 C 8.428 31.583 1.75 24.905 1.75 16.667 L 0 16.667 L -1.75 16.667 C -1.75 26.838 6.495 35.083 16.667 35.083 L 16.667 33.333 Z M 0 16.667 L 1.75 16.667 C 1.75 8.428 8.428 1.75 16.667 1.75 L 16.667 0 L 16.667 -1.75 C 6.495 -1.75 -1.75 6.495 -1.75 16.667 L 0 16.667 Z M 16.667 0 L 16.667 1.75 C 24.905 1.75 31.583 8.428 31.583 16.667 L 33.333 16.667 L 35.083 16.667 C 35.083 6.495 26.838 -1.75 16.667 -1.75 L 16.667 0 Z M 21.667 11.667 L 20.429 10.429 L 10.429 20.429 L 11.667 21.667 L 12.904 22.904 L 22.904 12.904 L 21.667 11.667 Z M 11.667 11.667 L 10.429 12.904 L 20.429 22.904 L 21.667 21.667 L 22.904 20.429 L 12.904 10.429 L 11.667 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.333 3.333)\"/>"
    },
    "XCircleSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 27.414 15.414 C 28.195 14.633 28.195 13.367 27.414 12.586 C 26.633 11.805 25.367 11.805 24.586 12.586 L 26 14 L 27.414 15.414 Z M 12.586 24.586 C 11.805 25.367 11.805 26.633 12.586 27.414 C 13.367 28.195 14.633 28.195 15.414 27.414 L 14 26 L 12.586 24.586 Z M 15.414 12.586 C 14.633 11.805 13.367 11.805 12.586 12.586 C 11.805 13.367 11.805 14.633 12.586 15.414 L 14 14 L 15.414 12.586 Z M 24.586 27.414 C 25.367 28.195 26.633 28.195 27.414 27.414 C 28.195 26.633 28.195 25.367 27.414 24.586 L 26 26 L 24.586 27.414 Z M 40 20 L 38 20 C 38 29.941 29.941 38 20 38 L 20 40 L 20 42 C 32.15 42 42 32.15 42 20 L 40 20 Z M 20 40 L 20 38 C 10.059 38 2 29.941 2 20 L 0 20 L -2 20 C -2 32.15 7.85 42 20 42 L 20 40 Z M 0 20 L 2 20 C 2 10.059 10.059 2 20 2 L 20 0 L 20 -2 C 7.85 -2 -2 7.85 -2 20 L 0 20 Z M 20 0 L 20 2 C 29.941 2 38 10.059 38 20 L 40 20 L 42 20 C 42 7.85 32.15 -2 20 -2 L 20 0 Z M 26 14 L 24.586 12.586 L 12.586 24.586 L 14 26 L 15.414 27.414 L 27.414 15.414 L 26 14 Z M 14 14 L 12.586 15.414 L 24.586 27.414 L 26 26 L 27.414 24.586 L 15.414 12.586 L 14 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "XSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 8.566 0.566 C 8.878 0.253 8.878 -0.253 8.566 -0.566 C 8.253 -0.878 7.747 -0.878 7.434 -0.566 L 8 0 L 8.566 0.566 Z M -0.566 7.434 C -0.878 7.747 -0.878 8.253 -0.566 8.566 C -0.253 8.878 0.253 8.878 0.566 8.566 L 0 8 L -0.566 7.434 Z M 0.566 -0.566 C 0.253 -0.878 -0.253 -0.878 -0.566 -0.566 C -0.878 -0.253 -0.878 0.253 -0.566 0.566 L 0 0 L 0.566 -0.566 Z M 7.434 8.566 C 7.747 8.878 8.253 8.878 8.566 8.566 C 8.878 8.253 8.878 7.747 8.566 7.434 L 8 8 L 7.434 8.566 Z M 8 0 L 7.434 -0.566 L -0.566 7.434 L 0 8 L 0.566 8.566 L 8.566 0.566 L 8 0 Z M 0 0 L -0.566 0.566 L 7.434 8.566 L 8 8 L 8.566 7.434 L 0.566 -0.566 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "XSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 10.707 0.707 C 11.098 0.317 11.098 -0.317 10.707 -0.707 C 10.317 -1.098 9.683 -1.098 9.293 -0.707 L 10 0 L 10.707 0.707 Z M -0.707 9.293 C -1.098 9.683 -1.098 10.317 -0.707 10.707 C -0.317 11.098 0.317 11.098 0.707 10.707 L 0 10 L -0.707 9.293 Z M 0.707 -0.707 C 0.317 -1.098 -0.317 -1.098 -0.707 -0.707 C -1.098 -0.317 -1.098 0.317 -0.707 0.707 L 0 0 L 0.707 -0.707 Z M 9.293 10.707 C 9.683 11.098 10.317 11.098 10.707 10.707 C 11.098 10.317 11.098 9.683 10.707 9.293 L 10 10 L 9.293 10.707 Z M 10 0 L 9.293 -0.707 L -0.707 9.293 L 0 10 L 0.707 10.707 L 10.707 0.707 L 10 0 Z M 0 0 L -0.707 0.707 L 9.293 10.707 L 10 10 L 10.707 9.293 L 0.707 -0.707 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "XSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12.884 0.884 C 13.372 0.396 13.372 -0.396 12.884 -0.884 C 12.396 -1.372 11.604 -1.372 11.116 -0.884 L 12 0 L 12.884 0.884 Z M -0.884 11.116 C -1.372 11.604 -1.372 12.396 -0.884 12.884 C -0.396 13.372 0.396 13.372 0.884 12.884 L 0 12 L -0.884 11.116 Z M 0.884 -0.884 C 0.396 -1.372 -0.396 -1.372 -0.884 -0.884 C -1.372 -0.396 -1.372 0.396 -0.884 0.884 L 0 0 L 0.884 -0.884 Z M 11.116 12.884 C 11.604 13.372 12.396 13.372 12.884 12.884 C 13.372 12.396 13.372 11.604 12.884 11.116 L 12 12 L 11.116 12.884 Z M 12 0 L 11.116 -0.884 L -0.884 11.116 L 0 12 L 0.884 12.884 L 12.884 0.884 L 12 0 Z M 0 0 L -0.884 0.884 L 11.116 12.884 L 12 12 L 12.884 11.116 L 0.884 -0.884 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    },
    "XSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 17.061 1.061 C 17.646 0.475 17.646 -0.475 17.061 -1.061 C 16.475 -1.646 15.525 -1.646 14.939 -1.061 L 16 0 L 17.061 1.061 Z M -1.061 14.939 C -1.646 15.525 -1.646 16.475 -1.061 17.061 C -0.475 17.646 0.475 17.646 1.061 17.061 L 0 16 L -1.061 14.939 Z M 1.061 -1.061 C 0.475 -1.646 -0.475 -1.646 -1.061 -1.061 C -1.646 -0.475 -1.646 0.475 -1.061 1.061 L 0 0 L 1.061 -1.061 Z M 14.939 17.061 C 15.525 17.646 16.475 17.646 17.061 17.061 C 17.646 16.475 17.646 15.525 17.061 14.939 L 16 16 L 14.939 17.061 Z M 16 0 L 14.939 -1.061 L -1.061 14.939 L 0 16 L 1.061 17.061 L 17.061 1.061 L 16 0 Z M 0 0 L -1.061 1.061 L 14.939 17.061 L 16 16 L 17.061 14.939 L 1.061 -1.061 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 8)\"/>"
    },
    "XSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 21.237 1.237 C 21.921 0.554 21.921 -0.554 21.237 -1.237 C 20.554 -1.921 19.446 -1.921 18.763 -1.237 L 20 0 L 21.237 1.237 Z M -1.237 18.763 C -1.921 19.446 -1.921 20.554 -1.237 21.237 C -0.554 21.921 0.554 21.921 1.237 21.237 L 0 20 L -1.237 18.763 Z M 1.237 -1.237 C 0.554 -1.921 -0.554 -1.921 -1.237 -1.237 C -1.921 -0.554 -1.921 0.554 -1.237 1.237 L 0 0 L 1.237 -1.237 Z M 18.763 21.237 C 19.446 21.921 20.554 21.921 21.237 21.237 C 21.921 20.554 21.921 19.446 21.237 18.763 L 20 20 L 18.763 21.237 Z M 20 0 L 18.763 -1.237 L -1.237 18.763 L 0 20 L 1.237 21.237 L 21.237 1.237 L 20 0 Z M 0 0 L -1.237 1.237 L 18.763 21.237 L 20 20 L 21.237 18.763 L 1.237 -1.237 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 10 10)\"/>"
    },
    "XSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 25.414 1.414 C 26.195 0.633 26.195 -0.633 25.414 -1.414 C 24.633 -2.195 23.367 -2.195 22.586 -1.414 L 24 0 L 25.414 1.414 Z M -1.414 22.586 C -2.195 23.367 -2.195 24.633 -1.414 25.414 C -0.633 26.195 0.633 26.195 1.414 25.414 L 0 24 L -1.414 22.586 Z M 1.414 -1.414 C 0.633 -2.195 -0.633 -2.195 -1.414 -1.414 C -2.195 -0.633 -2.195 0.633 -1.414 1.414 L 0 0 L 1.414 -1.414 Z M 22.586 25.414 C 23.367 26.195 24.633 26.195 25.414 25.414 C 26.195 24.633 26.195 23.367 25.414 22.586 L 24 24 L 22.586 25.414 Z M 24 0 L 22.586 -1.414 L -1.414 22.586 L 0 24 L 1.414 25.414 L 25.414 1.414 L 24 0 Z M 0 0 L -1.414 1.414 L 22.586 25.414 L 24 24 L 25.414 22.586 L 1.414 -1.414 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 12 12)\"/>"
    },
    "XSquareSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4.566 3.434 C 4.253 3.122 3.747 3.122 3.434 3.434 C 3.122 3.747 3.122 4.253 3.434 4.566 L 4 4 L 4.566 3.434 Z M 7.434 8.566 C 7.747 8.878 8.253 8.878 8.566 8.566 C 8.878 8.253 8.878 7.747 8.566 7.434 L 8 8 L 7.434 8.566 Z M 8.566 4.566 C 8.878 4.253 8.878 3.747 8.566 3.434 C 8.253 3.122 7.747 3.122 7.434 3.434 L 8 4 L 8.566 4.566 Z M 3.434 7.434 C 3.122 7.747 3.122 8.253 3.434 8.566 C 3.747 8.878 4.253 8.878 4.566 8.566 L 4 8 L 3.434 7.434 Z M 1.333 0 L 1.333 0.8 L 10.667 0.8 L 10.667 0 L 10.667 -0.8 L 1.333 -0.8 L 1.333 0 Z M 10.667 0 L 10.667 0.8 C 10.961 0.8 11.2 1.039 11.2 1.333 L 12 1.333 L 12.8 1.333 C 12.8 0.155 11.845 -0.8 10.667 -0.8 L 10.667 0 Z M 12 1.333 L 11.2 1.333 L 11.2 10.667 L 12 10.667 L 12.8 10.667 L 12.8 1.333 L 12 1.333 Z M 12 10.667 L 11.2 10.667 C 11.2 10.961 10.961 11.2 10.667 11.2 L 10.667 12 L 10.667 12.8 C 11.845 12.8 12.8 11.845 12.8 10.667 L 12 10.667 Z M 10.667 12 L 10.667 11.2 L 1.333 11.2 L 1.333 12 L 1.333 12.8 L 10.667 12.8 L 10.667 12 Z M 1.333 12 L 1.333 11.2 C 1.039 11.2 0.8 10.961 0.8 10.667 L 0 10.667 L -0.8 10.667 C -0.8 11.845 0.155 12.8 1.333 12.8 L 1.333 12 Z M 0 10.667 L 0.8 10.667 L 0.8 1.333 L 0 1.333 L -0.8 1.333 L -0.8 10.667 L 0 10.667 Z M 0 1.333 L 0.8 1.333 C 0.8 1.039 1.039 0.8 1.333 0.8 L 1.333 0 L 1.333 -0.8 C 0.155 -0.8 -0.8 0.155 -0.8 1.333 L 0 1.333 Z M 4 4 L 3.434 4.566 L 7.434 8.566 L 8 8 L 8.566 7.434 L 4.566 3.434 L 4 4 Z M 8 4 L 7.434 3.434 L 3.434 7.434 L 4 8 L 4.566 8.566 L 8.566 4.566 L 8 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "XSquareSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 5.707 4.293 C 5.317 3.902 4.683 3.902 4.293 4.293 C 3.902 4.683 3.902 5.317 4.293 5.707 L 5 5 L 5.707 4.293 Z M 9.293 10.707 C 9.683 11.098 10.317 11.098 10.707 10.707 C 11.098 10.317 11.098 9.683 10.707 9.293 L 10 10 L 9.293 10.707 Z M 10.707 5.707 C 11.098 5.317 11.098 4.683 10.707 4.293 C 10.317 3.902 9.683 3.902 9.293 4.293 L 10 5 L 10.707 5.707 Z M 4.293 9.293 C 3.902 9.683 3.902 10.317 4.293 10.707 C 4.683 11.098 5.317 11.098 5.707 10.707 L 5 10 L 4.293 9.293 Z M 1.667 0 L 1.667 1 L 13.333 1 L 13.333 0 L 13.333 -1 L 1.667 -1 L 1.667 0 Z M 13.333 0 L 13.333 1 C 13.702 1 14 1.298 14 1.667 L 15 1.667 L 16 1.667 C 16 0.194 14.806 -1 13.333 -1 L 13.333 0 Z M 15 1.667 L 14 1.667 L 14 13.333 L 15 13.333 L 16 13.333 L 16 1.667 L 15 1.667 Z M 15 13.333 L 14 13.333 C 14 13.702 13.702 14 13.333 14 L 13.333 15 L 13.333 16 C 14.806 16 16 14.806 16 13.333 L 15 13.333 Z M 13.333 15 L 13.333 14 L 1.667 14 L 1.667 15 L 1.667 16 L 13.333 16 L 13.333 15 Z M 1.667 15 L 1.667 14 C 1.298 14 1 13.702 1 13.333 L 0 13.333 L -1 13.333 C -1 14.806 0.194 16 1.667 16 L 1.667 15 Z M 0 13.333 L 1 13.333 L 1 1.667 L 0 1.667 L -1 1.667 L -1 13.333 L 0 13.333 Z M 0 1.667 L 1 1.667 C 1 1.298 1.298 1 1.667 1 L 1.667 0 L 1.667 -1 C 0.194 -1 -1 0.194 -1 1.667 L 0 1.667 Z M 5 5 L 4.293 5.707 L 9.293 10.707 L 10 10 L 10.707 9.293 L 5.707 4.293 L 5 5 Z M 10 5 L 9.293 4.293 L 4.293 9.293 L 5 10 L 5.707 10.707 L 10.707 5.707 L 10 5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.500 2.500)\"/>"
    },
    "XSquareSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.884 5.116 C 6.396 4.628 5.604 4.628 5.116 5.116 C 4.628 5.604 4.628 6.396 5.116 6.884 L 6 6 L 6.884 5.116 Z M 11.116 12.884 C 11.604 13.372 12.396 13.372 12.884 12.884 C 13.372 12.396 13.372 11.604 12.884 11.116 L 12 12 L 11.116 12.884 Z M 12.884 6.884 C 13.372 6.396 13.372 5.604 12.884 5.116 C 12.396 4.628 11.604 4.628 11.116 5.116 L 12 6 L 12.884 6.884 Z M 5.116 11.116 C 4.628 11.604 4.628 12.396 5.116 12.884 C 5.604 13.372 6.396 13.372 6.884 12.884 L 6 12 L 5.116 11.116 Z M 2 0 L 2 1.25 L 16 1.25 L 16 0 L 16 -1.25 L 2 -1.25 L 2 0 Z M 16 0 L 16 1.25 C 16.414 1.25 16.75 1.586 16.75 2 L 18 2 L 19.25 2 C 19.25 0.205 17.795 -1.25 16 -1.25 L 16 0 Z M 18 2 L 16.75 2 L 16.75 16 L 18 16 L 19.25 16 L 19.25 2 L 18 2 Z M 18 16 L 16.75 16 C 16.75 16.414 16.414 16.75 16 16.75 L 16 18 L 16 19.25 C 17.795 19.25 19.25 17.795 19.25 16 L 18 16 Z M 16 18 L 16 16.75 L 2 16.75 L 2 18 L 2 19.25 L 16 19.25 L 16 18 Z M 2 18 L 2 16.75 C 1.586 16.75 1.25 16.414 1.25 16 L 0 16 L -1.25 16 C -1.25 17.795 0.205 19.25 2 19.25 L 2 18 Z M 0 16 L 1.25 16 L 1.25 2 L 0 2 L -1.25 2 L -1.25 16 L 0 16 Z M 0 2 L 1.25 2 C 1.25 1.586 1.586 1.25 2 1.25 L 2 0 L 2 -1.25 C 0.205 -1.25 -1.25 0.205 -1.25 2 L 0 2 Z M 6 6 L 5.116 6.884 L 11.116 12.884 L 12 12 L 12.884 11.116 L 6.884 5.116 L 6 6 Z M 12 6 L 11.116 5.116 L 5.116 11.116 L 6 12 L 6.884 12.884 L 12.884 6.884 L 12 6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "XSquareSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 9.061 6.939 C 8.475 6.354 7.525 6.354 6.939 6.939 C 6.354 7.525 6.354 8.475 6.939 9.061 L 8 8 L 9.061 6.939 Z M 14.939 17.061 C 15.525 17.646 16.475 17.646 17.061 17.061 C 17.646 16.475 17.646 15.525 17.061 14.939 L 16 16 L 14.939 17.061 Z M 17.061 9.061 C 17.646 8.475 17.646 7.525 17.061 6.939 C 16.475 6.354 15.525 6.354 14.939 6.939 L 16 8 L 17.061 9.061 Z M 6.939 14.939 C 6.354 15.525 6.354 16.475 6.939 17.061 C 7.525 17.646 8.475 17.646 9.061 17.061 L 8 16 L 6.939 14.939 Z M 2.667 0 L 2.667 1.5 L 21.333 1.5 L 21.333 0 L 21.333 -1.5 L 2.667 -1.5 L 2.667 0 Z M 21.333 0 L 21.333 1.5 C 21.978 1.5 22.5 2.022 22.5 2.667 L 24 2.667 L 25.5 2.667 C 25.5 0.365 23.635 -1.5 21.333 -1.5 L 21.333 0 Z M 24 2.667 L 22.5 2.667 L 22.5 21.333 L 24 21.333 L 25.5 21.333 L 25.5 2.667 L 24 2.667 Z M 24 21.333 L 22.5 21.333 C 22.5 21.978 21.978 22.5 21.333 22.5 L 21.333 24 L 21.333 25.5 C 23.635 25.5 25.5 23.635 25.5 21.333 L 24 21.333 Z M 21.333 24 L 21.333 22.5 L 2.667 22.5 L 2.667 24 L 2.667 25.5 L 21.333 25.5 L 21.333 24 Z M 2.667 24 L 2.667 22.5 C 2.022 22.5 1.5 21.978 1.5 21.333 L 0 21.333 L -1.5 21.333 C -1.5 23.635 0.365 25.5 2.667 25.5 L 2.667 24 Z M 0 21.333 L 1.5 21.333 L 1.5 2.667 L 0 2.667 L -1.5 2.667 L -1.5 21.333 L 0 21.333 Z M 0 2.667 L 1.5 2.667 C 1.5 2.022 2.022 1.5 2.667 1.5 L 2.667 0 L 2.667 -1.5 C 0.365 -1.5 -1.5 0.365 -1.5 2.667 L 0 2.667 Z M 8 8 L 6.939 9.061 L 14.939 17.061 L 16 16 L 17.061 14.939 L 9.061 6.939 L 8 8 Z M 16 8 L 14.939 6.939 L 6.939 14.939 L 8 16 L 9.061 17.061 L 17.061 9.061 L 16 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "XSquareSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 11.237 8.763 C 10.554 8.079 9.446 8.079 8.763 8.763 C 8.079 9.446 8.079 10.554 8.763 11.237 L 10 10 L 11.237 8.763 Z M 18.763 21.237 C 19.446 21.921 20.554 21.921 21.237 21.237 C 21.921 20.554 21.921 19.446 21.237 18.763 L 20 20 L 18.763 21.237 Z M 21.237 11.237 C 21.921 10.554 21.921 9.446 21.237 8.763 C 20.554 8.079 19.446 8.079 18.763 8.763 L 20 10 L 21.237 11.237 Z M 8.763 18.763 C 8.079 19.446 8.079 20.554 8.763 21.237 C 9.446 21.921 10.554 21.921 11.237 21.237 L 10 20 L 8.763 18.763 Z M 3.333 0 L 3.333 1.75 L 26.667 1.75 L 26.667 0 L 26.667 -1.75 L 3.333 -1.75 L 3.333 0 Z M 26.667 0 L 26.667 1.75 C 27.541 1.75 28.25 2.459 28.25 3.333 L 30 3.333 L 31.75 3.333 C 31.75 0.526 29.474 -1.75 26.667 -1.75 L 26.667 0 Z M 30 3.333 L 28.25 3.333 L 28.25 26.667 L 30 26.667 L 31.75 26.667 L 31.75 3.333 L 30 3.333 Z M 30 26.667 L 28.25 26.667 C 28.25 27.541 27.541 28.25 26.667 28.25 L 26.667 30 L 26.667 31.75 C 29.474 31.75 31.75 29.474 31.75 26.667 L 30 26.667 Z M 26.667 30 L 26.667 28.25 L 3.333 28.25 L 3.333 30 L 3.333 31.75 L 26.667 31.75 L 26.667 30 Z M 3.333 30 L 3.333 28.25 C 2.459 28.25 1.75 27.541 1.75 26.667 L 0 26.667 L -1.75 26.667 C -1.75 29.474 0.526 31.75 3.333 31.75 L 3.333 30 Z M 0 26.667 L 1.75 26.667 L 1.75 3.333 L 0 3.333 L -1.75 3.333 L -1.75 26.667 L 0 26.667 Z M 0 3.333 L 1.75 3.333 C 1.75 2.459 2.459 1.75 3.333 1.75 L 3.333 0 L 3.333 -1.75 C 0.526 -1.75 -1.75 0.526 -1.75 3.333 L 0 3.333 Z M 10 10 L 8.763 11.237 L 18.763 21.237 L 20 20 L 21.237 18.763 L 11.237 8.763 L 10 10 Z M 20 10 L 18.763 8.763 L 8.763 18.763 L 10 20 L 11.237 21.237 L 21.237 11.237 L 20 10 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "XSquareSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 13.414 10.586 C 12.633 9.805 11.367 9.805 10.586 10.586 C 9.805 11.367 9.805 12.633 10.586 13.414 L 12 12 L 13.414 10.586 Z M 22.586 25.414 C 23.367 26.195 24.633 26.195 25.414 25.414 C 26.195 24.633 26.195 23.367 25.414 22.586 L 24 24 L 22.586 25.414 Z M 25.414 13.414 C 26.195 12.633 26.195 11.367 25.414 10.586 C 24.633 9.805 23.367 9.805 22.586 10.586 L 24 12 L 25.414 13.414 Z M 10.586 22.586 C 9.805 23.367 9.805 24.633 10.586 25.414 C 11.367 26.195 12.633 26.195 13.414 25.414 L 12 24 L 10.586 22.586 Z M 4 0 L 4 2 L 32 2 L 32 0 L 32 -2 L 4 -2 L 4 0 Z M 32 0 L 32 2 C 33.105 2 34 2.895 34 4 L 36 4 L 38 4 C 38 0.686 35.314 -2 32 -2 L 32 0 Z M 36 4 L 34 4 L 34 32 L 36 32 L 38 32 L 38 4 L 36 4 Z M 36 32 L 34 32 C 34 33.105 33.105 34 32 34 L 32 36 L 32 38 C 35.314 38 38 35.314 38 32 L 36 32 Z M 32 36 L 32 34 L 4 34 L 4 36 L 4 38 L 32 38 L 32 36 Z M 4 36 L 4 34 C 2.895 34 2 33.105 2 32 L 0 32 L -2 32 C -2 35.314 0.686 38 4 38 L 4 36 Z M 0 32 L 2 32 L 2 4 L 0 4 L -2 4 L -2 32 L 0 32 Z M 0 4 L 2 4 C 2 2.895 2.895 2 4 2 L 4 0 L 4 -2 C 0.686 -2 -2 0.686 -2 4 L 0 4 Z M 12 12 L 10.586 13.414 L 22.586 25.414 L 24 24 L 25.414 22.586 L 13.414 10.586 L 12 12 Z M 24 12 L 22.586 10.586 L 10.586 22.586 L 12 24 L 13.414 25.414 L 25.414 13.414 L 24 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    },
    "ImageSize16": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 11.434 8.566 C 11.747 8.878 12.253 8.878 12.566 8.566 C 12.878 8.253 12.878 7.747 12.566 7.434 L 12 8 L 11.434 8.566 Z M 8.667 4.667 L 9.232 4.101 C 8.92 3.789 8.413 3.789 8.101 4.101 L 8.667 4.667 Z M 1.333 0 L 1.333 0.8 L 10.667 0.8 L 10.667 0 L 10.667 -0.8 L 1.333 -0.8 L 1.333 0 Z M 10.667 0 L 10.667 0.8 C 10.961 0.8 11.2 1.039 11.2 1.333 L 12 1.333 L 12.8 1.333 C 12.8 0.155 11.845 -0.8 10.667 -0.8 L 10.667 0 Z M 12 1.333 L 11.2 1.333 L 11.2 10.667 L 12 10.667 L 12.8 10.667 L 12.8 1.333 L 12 1.333 Z M 12 10.667 L 11.2 10.667 C 11.2 10.961 10.961 11.2 10.667 11.2 L 10.667 12 L 10.667 12.8 C 11.845 12.8 12.8 11.845 12.8 10.667 L 12 10.667 Z M 10.667 12 L 10.667 11.2 L 1.333 11.2 L 1.333 12 L 1.333 12.8 L 10.667 12.8 L 10.667 12 Z M 1.333 12 L 1.333 11.2 C 1.039 11.2 0.8 10.961 0.8 10.667 L 0 10.667 L -0.8 10.667 C -0.8 11.845 0.155 12.8 1.333 12.8 L 1.333 12 Z M 0 10.667 L 0.8 10.667 L 0.8 1.333 L 0 1.333 L -0.8 1.333 L -0.8 10.667 L 0 10.667 Z M 0 1.333 L 0.8 1.333 C 0.8 1.039 1.039 0.8 1.333 0.8 L 1.333 0 L 1.333 -0.8 C 0.155 -0.8 -0.8 0.155 -0.8 1.333 L 0 1.333 Z M 4.667 3.667 L 3.867 3.667 C 3.867 3.777 3.777 3.867 3.667 3.867 L 3.667 4.667 L 3.667 5.467 C 4.661 5.467 5.467 4.661 5.467 3.667 L 4.667 3.667 Z M 3.667 4.667 L 3.667 3.867 C 3.556 3.867 3.467 3.777 3.467 3.667 L 2.667 3.667 L 1.867 3.667 C 1.867 4.661 2.673 5.467 3.667 5.467 L 3.667 4.667 Z M 2.667 3.667 L 3.467 3.667 C 3.467 3.556 3.556 3.467 3.667 3.467 L 3.667 2.667 L 3.667 1.867 C 2.673 1.867 1.867 2.673 1.867 3.667 L 2.667 3.667 Z M 3.667 2.667 L 3.667 3.467 C 3.777 3.467 3.867 3.556 3.867 3.667 L 4.667 3.667 L 5.467 3.667 C 5.467 2.673 4.661 1.867 3.667 1.867 L 3.667 2.667 Z M 12 8 L 12.566 7.434 L 9.232 4.101 L 8.667 4.667 L 8.101 5.232 L 11.434 8.566 L 12 8 Z M 8.667 4.667 L 8.101 4.101 L 0.768 11.434 L 1.333 12 L 1.899 12.566 L 9.232 5.232 L 8.667 4.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "ImageSize20": {
      viewBox: "0 0 20 20",
      body: "<path d=\"M 14.293 10.707 C 14.683 11.098 15.317 11.098 15.707 10.707 C 16.098 10.317 16.098 9.683 15.707 9.293 L 15 10 L 14.293 10.707 Z M 10.833 5.833 L 11.54 5.126 C 11.15 4.736 10.517 4.736 10.126 5.126 L 10.833 5.833 Z M 1.667 0 L 1.667 1 L 13.333 1 L 13.333 0 L 13.333 -1 L 1.667 -1 L 1.667 0 Z M 13.333 0 L 13.333 1 C 13.702 1 14 1.298 14 1.667 L 15 1.667 L 16 1.667 C 16 0.194 14.806 -1 13.333 -1 L 13.333 0 Z M 15 1.667 L 14 1.667 L 14 13.333 L 15 13.333 L 16 13.333 L 16 1.667 L 15 1.667 Z M 15 13.333 L 14 13.333 C 14 13.702 13.702 14 13.333 14 L 13.333 15 L 13.333 16 C 14.806 16 16 14.806 16 13.333 L 15 13.333 Z M 13.333 15 L 13.333 14 L 1.667 14 L 1.667 15 L 1.667 16 L 13.333 16 L 13.333 15 Z M 1.667 15 L 1.667 14 C 1.298 14 1 13.702 1 13.333 L 0 13.333 L -1 13.333 C -1 14.806 0.194 16 1.667 16 L 1.667 15 Z M 0 13.333 L 1 13.333 L 1 1.667 L 0 1.667 L -1 1.667 L -1 13.333 L 0 13.333 Z M 0 1.667 L 1 1.667 C 1 1.298 1.298 1 1.667 1 L 1.667 0 L 1.667 -1 C 0.194 -1 -1 0.194 -1 1.667 L 0 1.667 Z M 5.833 4.583 L 4.833 4.583 C 4.833 4.721 4.721 4.833 4.583 4.833 L 4.583 5.833 L 4.583 6.833 C 5.826 6.833 6.833 5.826 6.833 4.583 L 5.833 4.583 Z M 4.583 5.833 L 4.583 4.833 C 4.445 4.833 4.333 4.721 4.333 4.583 L 3.333 4.583 L 2.333 4.583 C 2.333 5.826 3.341 6.833 4.583 6.833 L 4.583 5.833 Z M 3.333 4.583 L 4.333 4.583 C 4.333 4.445 4.445 4.333 4.583 4.333 L 4.583 3.333 L 4.583 2.333 C 3.341 2.333 2.333 3.341 2.333 4.583 L 3.333 4.583 Z M 4.583 3.333 L 4.583 4.333 C 4.721 4.333 4.833 4.445 4.833 4.583 L 5.833 4.583 L 6.833 4.583 C 6.833 3.341 5.826 2.333 4.583 2.333 L 4.583 3.333 Z M 15 10 L 15.707 9.293 L 11.54 5.126 L 10.833 5.833 L 10.126 6.54 L 14.293 10.707 L 15 10 Z M 10.833 5.833 L 10.126 5.126 L 0.96 14.293 L 1.667 15 L 2.374 15.707 L 11.54 6.54 L 10.833 5.833 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.500 2.500)\"/>"
    },
    "ImageSize24": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 17.116 12.884 C 17.604 13.372 18.396 13.372 18.884 12.884 C 19.372 12.396 19.372 11.604 18.884 11.116 L 18 12 L 17.116 12.884 Z M 13 7 L 13.884 6.116 C 13.396 5.628 12.604 5.628 12.116 6.116 L 13 7 Z M 2 0 L 2 1.25 L 16 1.25 L 16 0 L 16 -1.25 L 2 -1.25 L 2 0 Z M 16 0 L 16 1.25 C 16.414 1.25 16.75 1.586 16.75 2 L 18 2 L 19.25 2 C 19.25 0.205 17.795 -1.25 16 -1.25 L 16 0 Z M 18 2 L 16.75 2 L 16.75 16 L 18 16 L 19.25 16 L 19.25 2 L 18 2 Z M 18 16 L 16.75 16 C 16.75 16.414 16.414 16.75 16 16.75 L 16 18 L 16 19.25 C 17.795 19.25 19.25 17.795 19.25 16 L 18 16 Z M 16 18 L 16 16.75 L 2 16.75 L 2 18 L 2 19.25 L 16 19.25 L 16 18 Z M 2 18 L 2 16.75 C 1.586 16.75 1.25 16.414 1.25 16 L 0 16 L -1.25 16 C -1.25 17.795 0.205 19.25 2 19.25 L 2 18 Z M 0 16 L 1.25 16 L 1.25 2 L 0 2 L -1.25 2 L -1.25 16 L 0 16 Z M 0 2 L 1.25 2 C 1.25 1.586 1.586 1.25 2 1.25 L 2 0 L 2 -1.25 C 0.205 -1.25 -1.25 0.205 -1.25 2 L 0 2 Z M 7 5.5 L 5.75 5.5 C 5.75 5.638 5.638 5.75 5.5 5.75 L 5.5 7 L 5.5 8.25 C 7.019 8.25 8.25 7.019 8.25 5.5 L 7 5.5 Z M 5.5 7 L 5.5 5.75 C 5.362 5.75 5.25 5.638 5.25 5.5 L 4 5.5 L 2.75 5.5 C 2.75 7.019 3.981 8.25 5.5 8.25 L 5.5 7 Z M 4 5.5 L 5.25 5.5 C 5.25 5.362 5.362 5.25 5.5 5.25 L 5.5 4 L 5.5 2.75 C 3.981 2.75 2.75 3.981 2.75 5.5 L 4 5.5 Z M 5.5 4 L 5.5 5.25 C 5.638 5.25 5.75 5.362 5.75 5.5 L 7 5.5 L 8.25 5.5 C 8.25 3.981 7.019 2.75 5.5 2.75 L 5.5 4 Z M 18 12 L 18.884 11.116 L 13.884 6.116 L 13 7 L 12.116 7.884 L 17.116 12.884 L 18 12 Z M 13 7 L 12.116 6.116 L 1.116 17.116 L 2 18 L 2.884 18.884 L 13.884 7.884 L 13 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "ImageSize32": {
      viewBox: "0 0 32 32",
      body: "<path d=\"M 22.939 17.061 C 23.525 17.646 24.475 17.646 25.061 17.061 C 25.646 16.475 25.646 15.525 25.061 14.939 L 24 16 L 22.939 17.061 Z M 17.333 9.333 L 18.394 8.273 C 17.808 7.687 16.858 7.687 16.273 8.273 L 17.333 9.333 Z M 2.667 0 L 2.667 1.5 L 21.333 1.5 L 21.333 0 L 21.333 -1.5 L 2.667 -1.5 L 2.667 0 Z M 21.333 0 L 21.333 1.5 C 21.978 1.5 22.5 2.022 22.5 2.667 L 24 2.667 L 25.5 2.667 C 25.5 0.365 23.635 -1.5 21.333 -1.5 L 21.333 0 Z M 24 2.667 L 22.5 2.667 L 22.5 21.333 L 24 21.333 L 25.5 21.333 L 25.5 2.667 L 24 2.667 Z M 24 21.333 L 22.5 21.333 C 22.5 21.978 21.978 22.5 21.333 22.5 L 21.333 24 L 21.333 25.5 C 23.635 25.5 25.5 23.635 25.5 21.333 L 24 21.333 Z M 21.333 24 L 21.333 22.5 L 2.667 22.5 L 2.667 24 L 2.667 25.5 L 21.333 25.5 L 21.333 24 Z M 2.667 24 L 2.667 22.5 C 2.022 22.5 1.5 21.978 1.5 21.333 L 0 21.333 L -1.5 21.333 C -1.5 23.635 0.365 25.5 2.667 25.5 L 2.667 24 Z M 0 21.333 L 1.5 21.333 L 1.5 2.667 L 0 2.667 L -1.5 2.667 L -1.5 21.333 L 0 21.333 Z M 0 2.667 L 1.5 2.667 C 1.5 2.022 2.022 1.5 2.667 1.5 L 2.667 0 L 2.667 -1.5 C 0.365 -1.5 -1.5 0.365 -1.5 2.667 L 0 2.667 Z M 9.333 7.333 L 7.833 7.333 C 7.833 7.609 7.609 7.833 7.333 7.833 L 7.333 9.333 L 7.333 10.833 C 9.266 10.833 10.833 9.266 10.833 7.333 L 9.333 7.333 Z M 7.333 9.333 L 7.333 7.833 C 7.057 7.833 6.833 7.609 6.833 7.333 L 5.333 7.333 L 3.833 7.333 C 3.833 9.266 5.4 10.833 7.333 10.833 L 7.333 9.333 Z M 5.333 7.333 L 6.833 7.333 C 6.833 7.057 7.057 6.833 7.333 6.833 L 7.333 5.333 L 7.333 3.833 C 5.4 3.833 3.833 5.4 3.833 7.333 L 5.333 7.333 Z M 7.333 5.333 L 7.333 6.833 C 7.609 6.833 7.833 7.057 7.833 7.333 L 9.333 7.333 L 10.833 7.333 C 10.833 5.4 9.266 3.833 7.333 3.833 L 7.333 5.333 Z M 24 16 L 25.061 14.939 L 18.394 8.273 L 17.333 9.333 L 16.273 10.394 L 22.939 17.061 L 24 16 Z M 17.333 9.333 L 16.273 8.273 L 1.606 22.939 L 2.667 24 L 3.727 25.061 L 18.394 10.394 L 17.333 9.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "ImageSize40": {
      viewBox: "0 0 40 40",
      body: "<path d=\"M 28.763 21.237 C 29.446 21.921 30.554 21.921 31.237 21.237 C 31.921 20.554 31.921 19.446 31.237 18.763 L 30 20 L 28.763 21.237 Z M 21.667 11.667 L 22.904 10.429 C 22.221 9.746 21.113 9.746 20.429 10.429 L 21.667 11.667 Z M 3.333 0 L 3.333 1.75 L 26.667 1.75 L 26.667 0 L 26.667 -1.75 L 3.333 -1.75 L 3.333 0 Z M 26.667 0 L 26.667 1.75 C 27.541 1.75 28.25 2.459 28.25 3.333 L 30 3.333 L 31.75 3.333 C 31.75 0.526 29.474 -1.75 26.667 -1.75 L 26.667 0 Z M 30 3.333 L 28.25 3.333 L 28.25 26.667 L 30 26.667 L 31.75 26.667 L 31.75 3.333 L 30 3.333 Z M 30 26.667 L 28.25 26.667 C 28.25 27.541 27.541 28.25 26.667 28.25 L 26.667 30 L 26.667 31.75 C 29.474 31.75 31.75 29.474 31.75 26.667 L 30 26.667 Z M 26.667 30 L 26.667 28.25 L 3.333 28.25 L 3.333 30 L 3.333 31.75 L 26.667 31.75 L 26.667 30 Z M 3.333 30 L 3.333 28.25 C 2.459 28.25 1.75 27.541 1.75 26.667 L 0 26.667 L -1.75 26.667 C -1.75 29.474 0.526 31.75 3.333 31.75 L 3.333 30 Z M 0 26.667 L 1.75 26.667 L 1.75 3.333 L 0 3.333 L -1.75 3.333 L -1.75 26.667 L 0 26.667 Z M 0 3.333 L 1.75 3.333 C 1.75 2.459 2.459 1.75 3.333 1.75 L 3.333 0 L 3.333 -1.75 C 0.526 -1.75 -1.75 0.526 -1.75 3.333 L 0 3.333 Z M 11.667 9.167 L 9.917 9.167 C 9.917 9.581 9.581 9.917 9.167 9.917 L 9.167 11.667 L 9.167 13.417 C 11.514 13.417 13.417 11.514 13.417 9.167 L 11.667 9.167 Z M 9.167 11.667 L 9.167 9.917 C 8.752 9.917 8.417 9.581 8.417 9.167 L 6.667 9.167 L 4.917 9.167 C 4.917 11.514 6.819 13.417 9.167 13.417 L 9.167 11.667 Z M 6.667 9.167 L 8.417 9.167 C 8.417 8.752 8.752 8.417 9.167 8.417 L 9.167 6.667 L 9.167 4.917 C 6.819 4.917 4.917 6.819 4.917 9.167 L 6.667 9.167 Z M 9.167 6.667 L 9.167 8.417 C 9.581 8.417 9.917 8.752 9.917 9.167 L 11.667 9.167 L 13.417 9.167 C 13.417 6.819 11.514 4.917 9.167 4.917 L 9.167 6.667 Z M 30 20 L 31.237 18.763 L 22.904 10.429 L 21.667 11.667 L 20.429 12.904 L 28.763 21.237 L 30 20 Z M 21.667 11.667 L 20.429 10.429 L 2.096 28.763 L 3.333 30 L 4.571 31.237 L 22.904 12.904 L 21.667 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "ImageSize48": {
      viewBox: "0 0 48 48",
      body: "<path d=\"M 34.586 25.414 C 35.367 26.195 36.633 26.195 37.414 25.414 C 38.195 24.633 38.195 23.367 37.414 22.586 L 36 24 L 34.586 25.414 Z M 26 14 L 27.414 12.586 C 26.633 11.805 25.367 11.805 24.586 12.586 L 26 14 Z M 4 0 L 4 2 L 32 2 L 32 0 L 32 -2 L 4 -2 L 4 0 Z M 32 0 L 32 2 C 33.105 2 34 2.895 34 4 L 36 4 L 38 4 C 38 0.686 35.314 -2 32 -2 L 32 0 Z M 36 4 L 34 4 L 34 32 L 36 32 L 38 32 L 38 4 L 36 4 Z M 36 32 L 34 32 C 34 33.105 33.105 34 32 34 L 32 36 L 32 38 C 35.314 38 38 35.314 38 32 L 36 32 Z M 32 36 L 32 34 L 4 34 L 4 36 L 4 38 L 32 38 L 32 36 Z M 4 36 L 4 34 C 2.895 34 2 33.105 2 32 L 0 32 L -2 32 C -2 35.314 0.686 38 4 38 L 4 36 Z M 0 32 L 2 32 L 2 4 L 0 4 L -2 4 L -2 32 L 0 32 Z M 0 4 L 2 4 C 2 2.895 2.895 2 4 2 L 4 0 L 4 -2 C 0.686 -2 -2 0.686 -2 4 L 0 4 Z M 14 11 L 12 11 C 12 11.552 11.552 12 11 12 L 11 14 L 11 16 C 13.761 16 16 13.761 16 11 L 14 11 Z M 11 14 L 11 12 C 10.448 12 10 11.552 10 11 L 8 11 L 6 11 C 6 13.761 8.239 16 11 16 L 11 14 Z M 8 11 L 10 11 C 10 10.448 10.448 10 11 10 L 11 8 L 11 6 C 8.239 6 6 8.239 6 11 L 8 11 Z M 11 8 L 11 10 C 11.552 10 12 10.448 12 11 L 14 11 L 16 11 C 16 8.239 13.761 6 11 6 L 11 8 Z M 36 24 L 37.414 22.586 L 27.414 12.586 L 26 14 L 24.586 15.414 L 34.586 25.414 L 36 24 Z M 26 14 L 24.586 12.586 L 2.586 34.586 L 4 36 L 5.414 37.414 L 27.414 15.414 L 26 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    }
  };
} catch {}
Object.assign(__ds_scope, { __ds_default_components_icons_icon_data_12stud1 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/icon-data.js", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_icon_data_12stud1$1nb03e1 = __ds_scope.__ds_default_components_icons_icon_data_12stud1;

// components/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Icon({
  name,
  size,
  ...rest
}) {
  const d = __ds_scope.__ds_default_components_icons_icon_data_12stud1$1nb03e1[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: d.viewBox,
    fill: "none"
    // body strings are emitter-controlled <path> markup — geometry,
    // numeric fills and transforms only; no .fig-authored text reaches them.
    ,
    dangerouslySetInnerHTML: {
      __html: d.body
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon, __ds_default_components_icons_Icon_fio49a: Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$cekuiz = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Check.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Check" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const CHECK_SIZES = [16, 20, 24, 32, 40, 48];
function Check({
  size = 24,
  ...rest
}) {
  const s = CHECK_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$cekuiz, _extends({
    name: 'CheckSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Check, __ds_default_components_icons_Check_es6mcj: Check });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Check.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$lqbvqf = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/ChevronUp.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Chevron up" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const CHEVRONUP_SIZES = [16, 20, 24, 32, 40, 48];
function ChevronUp({
  size = 24,
  ...rest
}) {
  const s = CHEVRONUP_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$lqbvqf, _extends({
    name: 'ChevronUpSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { ChevronUp, __ds_default_components_icons_ChevronUp_1vto3jz: ChevronUp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/ChevronUp.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$1qlbmyw = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Copy.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Copy" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const COPY_SIZES = [16, 20, 24, 32, 40, 48];
function Copy({
  size = 24,
  ...rest
}) {
  const s = COPY_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$1qlbmyw, _extends({
    name: 'CopySize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Copy, __ds_default_components_icons_Copy_fijs00: Copy });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Copy.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$s2bzvp = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Download.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Download" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const DOWNLOAD_SIZES = [16, 20, 24, 32, 40, 48];
function Download({
  size = 24,
  ...rest
}) {
  const s = DOWNLOAD_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$s2bzvp, _extends({
    name: 'DownloadSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Download, __ds_default_components_icons_Download_q9z1od: Download });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Download.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$2qe4he = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/FileText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "File text" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const FILETEXT_SIZES = [16, 20, 24, 32, 40, 48];
function FileText({
  size = 24,
  ...rest
}) {
  const s = FILETEXT_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$2qe4he, _extends({
    name: 'FileTextSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { FileText, __ds_default_components_icons_FileText_lx65be: FileText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/FileText.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$nzpf2o = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Image.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Image" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const IMAGE_SIZES = [16, 20, 24, 32, 40, 48];
function Image({
  size = 24,
  ...rest
}) {
  const s = IMAGE_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$nzpf2o, _extends({
    name: 'ImageSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Image, __ds_default_components_icons_Image_ewiw3s: Image });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Image.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$1r5csro = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Loader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Loader" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const LOADER_SIZES = [16, 20, 24, 32, 40, 48];
function Loader({
  size = 24,
  ...rest
}) {
  const s = LOADER_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$1r5csro, _extends({
    name: 'LoaderSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Loader, __ds_default_components_icons_Loader_1vlyaho: Loader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Loader.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$1ffpqzn = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/Sun.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "Sun" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const SUN_SIZES = [16, 20, 24, 32, 40, 48];
function Sun({
  size = 24,
  ...rest
}) {
  const s = SUN_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$1ffpqzn, _extends({
    name: 'SunSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { Sun, __ds_default_components_icons_Sun_fjcquz: Sun });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Sun.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$fo2aat = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/X.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "X" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const X_SIZES = [16, 20, 24, 32, 40, 48];
function X({
  size = 24,
  ...rest
}) {
  const s = X_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$fo2aat, _extends({
    name: 'XSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { X, __ds_default_components_icons_X_ear531: X });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/X.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$ivbqzb = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/XCircle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "X circle" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const XCIRCLE_SIZES = [16, 20, 24, 32, 40, 48];
function XCircle({
  size = 24,
  ...rest
}) {
  const s = XCIRCLE_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$ivbqzb, _extends({
    name: 'XCircleSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { XCircle, __ds_default_components_icons_XCircle_1827zzj: XCircle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/XCircle.jsx", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_components_icons_Icon_fio49a$1yps986 = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

// components/icons/XSquare.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Figma icon family "X square" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const XSQUARE_SIZES = [16, 20, 24, 32, 40, 48];
function XSquare({
  size = 24,
  ...rest
}) {
  const s = XSQUARE_SIZES.reduce((b, v) => Math.abs(v - size) < Math.abs(b - size) ? v : b, 48);
  return /*#__PURE__*/React.createElement(__ds_scope.__ds_default_components_icons_Icon_fio49a$1yps986, _extends({
    name: 'XSquareSize' + s,
    size: size
  }, rest));
}
Object.assign(__ds_scope, { XSquare, __ds_default_components_icons_XSquare_1ikqj5a: XSquare });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/XSquare.jsx", error: String((e && e.message) || e) }); }

// components/media/MediaImage.jsx
try { (() => {
/*
  MediaImage — the standalone "Image" symbol from the .fig (node 87:377):
  40×40 slot, 30×30 stroked image glyph inset 5px, ink rgb(30,30,30).
  Same glyph the app ships as lib/assets/media-image.svg.
*/
function MediaImage({
  size = 40,
  color = 'rgb(30,30,30)',
  style,
  className,
  title = 'Image'
}) {
  return /*#__PURE__*/React.createElement("svg", {
    className: className,
    width: size,
    height: size,
    viewBox: "0 0 40 40",
    fill: "none",
    role: "img",
    "aria-label": title,
    style: {
      color,
      ...style
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.33333 35H31.6667C33.5076 35 35 33.5076 35 31.6667V8.33333C35 6.49238 33.5076 5 31.6667 5H8.33333C6.49238 5 5 6.49238 5 8.33333V31.6667C5 33.5076 6.49238 35 8.33333 35ZM8.33333 35L26.6667 16.6667L35 25M16.6667 14.1667C16.6667 15.5474 15.5474 16.6667 14.1667 16.6667C12.786 16.6667 11.6667 15.5474 11.6667 14.1667C11.6667 12.786 12.786 11.6667 14.1667 11.6667C15.5474 11.6667 16.6667 12.786 16.6667 14.1667Z",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
}
Object.assign(__ds_scope, { MediaImage, __ds_default_components_media_MediaImage_gmhavg: MediaImage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/MediaImage.jsx", error: String((e && e.message) || e) }); }

// components/media/MediaVideo.jsx
try { (() => {
/*
  MediaVideo — the standalone "Video" symbol from the .fig (node 87:372):
  stroked video-camera glyph, ink rgb(30,30,30). Same glyph the app ships
  as lib/assets/media-video.svg.
*/
function MediaVideo({
  size = 32,
  color = 'rgb(30,30,30)',
  style,
  className,
  title = 'Video'
}) {
  return /*#__PURE__*/React.createElement("svg", {
    className: className,
    width: size,
    height: size,
    viewBox: "0 0 32 32",
    fill: "none",
    role: "img",
    "aria-label": title,
    style: {
      color,
      ...style
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M30.6667 9.33329L21.3334 16L30.6667 22.6666V9.33329Z",
    stroke: "currentColor",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M18.6667 6.66663H4.00004C2.52728 6.66663 1.33337 7.86053 1.33337 9.33329V22.6666C1.33337 24.1394 2.52728 25.3333 4.00004 25.3333H18.6667C20.1395 25.3333 21.3334 24.1394 21.3334 22.6666V9.33329C21.3334 7.86053 20.1395 6.66663 18.6667 6.66663Z",
    stroke: "currentColor",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
}
Object.assign(__ds_scope, { MediaVideo, __ds_default_components_media_MediaVideo_gvkq8w: MediaVideo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/MediaVideo.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/AppShell.jsx
try { (() => {
// Color Tool UI kit — app shell: nav, header, view container, library rail
const {
  useState: useStateA
} = React;
const NAV_ITEMS = [{
  key: 'home',
  label: 'Colors'
}, {
  key: 'values',
  label: 'Values'
}, {
  key: 'batch',
  label: 'Batch'
}, {
  key: 'exports',
  label: 'Exports'
}, {
  key: 'settings',
  label: 'Settings'
}];
const VIEW_DESCS = {
  home: 'OKLab color data derived by K-Means++ and plotted for analysis.',
  values: 'Value analysis derived from OKLab lightness.',
  batch: 'Batch analysis across multiple pinned images.',
  exports: 'Export analysis results as SVG, PNG, or CSV.',
  settings: 'Application preferences and defaults.'
};
const SidebarIcon = ({
  open,
  flip
}) => /*#__PURE__*/React.createElement("svg", {
  width: "16",
  height: "16",
  viewBox: "0 0 16 16",
  fill: "currentColor",
  style: flip ? {
    transform: 'scaleX(-1)'
  } : undefined
}, open ? /*#__PURE__*/React.createElement("path", {
  d: "M12.5 1C13.881 1 15 2.119 15 3.5V12.5C15 13.881 13.881 15 12.5 15H3.5C2.119 15 1 13.881 1 12.5V3.5C1 2.119 2.119 1 3.5 1H12.5ZM12.5 14C13.328 14 14 13.328 14 12.5V3.5C14 2.672 13.328 2 12.5 2H7V14H12.5Z"
}) : /*#__PURE__*/React.createElement("path", {
  d: "M12.5 1H3.5C2.122 1 1 2.122 1 3.5V12.5C1 13.879 2.122 15 3.5 15H12.5C13.878 15 15 13.879 15 12.5V3.5C15 2.122 13.878 1 12.5 1ZM2 12.5V3.5C2 2.673 2.673 2 3.5 2H9V14H3.5C2.673 14 2 13.327 2 12.5ZM14 12.5C14 13.327 13.327 14 12.5 14H10V2H12.5C13.327 2 14 2.673 14 3.5V12.5Z"
}));
function BatchView() {
  return /*#__PURE__*/React.createElement("section", {
    className: "batch-stub"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, "Pin two or more images in the Media Bucket to run a batch analysis.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'rgba(33,33,32,0.5)'
    }
  }, "(Batch results view intentionally not recreated in this kit \u2014 see BatchView.svelte for the three-panel layout.)")));
}
function App() {
  const [view, setView] = useStateA('home');
  const [navCollapsed, setNavCollapsed] = useStateA(false);
  const [libraryOpen, setLibraryOpen] = useStateA(true);
  const [loading, setLoading] = useStateA(false);
  const [items, setItems] = useStateA([{
    id: 'a',
    name: 'tavern-reference.jpg',
    pos: '20% 30%'
  }, {
    id: 'b',
    name: 'tavern-crop-01.png',
    pos: '70% 60%'
  }, {
    id: 'c',
    name: 'tavern-crop-02.png',
    pos: '45% 80%'
  }]);
  const [activeId, setActiveId] = useStateA('a');
  const [pinned, setPinned] = useStateA(new Set());
  const hasMedia = items.length > 0 && !!activeId;
  const addMedia = () => {
    setLoading(true);
    setTimeout(() => {
      const id = 'm' + Date.now();
      setItems(xs => [...xs, {
        id,
        name: 'upload-' + (items.length + 1) + '.png',
        pos: '50% 20%'
      }]);
      setActiveId(id);
      setLoading(false);
    }, 900);
  };
  const handlePin = id => {
    if (id === null) return setPinned(new Set());
    setPinned(p => {
      const n = new Set(p);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };
  const handleRemove = id => {
    if (id === null) {
      setItems([]);
      setActiveId(null);
      setPinned(new Set());
      return;
    }
    setItems(xs => xs.filter(x => x.id !== id));
    if (activeId === id) setActiveId(null);
  };
  const active = NAV_ITEMS.find(n => n.key === view);
  return /*#__PURE__*/React.createElement("main", {
    className: (navCollapsed ? 'nav-collapsed ' : '') + (libraryOpen ? 'library-open' : '')
  }, /*#__PURE__*/React.createElement("nav", {
    className: 'nav' + (navCollapsed ? ' collapsed' : ''),
    "data-screen-label": "Navigation"
  }, NAV_ITEMS.map(item => /*#__PURE__*/React.createElement("button", {
    key: item.key,
    className: view === item.key ? 'active' : '',
    onClick: () => setView(item.key)
  }, item.label))), /*#__PURE__*/React.createElement("header", {
    className: "app-header",
    "data-screen-label": "Header"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "header-toggle",
    "aria-label": navCollapsed ? 'Show navigation' : 'Hide navigation',
    onClick: () => setNavCollapsed(!navCollapsed)
  }, /*#__PURE__*/React.createElement(SidebarIcon, {
    open: !navCollapsed
  })), /*#__PURE__*/React.createElement("div", {
    className: "header-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "header-title-group"
  }, /*#__PURE__*/React.createElement("span", {
    className: "header-view-title"
  }, active.label), /*#__PURE__*/React.createElement("span", {
    className: "header-view-desc"
  }, VIEW_DESCS[view]))), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "header-toggle",
    "aria-label": libraryOpen ? 'Close library' : 'Open library',
    onClick: () => setLibraryOpen(!libraryOpen)
  }, /*#__PURE__*/React.createElement(SidebarIcon, {
    open: libraryOpen,
    flip: true
  }))), /*#__PURE__*/React.createElement("section", {
    className: "view-container ct-scroll",
    "data-screen-label": active.label + ' view'
  }, view === 'home' && /*#__PURE__*/React.createElement(ColorsView, {
    hasMedia: hasMedia,
    onAddMedia: addMedia
  }), view === 'values' && /*#__PURE__*/React.createElement(ValuesView, {
    hasMedia: hasMedia,
    onAddMedia: addMedia
  }), view === 'batch' && /*#__PURE__*/React.createElement(BatchView, null), view === 'exports' && /*#__PURE__*/React.createElement(ExportsView, {
    hasMedia: hasMedia
  }), view === 'settings' && /*#__PURE__*/React.createElement(SettingsView, null), /*#__PURE__*/React.createElement(LoadingOverlay, {
    visible: loading
  })), /*#__PURE__*/React.createElement("aside", {
    className: 'library-rail' + (libraryOpen ? '' : ' library-rail--hidden'),
    "aria-label": "Library rail",
    "data-screen-label": "Media Bucket"
  }, /*#__PURE__*/React.createElement("div", {
    className: "library-drawer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "library-drawer__content ct-scroll"
  }, /*#__PURE__*/React.createElement("header", {
    className: "library-drawer__header"
  }, /*#__PURE__*/React.createElement("h3", null, "Media Bucket"), /*#__PURE__*/React.createElement("button", {
    className: "library-section__add",
    "aria-label": "Add media",
    onClick: addMedia
  }, "+")), /*#__PURE__*/React.createElement(MediaBucket, {
    items: items,
    activeId: activeId,
    onSelect: setActiveId,
    pinned: pinned,
    onPin: handlePin,
    onRemove: handleRemove
  })))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/ColorsView.jsx
try { (() => {
// Color Tool UI kit — Colors (Home) view: empty dropzone state OR loaded analysis
const {
  useState: useStateC
} = React;
function ColorsView({
  hasMedia,
  onAddMedia
}) {
  const [histogramSort, setHistogramSort] = useStateC('frequency');
  const [polarMode, setPolarMode] = useStateC('okhsv');
  const [hlMode, setHlMode] = useStateC('chroma');
  const [clustersN, setClustersN] = useStateC(25);
  const [quality, setQuality] = useStateC(2);
  const [ignoreTop, setIgnoreTop] = useStateC(0);
  const [merge, setMerge] = useStateC(0.02);
  const [symbol, setSymbol] = useStateC(1.0);
  const [outline, setOutline] = useStateC(false);
  const [axisLabels, setAxisLabels] = useStateC(true);
  const [snapReal, setSnapReal] = useStateC(false);
  if (!hasMedia) {
    return /*#__PURE__*/React.createElement("section", {
      className: "home"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dropzone",
      role: "button",
      tabIndex: 0,
      "aria-label": "Image dropzone"
    }, /*#__PURE__*/React.createElement("div", {
      className: "inner"
    }, /*#__PURE__*/React.createElement("p", {
      className: "title"
    }, "Drop anywhere"), /*#__PURE__*/React.createElement("p", null, "or"), /*#__PURE__*/React.createElement("button", {
      className: "upload",
      onClick: onAddMedia
    }, "Add media"), /*#__PURE__*/React.createElement("p", {
      className: "formats"
    }, "PNG, JPEG, WebP, BMP, GIF, TIFF, MP4"))));
  }
  return /*#__PURE__*/React.createElement("section", {
    className: "home"
  }, /*#__PURE__*/React.createElement("section", {
    className: "analysis-layout two-columns"
  }, /*#__PURE__*/React.createElement("div", {
    className: "analysis-column"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dropzone dropzone--image"
  }, /*#__PURE__*/React.createElement("div", {
    className: "image-preview zoomable",
    role: "button",
    tabIndex: 0
  }, /*#__PURE__*/React.createElement("img", {
    src: KIT_IMG,
    alt: "tavern-reference.jpg"
  }))), /*#__PURE__*/React.createElement(AnalysisCard, {
    title: "Cluster Histogram",
    sub: `Top clusters by ${histogramSort}`,
    metrics: "51 ms \xB7 40 iterations \xB7 170,500 samples",
    toggles: /*#__PURE__*/React.createElement(ToggleGroup, {
      options: [{
        value: 'frequency',
        label: 'Frequency'
      }, {
        value: 'hue',
        label: 'Hue'
      }, {
        value: 'lightness',
        label: 'Lightness'
      }],
      value: histogramSort,
      onChange: setHistogramSort
    })
  }, /*#__PURE__*/React.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: window.CTKit.histogramSvg(histogramSort)
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "analysis-column"
  }, /*#__PURE__*/React.createElement(AnalysisCard, {
    title: "Polar Chart",
    sub: polarMode === 'oklch' ? 'Hue · Chroma' : 'Hue · Saturation',
    toggles: /*#__PURE__*/React.createElement(ToggleGroup, {
      options: [{
        value: 'oklch',
        label: 'OKLCH'
      }, {
        value: 'okhsv',
        label: 'OKHSV'
      }, {
        value: 'hsv',
        label: 'HSV'
      }],
      value: polarMode,
      onChange: setPolarMode
    })
  }, /*#__PURE__*/React.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: window.CTKit.polarSvg(polarMode)
    }
  })), /*#__PURE__*/React.createElement(AnalysisCard, {
    title: "Hue \xD7 Lightness",
    sub: "Rendered in OKLCH",
    toggles: /*#__PURE__*/React.createElement(ToggleGroup, {
      options: [{
        value: 'chroma',
        label: 'Chroma'
      }, {
        value: 'frequency',
        label: 'Frequency'
      }],
      value: hlMode,
      onChange: setHlMode
    })
  }, /*#__PURE__*/React.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: window.CTKit.hueLightnessSvg(hlMode)
    }
  })))), /*#__PURE__*/React.createElement("section", {
    className: "controls"
  }, /*#__PURE__*/React.createElement("h2", null, "Parameters"), /*#__PURE__*/React.createElement("div", {
    className: "param-grid"
  }, /*#__PURE__*/React.createElement(KitRange, {
    label: "Number of clusters",
    value: clustersN,
    min: 1,
    max: 400,
    onChange: setClustersN,
    number: true
  }), /*#__PURE__*/React.createElement(KitRange, {
    label: "Speed \u2190 \u2192 Quality",
    value: quality,
    min: 0,
    max: 4,
    onChange: setQuality
  }), /*#__PURE__*/React.createElement(KitRange, {
    label: "Exclude top clusters",
    value: ignoreTop,
    min: 0,
    max: 50,
    onChange: setIgnoreTop
  }), /*#__PURE__*/React.createElement(KitRange, {
    label: "Color merge threshold (\u0394E OKLab)",
    value: merge,
    display: merge.toFixed(2),
    min: 0,
    max: 0.1,
    step: 0.01,
    onChange: setMerge
  }), /*#__PURE__*/React.createElement(KitRange, {
    label: "Symbol size",
    value: symbol,
    display: symbol.toFixed(1),
    min: 0.5,
    max: 2,
    step: 0.1,
    onChange: setSymbol
  }), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Cluster outline",
    checked: outline,
    onChange: setOutline
  }), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Axis labels",
    checked: axisLabels,
    onChange: setAxisLabels
  }), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Snap to real pixels",
    checked: snapReal,
    onChange: setSnapReal,
    title: "Snap chart markers to actual sampled pixels rather than computed centroids"
  }))));
}
Object.assign(window, {
  ColorsView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/ColorsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/ExportsView.jsx
try { (() => {
// Color Tool UI kit — Exports view: builder sections (Colors / Values / Batch) + PNG scale
const {
  useState: useStateE
} = React;
function BuilderItem({
  label,
  checked,
  onChange,
  sub,
  subChecked,
  onSubChange,
  disabled
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: 'builder-item' + (disabled ? ' disabled' : '')
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", null, label), sub && /*#__PURE__*/React.createElement("span", {
    className: "sub-toggle",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("label", {
    className: "sub-toggle-inner"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: subChecked,
    onChange: e => onSubChange(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "sub-toggle-label"
  }, sub))), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("button", {
    className: "item-download",
    title: "Save PNG",
    disabled: disabled
  }, "\u2193"));
}
function DataRow({
  label,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "data-row"
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("button", null, action));
}
function ExportsView({
  hasMedia
}) {
  const [scale, setScale] = useStateE(2);
  const [checks, setChecks] = useStateE({
    src: true,
    polar: true,
    hist: true,
    hl: false,
    strip: true,
    neutral: true,
    range: true,
    vhist: false,
    simple: true,
    grid: false
  });
  const set = k => v => setChecks(c => ({
    ...c,
    [k]: v
  }));
  const [allSorts, setAllSorts] = useStateE(false);
  const [inclOriginal, setInclOriginal] = useStateE(true);
  const [allStudies, setAllStudies] = useStateE(false);
  const [saving, setSaving] = useStateE(false);
  if (!hasMedia) {
    return /*#__PURE__*/React.createElement("section", {
      className: "exports"
    }, /*#__PURE__*/React.createElement("h1", null, "Exports"), /*#__PURE__*/React.createElement("div", {
      className: "empty-state"
    }, "Load media in Colors to configure exports."));
  }
  const fakeSave = () => {
    setSaving(true);
    setTimeout(() => setSaving(false), 1200);
  };
  return /*#__PURE__*/React.createElement("section", {
    className: "exports"
  }, /*#__PURE__*/React.createElement("h1", null, "Exports"), /*#__PURE__*/React.createElement("div", {
    className: "builder-section"
  }, /*#__PURE__*/React.createElement("h2", null, "Colors"), /*#__PURE__*/React.createElement("div", {
    className: "builder-items"
  }, /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Source Image",
    checked: checks.src,
    onChange: set('src')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Polar Chart",
    checked: checks.polar,
    onChange: set('polar')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Cluster Histogram",
    checked: checks.hist,
    onChange: set('hist'),
    sub: "All sorts",
    subChecked: allSorts,
    onSubChange: setAllSorts
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Hue \xD7 Lightness",
    checked: checks.hl,
    onChange: set('hl')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Palette Strip (top 20)",
    checked: checks.strip,
    onChange: set('strip')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Video Barcode",
    checked: false,
    onChange: () => {},
    disabled: true
  }), /*#__PURE__*/React.createElement(DataRow, {
    label: "Palette CSV",
    action: "Save CSV"
  }), /*#__PURE__*/React.createElement(DataRow, {
    label: "Palette .ase",
    action: "Save .ase"
  }), /*#__PURE__*/React.createElement(DataRow, {
    label: "Palette JSON",
    action: "Save JSON"
  })), /*#__PURE__*/React.createElement("button", {
    className: "composite-btn",
    onClick: fakeSave
  }, "Export Colors Composite")), /*#__PURE__*/React.createElement("div", {
    className: "builder-section"
  }, /*#__PURE__*/React.createElement("h2", null, "Values"), /*#__PURE__*/React.createElement("div", {
    className: "builder-items"
  }, /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Neutral Values",
    checked: checks.neutral,
    onChange: set('neutral'),
    sub: "Include original",
    subChecked: inclOriginal,
    onSubChange: setInclOriginal
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Range Finder",
    checked: checks.range,
    onChange: set('range')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Values Histogram",
    checked: checks.vhist,
    onChange: set('vhist')
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Simplified Values",
    checked: checks.simple,
    onChange: set('simple'),
    sub: "All studies",
    subChecked: allStudies,
    onSubChange: setAllStudies
  })), /*#__PURE__*/React.createElement("button", {
    className: "composite-btn",
    onClick: fakeSave
  }, "Export Values Composite")), /*#__PURE__*/React.createElement("div", {
    className: "builder-section"
  }, /*#__PURE__*/React.createElement("h2", null, "Batch"), /*#__PURE__*/React.createElement("div", {
    className: "builder-items"
  }, /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Composite Grid",
    checked: false,
    onChange: () => {},
    disabled: true
  }), /*#__PURE__*/React.createElement(BuilderItem, {
    label: "Polar Chart",
    checked: checks.grid,
    onChange: set('grid')
  }), /*#__PURE__*/React.createElement(DataRow, {
    label: "Palette CSV",
    action: "Save CSV"
  })), /*#__PURE__*/React.createElement("button", {
    className: "composite-btn",
    disabled: true
  }, "Export Batch Composite")), /*#__PURE__*/React.createElement("div", {
    className: "builder-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "scale-control scale-control--standalone"
  }, /*#__PURE__*/React.createElement("label", null, /*#__PURE__*/React.createElement("span", null, "PNG Scale"), /*#__PURE__*/React.createElement("span", {
    className: "scale-value"
  }, scale, "\xD7"), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 1,
    max: 4,
    step: 1,
    value: scale,
    onChange: e => setScale(Number(e.target.value))
  })))), saving && /*#__PURE__*/React.createElement("div", {
    className: "status status-saving"
  }, "Saving\u2026"));
}
Object.assign(window, {
  ExportsView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/ExportsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/KitBits.jsx
try { (() => {
// Color Tool UI kit — shared bits: toggle group, range input, cards, media bucket, overlays
const {
  useState
} = React;
function ToggleGroup({
  options,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "toggle-group"
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    className: value === o.value ? 'active' : '',
    onClick: () => onChange(o.value)
  }, o.label)));
}
function KitRange({
  label,
  value,
  display,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  number
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "param",
    title: label
  }, /*#__PURE__*/React.createElement("span", null, label, ": ", /*#__PURE__*/React.createElement("strong", null, display !== undefined ? display : value)), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }), number && /*#__PURE__*/React.createElement("input", {
    className: "number-input",
    type: "number",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function KitCheck({
  label,
  checked,
  onChange,
  title
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "choice",
    title: title || label
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    onChange: e => onChange(e.target.checked)
  }), label);
}
function AnalysisCard({
  title,
  sub,
  toggles,
  metrics,
  children
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "analysis-card"
  }, /*#__PURE__*/React.createElement("header", {
    className: "analysis-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", null, title), /*#__PURE__*/React.createElement("span", null, sub)), toggles, metrics && /*#__PURE__*/React.createElement("span", {
    className: "metrics"
  }, metrics)), /*#__PURE__*/React.createElement("div", {
    className: "chart"
  }, children));
}
const KIT_IMG = '../../assets/sample/tavern-reference.jpg';
function MediaBucket({
  items,
  activeId,
  onSelect,
  pinned,
  onPin,
  onRemove
}) {
  return /*#__PURE__*/React.createElement("div", null, items.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "bucket-empty"
  }, "No items yet.") : /*#__PURE__*/React.createElement("div", {
    className: "bucket-grid"
  }, items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.id,
    className: 'bucket-item' + (it.id === activeId ? ' active' : '') + (pinned.has(it.id) ? ' pinned' : ''),
    role: "button",
    tabIndex: 0,
    title: it.name,
    onClick: () => onSelect(it.id)
  }, /*#__PURE__*/React.createElement("img", {
    src: KIT_IMG,
    alt: it.name,
    style: {
      objectPosition: it.pos
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "bucket-badge"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 40 40",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.33333 35H31.6667C33.5076 35 35 33.5076 35 31.6667V8.33333C35 6.49238 33.5076 5 31.6667 5H8.33333C6.49238 5 5 6.49238 5 8.33333V31.6667C5 33.5076 6.49238 35 8.33333 35ZM8.33333 35L26.6667 16.6667L35 25M16.6667 14.1667C16.6667 15.5474 15.5474 16.6667 14.1667 16.6667C12.786 16.6667 11.6667 15.5474 11.6667 14.1667C11.6667 12.786 12.786 11.6667 14.1667 11.6667C15.5474 11.6667 16.6667 12.786 16.6667 14.1667Z",
    stroke: "currentColor",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("button", {
    className: 'bucket-pin' + (pinned.has(it.id) ? ' pinned' : ''),
    "aria-label": pinned.has(it.id) ? `Unpin ${it.name}` : `Pin ${it.name}`,
    onClick: e => {
      e.stopPropagation();
      onPin(it.id);
    }
  }, pinned.has(it.id) ? '\u{1F4CC}' : '\u25CB'), /*#__PURE__*/React.createElement("button", {
    className: "bucket-remove",
    "aria-label": `Remove ${it.name}`,
    onClick: e => {
      e.stopPropagation();
      onRemove(it.id);
    }
  }, "\xD7")))), pinned.size > 0 && /*#__PURE__*/React.createElement("div", {
    className: "bucket-pin-footer"
  }, /*#__PURE__*/React.createElement("span", null, pinned.size, " pinned"), /*#__PURE__*/React.createElement("button", {
    className: "bucket-clear-pins",
    onClick: () => onPin(null)
  }, "Clear pins")), items.length > 1 && /*#__PURE__*/React.createElement("button", {
    className: "bucket-clear-all",
    onClick: () => onRemove(null)
  }, "Clear All"));
}
function LoadingOverlay({
  visible
}) {
  if (!visible) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "overlay-root overlay-root--content visible",
    role: "dialog",
    "aria-label": "Analyzing\u2026"
  }, /*#__PURE__*/React.createElement("div", {
    className: "overlay-panel"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      placeItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner",
    "aria-label": "loading"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      opacity: 0.8
    }
  }, "This may take a moment"))));
}
Object.assign(window, {
  ToggleGroup,
  KitRange,
  KitCheck,
  AnalysisCard,
  MediaBucket,
  LoadingOverlay,
  KIT_IMG
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/KitBits.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/SettingsView.jsx
try { (() => {
// Color Tool UI kit — Settings view (recreated from SettingsView.svelte)
const {
  useState: useStateS
} = React;
function SettingsView() {
  const [compact, setCompact] = useStateS(false);
  const [clusterMax, setClusterMax] = useStateS(400);
  const [excludeMax, setExcludeMax] = useStateS(50);
  const [charts, setCharts] = useStateS({
    hist: true,
    polar: true,
    hl: true
  });
  const [tones, setTones] = useStateS(true);
  const [strip, setStrip] = useStateS('barcode');
  const [frameLabel, setFrameLabel] = useStateS('timestamp');
  const [format, setFormat] = useStateS('png');
  const Radio = ({
    name,
    value,
    current,
    onChange,
    label
  }) => /*#__PURE__*/React.createElement("label", {
    className: "choice"
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: current === value,
    onChange: () => onChange(value)
  }), label);
  return /*#__PURE__*/React.createElement("section", {
    className: "settings"
  }, /*#__PURE__*/React.createElement("div", {
    className: "group"
  }, /*#__PURE__*/React.createElement("h2", null, "App"), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Compact sidebars (always overlay)",
    checked: compact,
    onChange: setCompact
  })), /*#__PURE__*/React.createElement("div", {
    className: "group"
  }, /*#__PURE__*/React.createElement("h2", null, "Colors"), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement(KitRange, {
    label: "Max clusters",
    value: clusterMax,
    min: 10,
    max: 5000,
    step: 10,
    onChange: setClusterMax,
    number: true
  }), /*#__PURE__*/React.createElement("p", {
    className: "hint"
  }, "Higher values (1000+) may slow processing on some hardware.")), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement(KitRange, {
    label: "Max excludable clusters",
    value: excludeMax,
    min: 10,
    max: 500,
    step: 10,
    onChange: setExcludeMax,
    number: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "field-label"
  }, "Display Charts"), /*#__PURE__*/React.createElement("p", {
    className: "hint"
  }, "Applies to Colors and Batch views."), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Cluster Histogram",
    checked: charts.hist,
    onChange: v => setCharts({
      ...charts,
      hist: v
    })
  }), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Polar Chart",
    checked: charts.polar,
    onChange: v => setCharts({
      ...charts,
      polar: v
    })
  }), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Hue x Lightness",
    checked: charts.hl,
    onChange: v => setCharts({
      ...charts,
      hl: v
    })
  }))), /*#__PURE__*/React.createElement("div", {
    className: "group"
  }, /*#__PURE__*/React.createElement("h2", null, "Values"), /*#__PURE__*/React.createElement(KitCheck, {
    label: "Show simplified-tones panel",
    checked: tones,
    onChange: setTones
  })), /*#__PURE__*/React.createElement("div", {
    className: "group"
  }, /*#__PURE__*/React.createElement("h2", null, "Video"), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "field-label"
  }, "Strip Style"), /*#__PURE__*/React.createElement(Radio, {
    name: "strip",
    value: "filmstrip",
    current: strip,
    onChange: setStrip,
    label: "Filmstrip (scene thumbnails)"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "strip",
    value: "barcode",
    current: strip,
    onChange: setStrip,
    label: "Barcode (per-frame color)"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "field-label"
  }, "Export Frame Label"), /*#__PURE__*/React.createElement(Radio, {
    name: "flabel",
    value: "timestamp",
    current: frameLabel,
    onChange: setFrameLabel,
    label: "Timestamp (e.g. -00m03s25)"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "flabel",
    value: "frame",
    current: frameLabel,
    onChange: setFrameLabel,
    label: "Frame number (e.g. -f97)"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "group"
  }, /*#__PURE__*/React.createElement("h2", null, "Export"), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "field-label"
  }, "Graph export format"), /*#__PURE__*/React.createElement(Radio, {
    name: "fmt",
    value: "svg",
    current: format,
    onChange: setFormat,
    label: "SVG (raw vector)"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "fmt",
    value: "png",
    current: format,
    onChange: setFormat,
    label: "PNG (rasterized at scale)"
  })), /*#__PURE__*/React.createElement("label", null, /*#__PURE__*/React.createElement("span", null, "Save directory"), /*#__PURE__*/React.createElement("div", {
    className: "dir-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dir-path"
  }, "\u2026/Pictures/color-tool-exports"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "browse-btn"
  }, "Browse")))), /*#__PURE__*/React.createElement("div", {
    className: "group reset-group"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "reset-btn"
  }, "Reset to defaults")));
}
Object.assign(window, {
  SettingsView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/SettingsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/ValuesView.jsx
try { (() => {
// Color Tool UI kit — Values view: neutral pair, range finder, values histogram, simplified tones
const {
  useState: useStateV
} = React;
const VALUE_BUCKETS = {
  2: ['#1c1a17', '#e8e2d2'],
  3: ['#1c1a17', '#7a756c', '#e8e2d2'],
  4: ['#14120f', '#4f4b43', '#9a948a', '#e8e2d2'],
  5: ['#14120f', '#3d3a33', '#6f6a61', '#a8a297', '#e8e2d2']
};
function ValuesView({
  hasMedia,
  onAddMedia
}) {
  const [levels, setLevels] = useStateV(4);
  const [activeBucket, setActiveBucket] = useStateV(null);
  if (!hasMedia) {
    return /*#__PURE__*/React.createElement("section", {
      className: "values"
    }, /*#__PURE__*/React.createElement("div", {
      className: "empty-state empty--upload"
    }, /*#__PURE__*/React.createElement("p", null, "Drop anywhere"), /*#__PURE__*/React.createElement("p", null, "or"), /*#__PURE__*/React.createElement("button", {
      className: "upload",
      onClick: onAddMedia
    }, "Add media"), /*#__PURE__*/React.createElement("p", {
      className: "formats"
    }, "PNG, JPEG, WebP, BMP, GIF, TIFF, MP4")));
  }
  const buckets = VALUE_BUCKETS[levels];
  const shares = {
    2: [0.58, 0.42],
    3: [0.41, 0.33, 0.26],
    4: [0.3, 0.28, 0.24, 0.18],
    5: [0.24, 0.23, 0.21, 0.18, 0.14]
  }[levels];
  return /*#__PURE__*/React.createElement("section", {
    className: "values"
  }, /*#__PURE__*/React.createElement("div", {
    className: "preview-frame"
  }, /*#__PURE__*/React.createElement("div", {
    className: "preview-pair"
  }, /*#__PURE__*/React.createElement("div", {
    className: "preview-card"
  }, /*#__PURE__*/React.createElement("span", null, "Original"), /*#__PURE__*/React.createElement("img", {
    className: "preview zoomable",
    src: KIT_IMG,
    alt: "Original"
  })), /*#__PURE__*/React.createElement("div", {
    className: "preview-card"
  }, /*#__PURE__*/React.createElement("span", null, "Neutral values"), /*#__PURE__*/React.createElement("img", {
    className: "preview zoomable",
    src: KIT_IMG,
    alt: "Neutral values",
    style: {
      filter: 'grayscale(1)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "range-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "range-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "range-title"
  }, "Range finder"), /*#__PURE__*/React.createElement("div", {
    className: "range-tags"
  }, /*#__PURE__*/React.createElement("span", null, "Full range"), /*#__PURE__*/React.createElement("span", null, "Mid key"))), /*#__PURE__*/React.createElement("div", {
    className: "range-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "range-extension",
    style: {
      left: '6%',
      width: '88%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "range-core",
    style: {
      left: '18%',
      width: '52%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "range-outline",
    style: {
      left: '6%',
      width: '88%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "range-scale"
  }, /*#__PURE__*/React.createElement("span", null, "0"), /*#__PURE__*/React.createElement("span", null, "25"), /*#__PURE__*/React.createElement("span", null, "50"), /*#__PURE__*/React.createElement("span", null, "75"), /*#__PURE__*/React.createElement("span", null, "100")), /*#__PURE__*/React.createElement("div", {
    className: "range-meta"
  }, /*#__PURE__*/React.createElement("span", null, "Core mass: L 0.18\u20130.70"), /*#__PURE__*/React.createElement("span", null, "Extremes: L 0.06\u20130.94"))), /*#__PURE__*/React.createElement("div", {
    className: "histogram-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "histogram-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "histogram-title"
  }, "Values Histogram")), /*#__PURE__*/React.createElement("div", {
    className: "histogram-chart zoomable",
    dangerouslySetInnerHTML: {
      __html: window.CTKit.valuesHistogramSvg()
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "analysis-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "analysis-header2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "analysis-title"
  }, "Simplified tones"), /*#__PURE__*/React.createElement("div", {
    className: "analysis-controls"
  }, /*#__PURE__*/React.createElement("label", {
    className: "levels"
  }, /*#__PURE__*/React.createElement("span", null, "Levels: ", levels), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 2,
    max: 5,
    step: 1,
    value: levels,
    onChange: e => {
      setLevels(Number(e.target.value));
      setActiveBucket(null);
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "bucket-strip",
    role: "list"
  }, buckets.map((hex, i) => /*#__PURE__*/React.createElement("button", {
    key: hex,
    className: "bucket",
    style: {
      background: hex,
      color: i < buckets.length / 2 ? '#fff' : '#262626',
      flex: shares[i],
      outline: activeBucket === i ? '2px solid var(--accent)' : 'none',
      outlineOffset: -2
    },
    onClick: () => setActiveBucket(activeBucket === i ? null : i)
  }, /*#__PURE__*/React.createElement("span", {
    className: "bucket-percent"
  }, Math.round(shares[i] * 100), "%")))), /*#__PURE__*/React.createElement("div", {
    className: "preview-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "preview-card"
  }, /*#__PURE__*/React.createElement("span", null, activeBucket === null ? `Simplified · ${levels} tones` : `Isolating tone ${activeBucket + 1}`), /*#__PURE__*/React.createElement("img", {
    className: "preview zoomable",
    src: KIT_IMG,
    alt: "Simplified tones",
    style: {
      filter: `grayscale(1) contrast(${0.8 + levels * 0.25}) ${activeBucket !== null ? 'brightness(1.15)' : ''}`,
      maxWidth: 520
    }
  })))));
}
Object.assign(window, {
  ValuesView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/ValuesView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/color-tool/kit-data.js
try { (() => {
// Color Tool UI kit — shared fake data + chart generators (plain script, no JSX)
// Cluster palette approximating the tavern reference artwork.
(function () {
  const clusters = [{
    hex: '#3a2b26',
    share: 0.16,
    h: 30,
    c: 0.28,
    l: 0.24
  }, {
    hex: '#6b4a3b',
    share: 0.09,
    h: 38,
    c: 0.42,
    l: 0.38
  }, {
    hex: '#8a5a41',
    share: 0.08,
    h: 42,
    c: 0.52,
    l: 0.45
  }, {
    hex: '#c9b39a',
    share: 0.055,
    h: 62,
    c: 0.3,
    l: 0.74
  }, {
    hex: '#a8b3b8',
    share: 0.05,
    h: 220,
    c: 0.12,
    l: 0.72
  }, {
    hex: '#7e8a92',
    share: 0.045,
    h: 225,
    c: 0.16,
    l: 0.58
  }, {
    hex: '#20180f',
    share: 0.043,
    h: 55,
    c: 0.2,
    l: 0.13
  }, {
    hex: '#0e0c0a',
    share: 0.04,
    h: 40,
    c: 0.08,
    l: 0.07
  }, {
    hex: '#5c5346',
    share: 0.037,
    h: 70,
    c: 0.22,
    l: 0.36
  }, {
    hex: '#748067',
    share: 0.034,
    h: 130,
    c: 0.24,
    l: 0.52
  }, {
    hex: '#97a08a',
    share: 0.032,
    h: 125,
    c: 0.18,
    l: 0.63
  }, {
    hex: '#b98d6a',
    share: 0.03,
    h: 55,
    c: 0.44,
    l: 0.62
  }, {
    hex: '#d8c1a5',
    share: 0.028,
    h: 65,
    c: 0.28,
    l: 0.79
  }, {
    hex: '#8f7f6c',
    share: 0.027,
    h: 60,
    c: 0.2,
    l: 0.53
  }, {
    hex: '#4b3f35',
    share: 0.026,
    h: 50,
    c: 0.2,
    l: 0.29
  }, {
    hex: '#c47d5a',
    share: 0.024,
    h: 45,
    c: 0.58,
    l: 0.58
  }, {
    hex: '#e2965f',
    share: 0.022,
    h: 52,
    c: 0.66,
    l: 0.68
  }, {
    hex: '#aa4f42',
    share: 0.02,
    h: 28,
    c: 0.62,
    l: 0.44
  }, {
    hex: '#b56f7a',
    share: 0.018,
    h: 5,
    c: 0.4,
    l: 0.55
  }, {
    hex: '#e8c6bb',
    share: 0.017,
    h: 30,
    c: 0.2,
    l: 0.82
  }, {
    hex: '#3d5245',
    share: 0.016,
    h: 150,
    c: 0.26,
    l: 0.33
  }, {
    hex: '#5a7a4e',
    share: 0.015,
    h: 135,
    c: 0.44,
    l: 0.46
  }, {
    hex: '#93684c',
    share: 0.014,
    h: 48,
    c: 0.46,
    l: 0.47
  }, {
    hex: '#d0d2c9',
    share: 0.013,
    h: 100,
    c: 0.06,
    l: 0.84
  }, {
    hex: '#ede5d3',
    share: 0.012,
    h: 80,
    c: 0.1,
    l: 0.91
  }];
  const AXIS_FONT = 'Georgia, "Times New Roman", serif';
  function polarSvg(mode) {
    const S = 420,
      cx = S / 2,
      cy = S / 2,
      R = S / 2 - 24;
    let dots = '';
    clusters.forEach(k => {
      const a = (k.h - 90) * Math.PI / 180;
      const r = R * k.c;
      const x = cx + r * Math.cos(a);
      const y = cy + r * Math.sin(a);
      const rad = 4 + Math.sqrt(k.share) * 46;
      dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rad.toFixed(1)}" fill="${k.hex}" stroke="rgba(38,38,38,0.35)" stroke-width="0.5"/>`;
    });
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${S} ${S}" width="${S}" height="${S}">` + `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#262626" stroke-width="1"/>` + `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#262626" stroke-width="0.75"/>` + `<line x1="${cx}" y1="${cy - R}" x2="${cx}" y2="${cy + R}" stroke="#262626" stroke-width="0.75"/>` + dots + `<text x="${cx + R - 8}" y="${cy + 26}" font-family='${AXIS_FONT}' font-size="13" fill="#262626" text-anchor="end">&lt;- Hue -&gt;</text>` + `<text x="${cx + 6}" y="${cy - R + 14}" font-family='${AXIS_FONT}' font-size="13" fill="#262626" transform="rotate(90 ${cx + 6} ${cy - R + 14})">Saturation -&gt;</text>` + `</svg>`;
  }
  function histogramSvg(sort) {
    const W = 520,
      H = 180,
      pad = 14,
      base = H - 26;
    const sorted = [...clusters].sort(sort === 'hue' ? (a, b) => a.h - b.h : sort === 'lightness' ? (a, b) => b.l - a.l : (a, b) => b.share - a.share);
    const bw = (W - pad * 2) / sorted.length;
    let bars = '';
    const maxShare = sorted.reduce((m, k) => Math.max(m, k.share), 0);
    sorted.forEach((k, i) => {
      const h = Math.max(4, k.share / maxShare * (base - 18));
      bars += `<rect x="${(pad + i * bw + 0.5).toFixed(1)}" y="${(base - h).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${h.toFixed(1)}" fill="${k.hex}"/>`;
    });
    let grid = '';
    for (let i = 1; i <= 4; i++) {
      const y = base - i * (base - 18) / 4;
      grid += `<line x1="${pad}" y1="${y}" x2="${W - pad}" y2="${y}" stroke="rgba(38,38,38,0.12)" stroke-width="0.5"/>`;
    }
    const label = sort === 'hue' ? 'sorted by hue' : sort === 'lightness' ? 'sorted by lightness' : 'sorted by frequency';
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` + `<rect x="0" y="0" width="${W}" height="${H}" fill="#ffffff"/>` + grid + bars + `<line x1="${pad}" y1="${base}" x2="${W - pad}" y2="${base}" stroke="#262626" stroke-width="0.75"/>` + `<text x="${pad}" y="${H - 8}" font-family='${AXIS_FONT}' font-size="11" fill="#262626">Top ${clusters.length} clusters &#8226; ${label}</text>` + `</svg>`;
  }
  function hueLightnessSvg(sizeMode) {
    const W = 420,
      H = 240,
      pad = 26;
    let dots = '';
    clusters.forEach(k => {
      const x = pad + k.h / 360 * (W - pad * 2);
      const y = H - pad - k.l * (H - pad * 2);
      const rad = 2 + (sizeMode === 'frequency' ? Math.sqrt(k.share) * 30 : k.c * 14);
      dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rad.toFixed(1)}" fill="${k.hex}" stroke="rgba(38,38,38,0.3)" stroke-width="0.5"/>`;
    });
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` + `<rect x="${pad}" y="${pad}" width="${W - pad * 2}" height="${H - pad * 2}" fill="none" stroke="rgba(38,38,38,0.5)" stroke-width="0.75"/>` + `<line x1="${W / 2}" y1="${pad}" x2="${W / 2}" y2="${H - pad}" stroke="rgba(38,38,38,0.25)" stroke-width="0.5"/>` + `<line x1="${pad}" y1="${H / 2}" x2="${W - pad}" y2="${H / 2}" stroke="rgba(38,38,38,0.25)" stroke-width="0.5"/>` + dots + `<text x="${pad - 12}" y="${H / 2}" font-family='${AXIS_FONT}' font-size="12" fill="#262626" transform="rotate(-90 ${pad - 12} ${H / 2})" text-anchor="middle">Lightness</text>` + `</svg>`;
  }
  function valuesHistogramSvg() {
    const W = 640,
      H = 150,
      pad = 14,
      base = H - 12;
    let bars = '';
    const n = 48;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      const amp = Math.exp(-Math.pow((t - 0.32) / 0.22, 2)) + 0.55 * Math.exp(-Math.pow((t - 0.78) / 0.14, 2)) + 0.06;
      const h = amp * (base - 14) * 0.72;
      const g = Math.round(t * 232);
      const bw = (W - pad * 2) / n;
      bars += `<rect x="${(pad + i * bw + 0.5).toFixed(1)}" y="${(base - h).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${h.toFixed(1)}" fill="rgb(${g},${g},${g})" stroke="rgba(38,38,38,0.25)" stroke-width="0.25"/>`;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` + `<rect x="0" y="0" width="${W}" height="${H}" fill="#ffffff"/>` + bars + `<line x1="${pad}" y1="${base}" x2="${W - pad}" y2="${base}" stroke="#262626" stroke-width="0.75"/>` + `</svg>`;
  }
  window.CTKit = {
    clusters,
    polarSvg,
    histogramSvg,
    hueLightnessSvg,
    valuesHistogramSvg
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/color-tool/kit-data.js", error: String((e && e.message) || e) }); }

if (__ds_scope.__ds_default_components_icons_icon_data_12stud1$1nb03e1 === undefined) __ds_scope.__ds_default_components_icons_icon_data_12stud1$1nb03e1 = __ds_scope.__ds_default_components_icons_icon_data_12stud1;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$cekuiz === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$cekuiz = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$lqbvqf === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$lqbvqf = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$1qlbmyw === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$1qlbmyw = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$s2bzvp === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$s2bzvp = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$2qe4he === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$2qe4he = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$nzpf2o === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$nzpf2o = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$1r5csro === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$1r5csro = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$1ffpqzn === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$1ffpqzn = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$fo2aat === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$fo2aat = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$ivbqzb === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$ivbqzb = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;
if (__ds_scope.__ds_default_components_icons_Icon_fio49a$1yps986 === undefined) __ds_scope.__ds_default_components_icons_Icon_fio49a$1yps986 = __ds_scope.__ds_default_components_icons_Icon_fio49a !== undefined ? __ds_scope.__ds_default_components_icons_Icon_fio49a : __ds_scope.Icon;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.SliderDefault = __ds_scope.SliderDefault;

__ds_ns.PlainTooltip = __ds_scope.PlainTooltip;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Check = __ds_scope.Check;

__ds_ns.ChevronUp = __ds_scope.ChevronUp;

__ds_ns.Copy = __ds_scope.Copy;

__ds_ns.Download = __ds_scope.Download;

__ds_ns.FileText = __ds_scope.FileText;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Image = __ds_scope.Image;

__ds_ns.Loader = __ds_scope.Loader;

__ds_ns.Sun = __ds_scope.Sun;

__ds_ns.X = __ds_scope.X;

__ds_ns.XCircle = __ds_scope.XCircle;

__ds_ns.XSquare = __ds_scope.XSquare;

__ds_ns.MediaImage = __ds_scope.MediaImage;

__ds_ns.MediaVideo = __ds_scope.MediaVideo;

})();
