// Color Tool UI kit — app shell: nav, header, view container, library rail
const { useState: useStateA } = React;

const NAV_ITEMS = [
  { key: 'home', label: 'Colors' },
  { key: 'values', label: 'Values' },
  { key: 'batch', label: 'Batch' },
  { key: 'exports', label: 'Exports' },
  { key: 'settings', label: 'Settings' }
];

const VIEW_DESCS = {
  home: 'OKLab color data derived by K-Means++ and plotted for analysis.',
  values: 'Value analysis derived from OKLab lightness.',
  batch: 'Batch analysis across multiple pinned images.',
  exports: 'Export analysis results as SVG, PNG, or CSV.',
  settings: 'Application preferences and defaults.'
};

const SidebarIcon = ({ open, flip }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" style={flip ? { transform: 'scaleX(-1)' } : undefined}>
    {open ? (
      <path d="M12.5 1C13.881 1 15 2.119 15 3.5V12.5C15 13.881 13.881 15 12.5 15H3.5C2.119 15 1 13.881 1 12.5V3.5C1 2.119 2.119 1 3.5 1H12.5ZM12.5 14C13.328 14 14 13.328 14 12.5V3.5C14 2.672 13.328 2 12.5 2H7V14H12.5Z" />
    ) : (
      <path d="M12.5 1H3.5C2.122 1 1 2.122 1 3.5V12.5C1 13.879 2.122 15 3.5 15H12.5C13.878 15 15 13.879 15 12.5V3.5C15 2.122 13.878 1 12.5 1ZM2 12.5V3.5C2 2.673 2.673 2 3.5 2H9V14H3.5C2.673 14 2 13.327 2 12.5ZM14 12.5C14 13.327 13.327 14 12.5 14H10V2H12.5C13.327 2 14 2.673 14 3.5V12.5Z" />
    )}
  </svg>
);

function BatchView() {
  return (
    <section className="batch-stub">
      <div className="empty-state">
        Pin two or more images in the Media Bucket to run a batch analysis.
        <br />
        <span style={{ fontSize: 12, color: 'rgba(33,33,32,0.5)' }}>
          (Batch results view intentionally not recreated in this kit — see BatchView.svelte for the three-panel layout.)
        </span>
      </div>
    </section>
  );
}

function App() {
  const [view, setView] = useStateA('home');
  const [navCollapsed, setNavCollapsed] = useStateA(false);
  const [libraryOpen, setLibraryOpen] = useStateA(true);
  const [loading, setLoading] = useStateA(false);
  const [items, setItems] = useStateA([
    { id: 'a', name: 'tavern-reference.jpg', pos: '20% 30%' },
    { id: 'b', name: 'tavern-crop-01.png', pos: '70% 60%' },
    { id: 'c', name: 'tavern-crop-02.png', pos: '45% 80%' }
  ]);
  const [activeId, setActiveId] = useStateA('a');
  const [pinned, setPinned] = useStateA(new Set());
  const hasMedia = items.length > 0 && !!activeId;

  const addMedia = () => {
    setLoading(true);
    setTimeout(() => {
      const id = 'm' + Date.now();
      setItems((xs) => [...xs, { id, name: 'upload-' + (items.length + 1) + '.png', pos: '50% 20%' }]);
      setActiveId(id);
      setLoading(false);
    }, 900);
  };

  const handlePin = (id) => {
    if (id === null) return setPinned(new Set());
    setPinned((p) => {
      const n = new Set(p);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const handleRemove = (id) => {
    if (id === null) { setItems([]); setActiveId(null); setPinned(new Set()); return; }
    setItems((xs) => xs.filter((x) => x.id !== id));
    if (activeId === id) setActiveId(null);
  };

  const active = NAV_ITEMS.find((n) => n.key === view);

  return (
    <main className={(navCollapsed ? 'nav-collapsed ' : '') + (libraryOpen ? 'library-open' : '')}>
      <nav className={'nav' + (navCollapsed ? ' collapsed' : '')} data-screen-label="Navigation">
        {NAV_ITEMS.map((item) => (
          <button key={item.key} className={view === item.key ? 'active' : ''} onClick={() => setView(item.key)}>
            {item.label}
          </button>
        ))}
      </nav>

      <header className="app-header" data-screen-label="Header">
        <button type="button" className="header-toggle" aria-label={navCollapsed ? 'Show navigation' : 'Hide navigation'} onClick={() => setNavCollapsed(!navCollapsed)}>
          <SidebarIcon open={!navCollapsed} />
        </button>
        <div className="header-center">
          <div className="header-title-group">
            <span className="header-view-title">{active.label}</span>
            <span className="header-view-desc">{VIEW_DESCS[view]}</span>
          </div>
        </div>
        <button type="button" className="header-toggle" aria-label={libraryOpen ? 'Close library' : 'Open library'} onClick={() => setLibraryOpen(!libraryOpen)}>
          <SidebarIcon open={libraryOpen} flip />
        </button>
      </header>

      <section className="view-container ct-scroll" data-screen-label={active.label + ' view'}>
        {view === 'home' && <ColorsView hasMedia={hasMedia} onAddMedia={addMedia} />}
        {view === 'values' && <ValuesView hasMedia={hasMedia} onAddMedia={addMedia} />}
        {view === 'batch' && <BatchView />}
        {view === 'exports' && <ExportsView hasMedia={hasMedia} />}
        {view === 'settings' && <SettingsView />}
        <LoadingOverlay visible={loading} />
      </section>

      <aside className={'library-rail' + (libraryOpen ? '' : ' library-rail--hidden')} aria-label="Library rail" data-screen-label="Media Bucket">
        <div className="library-drawer">
          <div className="library-drawer__content ct-scroll">
            <header className="library-drawer__header">
              <h3>Media Bucket</h3>
              <button className="library-section__add" aria-label="Add media" onClick={addMedia}>+</button>
            </header>
            <MediaBucket items={items} activeId={activeId} onSelect={setActiveId} pinned={pinned} onPin={handlePin} onRemove={handleRemove} />
          </div>
        </div>
      </aside>
    </main>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
