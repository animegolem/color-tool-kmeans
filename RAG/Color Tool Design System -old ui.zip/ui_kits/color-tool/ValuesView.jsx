// Color Tool UI kit — Values view: neutral pair, range finder, values histogram, simplified tones
const { useState: useStateV } = React;

const VALUE_BUCKETS = {
  2: ['#1c1a17', '#e8e2d2'],
  3: ['#1c1a17', '#7a756c', '#e8e2d2'],
  4: ['#14120f', '#4f4b43', '#9a948a', '#e8e2d2'],
  5: ['#14120f', '#3d3a33', '#6f6a61', '#a8a297', '#e8e2d2']
};

function ValuesView({ hasMedia, onAddMedia }) {
  const [levels, setLevels] = useStateV(4);
  const [activeBucket, setActiveBucket] = useStateV(null);

  if (!hasMedia) {
    return (
      <section className="values">
        <div className="empty-state empty--upload">
          <p>Drop anywhere</p>
          <p>or</p>
          <button className="upload" onClick={onAddMedia}>Add media</button>
          <p className="formats">PNG, JPEG, WebP, BMP, GIF, TIFF, MP4</p>
        </div>
      </section>
    );
  }

  const buckets = VALUE_BUCKETS[levels];
  const shares = { 2: [0.58, 0.42], 3: [0.41, 0.33, 0.26], 4: [0.3, 0.28, 0.24, 0.18], 5: [0.24, 0.23, 0.21, 0.18, 0.14] }[levels];

  return (
    <section className="values">
      <div className="preview-frame">
        <div className="preview-pair">
          <div className="preview-card">
            <span>Original</span>
            <img className="preview zoomable" src={KIT_IMG} alt="Original" />
          </div>
          <div className="preview-card">
            <span>Neutral values</span>
            <img className="preview zoomable" src={KIT_IMG} alt="Neutral values" style={{ filter: 'grayscale(1)' }} />
          </div>
        </div>
      </div>

      <div className="range-section">
        <div className="range-header">
          <div className="range-title">Range finder</div>
          <div className="range-tags"><span>Full range</span><span>Mid key</span></div>
        </div>
        <div className="range-track">
          <div className="range-extension" style={{ left: '6%', width: '88%' }}></div>
          <div className="range-core" style={{ left: '18%', width: '52%' }}></div>
          <div className="range-outline" style={{ left: '6%', width: '88%' }}></div>
        </div>
        <div className="range-scale"><span>0</span><span>25</span><span>50</span><span>75</span><span>100</span></div>
        <div className="range-meta"><span>Core mass: L 0.18–0.70</span><span>Extremes: L 0.06–0.94</span></div>
      </div>

      <div className="histogram-section">
        <div className="histogram-header">
          <div className="histogram-title">Values Histogram</div>
        </div>
        <div className="histogram-chart zoomable" dangerouslySetInnerHTML={{ __html: window.CTKit.valuesHistogramSvg() }} />
      </div>

      <div className="analysis-section">
        <div className="analysis-header2">
          <div className="analysis-title">Simplified tones</div>
          <div className="analysis-controls">
            <label className="levels">
              <span>Levels: {levels}</span>
              <input type="range" min={2} max={5} step={1} value={levels} onChange={(e) => { setLevels(Number(e.target.value)); setActiveBucket(null); }} />
            </label>
          </div>
        </div>
        <div className="bucket-strip" role="list">
          {buckets.map((hex, i) => (
            <button
              key={hex}
              className="bucket"
              style={{ background: hex, color: i < buckets.length / 2 ? '#fff' : '#262626', flex: shares[i], outline: activeBucket === i ? '2px solid var(--accent)' : 'none', outlineOffset: -2 }}
              onClick={() => setActiveBucket(activeBucket === i ? null : i)}
            >
              <span className="bucket-percent">{Math.round(shares[i] * 100)}%</span>
            </button>
          ))}
        </div>
        <div className="preview-panel">
          <div className="preview-card">
            <span>{activeBucket === null ? `Simplified · ${levels} tones` : `Isolating tone ${activeBucket + 1}`}</span>
            <img
              className="preview zoomable"
              src={KIT_IMG}
              alt="Simplified tones"
              style={{ filter: `grayscale(1) contrast(${0.8 + levels * 0.25}) ${activeBucket !== null ? 'brightness(1.15)' : ''}`, maxWidth: 520 }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { ValuesView });
