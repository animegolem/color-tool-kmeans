// Color Tool UI kit — Colors (Home) view: empty dropzone state OR loaded analysis
const { useState: useStateC } = React;

function ColorsView({ hasMedia, onAddMedia }) {
  const [histogramSort, setHistogramSort] = useStateC('frequency');
  const [polarMode, setPolarMode] = useStateC('okhsv');
  const [hlMode, setHlMode] = useStateC('chroma');
  const [clustersN, setClustersN] = useStateC(25);
  const [quality, setQuality] = useStateC(2);
  const [ignoreTop, setIgnoreTop] = useStateC(0);
  const [merge, setMerge] = useStateC(0.02);
  const [symbol, setSymbol] = useStateC(1.0);
  const [outline, setOutline] = useStateC(false);
  const [axisLabels, setAxisLabels] = useStateC(true);
  const [snapReal, setSnapReal] = useStateC(false);

  if (!hasMedia) {
    return (
      <section className="home">
        <div className="dropzone" role="button" tabIndex={0} aria-label="Image dropzone">
          <div className="inner">
            <p className="title">Drop anywhere</p>
            <p>or</p>
            <button className="upload" onClick={onAddMedia}>Add media</button>
            <p className="formats">PNG, JPEG, WebP, BMP, GIF, TIFF, MP4</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="home">
      <section className="analysis-layout two-columns">
        <div className="analysis-column">
          <div className="dropzone dropzone--image">
            <div className="image-preview zoomable" role="button" tabIndex={0}>
              <img src={KIT_IMG} alt="tavern-reference.jpg" />
            </div>
          </div>
          <AnalysisCard
            title="Cluster Histogram"
            sub={`Top clusters by ${histogramSort}`}
            metrics="51 ms · 40 iterations · 170,500 samples"
            toggles={
              <ToggleGroup
                options={[{ value: 'frequency', label: 'Frequency' }, { value: 'hue', label: 'Hue' }, { value: 'lightness', label: 'Lightness' }]}
                value={histogramSort}
                onChange={setHistogramSort}
              />
            }
          >
            <div dangerouslySetInnerHTML={{ __html: window.CTKit.histogramSvg(histogramSort) }} />
          </AnalysisCard>
        </div>
        <div className="analysis-column">
          <AnalysisCard
            title="Polar Chart"
            sub={polarMode === 'oklch' ? 'Hue · Chroma' : 'Hue · Saturation'}
            toggles={
              <ToggleGroup
                options={[{ value: 'oklch', label: 'OKLCH' }, { value: 'okhsv', label: 'OKHSV' }, { value: 'hsv', label: 'HSV' }]}
                value={polarMode}
                onChange={setPolarMode}
              />
            }
          >
            <div dangerouslySetInnerHTML={{ __html: window.CTKit.polarSvg(polarMode) }} />
          </AnalysisCard>
          <AnalysisCard
            title="Hue × Lightness"
            sub="Rendered in OKLCH"
            toggles={
              <ToggleGroup
                options={[{ value: 'chroma', label: 'Chroma' }, { value: 'frequency', label: 'Frequency' }]}
                value={hlMode}
                onChange={setHlMode}
              />
            }
          >
            <div dangerouslySetInnerHTML={{ __html: window.CTKit.hueLightnessSvg(hlMode) }} />
          </AnalysisCard>
        </div>
      </section>

      <section className="controls">
        <h2>Parameters</h2>
        <div className="param-grid">
          <KitRange label="Number of clusters" value={clustersN} min={1} max={400} onChange={setClustersN} number />
          <KitRange label="Speed ← → Quality" value={quality} min={0} max={4} onChange={setQuality} />
          <KitRange label="Exclude top clusters" value={ignoreTop} min={0} max={50} onChange={setIgnoreTop} />
          <KitRange label="Color merge threshold (ΔE OKLab)" value={merge} display={merge.toFixed(2)} min={0} max={0.1} step={0.01} onChange={setMerge} />
          <KitRange label="Symbol size" value={symbol} display={symbol.toFixed(1)} min={0.5} max={2} step={0.1} onChange={setSymbol} />
          <KitCheck label="Cluster outline" checked={outline} onChange={setOutline} />
          <KitCheck label="Axis labels" checked={axisLabels} onChange={setAxisLabels} />
          <KitCheck label="Snap to real pixels" checked={snapReal} onChange={setSnapReal} title="Snap chart markers to actual sampled pixels rather than computed centroids" />
        </div>
      </section>
    </section>
  );
}

Object.assign(window, { ColorsView });
