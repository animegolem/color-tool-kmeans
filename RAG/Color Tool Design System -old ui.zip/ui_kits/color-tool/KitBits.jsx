// Color Tool UI kit — shared bits: toggle group, range input, cards, media bucket, overlays
const { useState } = React;

function ToggleGroup({ options, value, onChange }) {
  return (
    <div className="toggle-group">
      {options.map((o) => (
        <button key={o.value} type="button" className={value === o.value ? 'active' : ''} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

function KitRange({ label, value, display, min = 0, max = 100, step = 1, onChange, number }) {
  return (
    <label className="param" title={label}>
      <span>
        {label}: <strong>{display !== undefined ? display : value}</strong>
      </span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
      {number && (
        <input className="number-input" type="number" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
      )}
    </label>
  );
}

function KitCheck({ label, checked, onChange, title }) {
  return (
    <label className="choice" title={title || label}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

function AnalysisCard({ title, sub, toggles, metrics, children }) {
  return (
    <article className="analysis-card">
      <header className="analysis-header">
        <div>
          <h2>{title}</h2>
          <span>{sub}</span>
        </div>
        {toggles}
        {metrics && <span className="metrics">{metrics}</span>}
      </header>
      <div className="chart">{children}</div>
    </article>
  );
}

const KIT_IMG = '../../assets/sample/tavern-reference.jpg';

function MediaBucket({ items, activeId, onSelect, pinned, onPin, onRemove }) {
  return (
    <div>
      {items.length === 0 ? (
        <div className="bucket-empty">No items yet.</div>
      ) : (
        <div className="bucket-grid">
          {items.map((it) => (
            <div
              key={it.id}
              className={'bucket-item' + (it.id === activeId ? ' active' : '') + (pinned.has(it.id) ? ' pinned' : '')}
              role="button"
              tabIndex={0}
              title={it.name}
              onClick={() => onSelect(it.id)}
            >
              <img src={KIT_IMG} alt={it.name} style={{ objectPosition: it.pos }} />
              <span className="bucket-badge">
                <svg width="16" height="16" viewBox="0 0 40 40" fill="none"><path d="M8.33333 35H31.6667C33.5076 35 35 33.5076 35 31.6667V8.33333C35 6.49238 33.5076 5 31.6667 5H8.33333C6.49238 5 5 6.49238 5 8.33333V31.6667C5 33.5076 6.49238 35 8.33333 35ZM8.33333 35L26.6667 16.6667L35 25M16.6667 14.1667C16.6667 15.5474 15.5474 16.6667 14.1667 16.6667C12.786 16.6667 11.6667 15.5474 11.6667 14.1667C11.6667 12.786 12.786 11.6667 14.1667 11.6667C15.5474 11.6667 16.6667 12.786 16.6667 14.1667Z" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </span>
              <button
                className={'bucket-pin' + (pinned.has(it.id) ? ' pinned' : '')}
                aria-label={pinned.has(it.id) ? `Unpin ${it.name}` : `Pin ${it.name}`}
                onClick={(e) => { e.stopPropagation(); onPin(it.id); }}
              >{pinned.has(it.id) ? '\u{1F4CC}' : '\u25CB'}</button>
              <button className="bucket-remove" aria-label={`Remove ${it.name}`} onClick={(e) => { e.stopPropagation(); onRemove(it.id); }}>×</button>
            </div>
          ))}
        </div>
      )}
      {pinned.size > 0 && (
        <div className="bucket-pin-footer">
          <span>{pinned.size} pinned</span>
          <button className="bucket-clear-pins" onClick={() => onPin(null)}>Clear pins</button>
        </div>
      )}
      {items.length > 1 && <button className="bucket-clear-all" onClick={() => onRemove(null)}>Clear All</button>}
    </div>
  );
}

function LoadingOverlay({ visible }) {
  if (!visible) return null;
  return (
    <div className="overlay-root overlay-root--content visible" role="dialog" aria-label="Analyzing…">
      <div className="overlay-panel">
        <div style={{ display: 'grid', placeItems: 'center', gap: 12 }}>
          <div className="spinner" aria-label="loading"></div>
          <div style={{ fontSize: 12, opacity: 0.8 }}>This may take a moment</div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ToggleGroup, KitRange, KitCheck, AnalysisCard, MediaBucket, LoadingOverlay, KIT_IMG });
