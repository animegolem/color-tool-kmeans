// Color Tool UI kit — shared fake data + chart generators (plain script, no JSX)
// Cluster palette approximating the tavern reference artwork.
(function () {
  const clusters = [
    { hex: '#3a2b26', share: 0.16, h: 30, c: 0.28, l: 0.24 },
    { hex: '#6b4a3b', share: 0.09, h: 38, c: 0.42, l: 0.38 },
    { hex: '#8a5a41', share: 0.08, h: 42, c: 0.52, l: 0.45 },
    { hex: '#c9b39a', share: 0.055, h: 62, c: 0.3, l: 0.74 },
    { hex: '#a8b3b8', share: 0.05, h: 220, c: 0.12, l: 0.72 },
    { hex: '#7e8a92', share: 0.045, h: 225, c: 0.16, l: 0.58 },
    { hex: '#20180f', share: 0.043, h: 55, c: 0.2, l: 0.13 },
    { hex: '#0e0c0a', share: 0.04, h: 40, c: 0.08, l: 0.07 },
    { hex: '#5c5346', share: 0.037, h: 70, c: 0.22, l: 0.36 },
    { hex: '#748067', share: 0.034, h: 130, c: 0.24, l: 0.52 },
    { hex: '#97a08a', share: 0.032, h: 125, c: 0.18, l: 0.63 },
    { hex: '#b98d6a', share: 0.03, h: 55, c: 0.44, l: 0.62 },
    { hex: '#d8c1a5', share: 0.028, h: 65, c: 0.28, l: 0.79 },
    { hex: '#8f7f6c', share: 0.027, h: 60, c: 0.2, l: 0.53 },
    { hex: '#4b3f35', share: 0.026, h: 50, c: 0.2, l: 0.29 },
    { hex: '#c47d5a', share: 0.024, h: 45, c: 0.58, l: 0.58 },
    { hex: '#e2965f', share: 0.022, h: 52, c: 0.66, l: 0.68 },
    { hex: '#aa4f42', share: 0.02, h: 28, c: 0.62, l: 0.44 },
    { hex: '#b56f7a', share: 0.018, h: 5, c: 0.4, l: 0.55 },
    { hex: '#e8c6bb', share: 0.017, h: 30, c: 0.2, l: 0.82 },
    { hex: '#3d5245', share: 0.016, h: 150, c: 0.26, l: 0.33 },
    { hex: '#5a7a4e', share: 0.015, h: 135, c: 0.44, l: 0.46 },
    { hex: '#93684c', share: 0.014, h: 48, c: 0.46, l: 0.47 },
    { hex: '#d0d2c9', share: 0.013, h: 100, c: 0.06, l: 0.84 },
    { hex: '#ede5d3', share: 0.012, h: 80, c: 0.1, l: 0.91 }
  ];

  const AXIS_FONT = 'Georgia, "Times New Roman", serif';

  function polarSvg(mode) {
    const S = 420, cx = S / 2, cy = S / 2, R = S / 2 - 24;
    let dots = '';
    clusters.forEach((k) => {
      const a = ((k.h - 90) * Math.PI) / 180;
      const r = R * k.c;
      const x = cx + r * Math.cos(a);
      const y = cy + r * Math.sin(a);
      const rad = 4 + Math.sqrt(k.share) * 46;
      dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rad.toFixed(1)}" fill="${k.hex}" stroke="rgba(38,38,38,0.35)" stroke-width="0.5"/>`;
    });
    return (
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${S} ${S}" width="${S}" height="${S}">` +
      `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#262626" stroke-width="1"/>` +
      `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#262626" stroke-width="0.75"/>` +
      `<line x1="${cx}" y1="${cy - R}" x2="${cx}" y2="${cy + R}" stroke="#262626" stroke-width="0.75"/>` +
      dots +
      `<text x="${cx + R - 8}" y="${cy + 26}" font-family='${AXIS_FONT}' font-size="13" fill="#262626" text-anchor="end">&lt;- Hue -&gt;</text>` +
      `<text x="${cx + 6}" y="${cy - R + 14}" font-family='${AXIS_FONT}' font-size="13" fill="#262626" transform="rotate(90 ${cx + 6} ${cy - R + 14})">Saturation -&gt;</text>` +
      `</svg>`
    );
  }

  function histogramSvg(sort) {
    const W = 520, H = 180, pad = 14, base = H - 26;
    const sorted = [...clusters].sort(
      sort === 'hue' ? (a, b) => a.h - b.h : sort === 'lightness' ? (a, b) => b.l - a.l : (a, b) => b.share - a.share
    );
    const bw = (W - pad * 2) / sorted.length;
    let bars = '';
    const maxShare = sorted.reduce((m, k) => Math.max(m, k.share), 0);
    sorted.forEach((k, i) => {
      const h = Math.max(4, (k.share / maxShare) * (base - 18));
      bars += `<rect x="${(pad + i * bw + 0.5).toFixed(1)}" y="${(base - h).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${h.toFixed(1)}" fill="${k.hex}"/>`;
    });
    let grid = '';
    for (let i = 1; i <= 4; i++) {
      const y = base - (i * (base - 18)) / 4;
      grid += `<line x1="${pad}" y1="${y}" x2="${W - pad}" y2="${y}" stroke="rgba(38,38,38,0.12)" stroke-width="0.5"/>`;
    }
    const label = sort === 'hue' ? 'sorted by hue' : sort === 'lightness' ? 'sorted by lightness' : 'sorted by frequency';
    return (
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` +
      `<rect x="0" y="0" width="${W}" height="${H}" fill="#ffffff"/>` +
      grid + bars +
      `<line x1="${pad}" y1="${base}" x2="${W - pad}" y2="${base}" stroke="#262626" stroke-width="0.75"/>` +
      `<text x="${pad}" y="${H - 8}" font-family='${AXIS_FONT}' font-size="11" fill="#262626">Top ${clusters.length} clusters &#8226; ${label}</text>` +
      `</svg>`
    );
  }

  function hueLightnessSvg(sizeMode) {
    const W = 420, H = 240, pad = 26;
    let dots = '';
    clusters.forEach((k) => {
      const x = pad + (k.h / 360) * (W - pad * 2);
      const y = H - pad - k.l * (H - pad * 2);
      const rad = 2 + (sizeMode === 'frequency' ? Math.sqrt(k.share) * 30 : k.c * 14);
      dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rad.toFixed(1)}" fill="${k.hex}" stroke="rgba(38,38,38,0.3)" stroke-width="0.5"/>`;
    });
    return (
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` +
      `<rect x="${pad}" y="${pad}" width="${W - pad * 2}" height="${H - pad * 2}" fill="none" stroke="rgba(38,38,38,0.5)" stroke-width="0.75"/>` +
      `<line x1="${W / 2}" y1="${pad}" x2="${W / 2}" y2="${H - pad}" stroke="rgba(38,38,38,0.25)" stroke-width="0.5"/>` +
      `<line x1="${pad}" y1="${H / 2}" x2="${W - pad}" y2="${H / 2}" stroke="rgba(38,38,38,0.25)" stroke-width="0.5"/>` +
      dots +
      `<text x="${pad - 12}" y="${H / 2}" font-family='${AXIS_FONT}' font-size="12" fill="#262626" transform="rotate(-90 ${pad - 12} ${H / 2})" text-anchor="middle">Lightness</text>` +
      `</svg>`
    );
  }

  function valuesHistogramSvg() {
    const W = 640, H = 150, pad = 14, base = H - 12;
    let bars = '';
    const n = 48;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      const amp = Math.exp(-Math.pow((t - 0.32) / 0.22, 2)) + 0.55 * Math.exp(-Math.pow((t - 0.78) / 0.14, 2)) + 0.06;
      const h = amp * (base - 14) * 0.72;
      const g = Math.round(t * 232);
      const bw = (W - pad * 2) / n;
      bars += `<rect x="${(pad + i * bw + 0.5).toFixed(1)}" y="${(base - h).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${h.toFixed(1)}" fill="rgb(${g},${g},${g})" stroke="rgba(38,38,38,0.25)" stroke-width="0.25"/>`;
    }
    return (
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` +
      `<rect x="0" y="0" width="${W}" height="${H}" fill="#ffffff"/>` + bars +
      `<line x1="${pad}" y1="${base}" x2="${W - pad}" y2="${base}" stroke="#262626" stroke-width="0.75"/>` +
      `</svg>`
    );
  }

  window.CTKit = { clusters, polarSvg, histogramSvg, hueLightnessSvg, valuesHistogramSvg };
})();
