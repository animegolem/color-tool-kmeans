// Color Tool UI kit — Exports view: builder sections (Colors / Values / Batch) + PNG scale
const { useState: useStateE } = React;

function BuilderItem({ label, checked, onChange, sub, subChecked, onSubChange, disabled }) {
  return (
    <label className={'builder-item' + (disabled ? ' disabled' : '')}>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
      {sub && (
        <span className="sub-toggle" onClick={(e) => e.stopPropagation()}>
          <label className="sub-toggle-inner">
            <input type="checkbox" checked={subChecked} onChange={(e) => onSubChange(e.target.checked)} />
            <span className="sub-toggle-label">{sub}</span>
          </label>
        </span>
      )}
      <span className="spacer"></span>
      <button className="item-download" title="Save PNG" disabled={disabled}>↓</button>
    </label>
  );
}

function DataRow({ label, action }) {
  return (
    <div className="data-row">
      <span>{label}</span>
      <span className="spacer"></span>
      <button>{action}</button>
    </div>
  );
}

function ExportsView({ hasMedia }) {
  const [scale, setScale] = useStateE(2);
  const [checks, setChecks] = useStateE({ src: true, polar: true, hist: true, hl: false, strip: true, neutral: true, range: true, vhist: false, simple: true, grid: false });
  const set = (k) => (v) => setChecks((c) => ({ ...c, [k]: v }));
  const [allSorts, setAllSorts] = useStateE(false);
  const [inclOriginal, setInclOriginal] = useStateE(true);
  const [allStudies, setAllStudies] = useStateE(false);
  const [saving, setSaving] = useStateE(false);

  if (!hasMedia) {
    return (
      <section className="exports">
        <h1>Exports</h1>
        <div className="empty-state">Load media in Colors to configure exports.</div>
      </section>
    );
  }

  const fakeSave = () => { setSaving(true); setTimeout(() => setSaving(false), 1200); };

  return (
    <section className="exports">
      <h1>Exports</h1>
      <div className="builder-section">
        <h2>Colors</h2>
        <div className="builder-items">
          <BuilderItem label="Source Image" checked={checks.src} onChange={set('src')} />
          <BuilderItem label="Polar Chart" checked={checks.polar} onChange={set('polar')} />
          <BuilderItem label="Cluster Histogram" checked={checks.hist} onChange={set('hist')} sub="All sorts" subChecked={allSorts} onSubChange={setAllSorts} />
          <BuilderItem label="Hue × Lightness" checked={checks.hl} onChange={set('hl')} />
          <BuilderItem label="Palette Strip (top 20)" checked={checks.strip} onChange={set('strip')} />
          <BuilderItem label="Video Barcode" checked={false} onChange={() => {}} disabled />
          <DataRow label="Palette CSV" action="Save CSV" />
          <DataRow label="Palette .ase" action="Save .ase" />
          <DataRow label="Palette JSON" action="Save JSON" />
        </div>
        <button className="composite-btn" onClick={fakeSave}>Export Colors Composite</button>
      </div>

      <div className="builder-section">
        <h2>Values</h2>
        <div className="builder-items">
          <BuilderItem label="Neutral Values" checked={checks.neutral} onChange={set('neutral')} sub="Include original" subChecked={inclOriginal} onSubChange={setInclOriginal} />
          <BuilderItem label="Range Finder" checked={checks.range} onChange={set('range')} />
          <BuilderItem label="Values Histogram" checked={checks.vhist} onChange={set('vhist')} />
          <BuilderItem label="Simplified Values" checked={checks.simple} onChange={set('simple')} sub="All studies" subChecked={allStudies} onSubChange={setAllStudies} />
        </div>
        <button className="composite-btn" onClick={fakeSave}>Export Values Composite</button>
      </div>

      <div className="builder-section">
        <h2>Batch</h2>
        <div className="builder-items">
          <BuilderItem label="Composite Grid" checked={false} onChange={() => {}} disabled />
          <BuilderItem label="Polar Chart" checked={checks.grid} onChange={set('grid')} />
          <DataRow label="Palette CSV" action="Save CSV" />
        </div>
        <button className="composite-btn" disabled>Export Batch Composite</button>
      </div>

      <div className="builder-section">
        <div className="scale-control scale-control--standalone">
          <label>
            <span>PNG Scale</span>
            <span className="scale-value">{scale}×</span>
            <input type="range" min={1} max={4} step={1} value={scale} onChange={(e) => setScale(Number(e.target.value))} />
          </label>
        </div>
      </div>

      {saving && <div className="status status-saving">Saving…</div>}
    </section>
  );
}

Object.assign(window, { ExportsView });
