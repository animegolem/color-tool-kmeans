// Color Tool UI kit — Settings view (recreated from SettingsView.svelte)
const { useState: useStateS } = React;

function SettingsView() {
  const [compact, setCompact] = useStateS(false);
  const [clusterMax, setClusterMax] = useStateS(400);
  const [excludeMax, setExcludeMax] = useStateS(50);
  const [charts, setCharts] = useStateS({ hist: true, polar: true, hl: true });
  const [tones, setTones] = useStateS(true);
  const [strip, setStrip] = useStateS('barcode');
  const [frameLabel, setFrameLabel] = useStateS('timestamp');
  const [format, setFormat] = useStateS('png');

  const Radio = ({ name, value, current, onChange, label }) => (
    <label className="choice">
      <input type="radio" name={name} value={value} checked={current === value} onChange={() => onChange(value)} />
      {label}
    </label>
  );

  return (
    <section className="settings">
      <div className="group">
        <h2>App</h2>
        <KitCheck label="Compact sidebars (always overlay)" checked={compact} onChange={setCompact} />
      </div>
      <div className="group">
        <h2>Colors</h2>
        <div className="field">
          <KitRange label="Max clusters" value={clusterMax} min={10} max={5000} step={10} onChange={setClusterMax} number />
          <p className="hint">Higher values (1000+) may slow processing on some hardware.</p>
        </div>
        <div className="field">
          <KitRange label="Max excludable clusters" value={excludeMax} min={10} max={500} step={10} onChange={setExcludeMax} number />
        </div>
        <div className="field">
          <span className="field-label">Display Charts</span>
          <p className="hint">Applies to Colors and Batch views.</p>
          <KitCheck label="Cluster Histogram" checked={charts.hist} onChange={(v) => setCharts({ ...charts, hist: v })} />
          <KitCheck label="Polar Chart" checked={charts.polar} onChange={(v) => setCharts({ ...charts, polar: v })} />
          <KitCheck label="Hue x Lightness" checked={charts.hl} onChange={(v) => setCharts({ ...charts, hl: v })} />
        </div>
      </div>
      <div className="group">
        <h2>Values</h2>
        <KitCheck label="Show simplified-tones panel" checked={tones} onChange={setTones} />
      </div>
      <div className="group">
        <h2>Video</h2>
        <div className="field">
          <span className="field-label">Strip Style</span>
          <Radio name="strip" value="filmstrip" current={strip} onChange={setStrip} label="Filmstrip (scene thumbnails)" />
          <Radio name="strip" value="barcode" current={strip} onChange={setStrip} label="Barcode (per-frame color)" />
        </div>
        <div className="field">
          <span className="field-label">Export Frame Label</span>
          <Radio name="flabel" value="timestamp" current={frameLabel} onChange={setFrameLabel} label="Timestamp (e.g. -00m03s25)" />
          <Radio name="flabel" value="frame" current={frameLabel} onChange={setFrameLabel} label="Frame number (e.g. -f97)" />
        </div>
      </div>
      <div className="group">
        <h2>Export</h2>
        <div className="field">
          <span className="field-label">Graph export format</span>
          <Radio name="fmt" value="svg" current={format} onChange={setFormat} label="SVG (raw vector)" />
          <Radio name="fmt" value="png" current={format} onChange={setFormat} label="PNG (rasterized at scale)" />
        </div>
        <label>
          <span>Save directory</span>
          <div className="dir-row">
            <span className="dir-path">…/Pictures/color-tool-exports</span>
            <button type="button" className="browse-btn">Browse</button>
          </div>
        </label>
      </div>
      <div className="group reset-group">
        <button type="button" className="reset-btn">Reset to defaults</button>
      </div>
    </section>
  );
}

Object.assign(window, { SettingsView });
