# Color Tool — UI kit

Cosmetic, interactive recreation of the shipped desktop app (`tauri-app/src`), pixel-values ported from the Svelte source.

- `index.html` — entry; app shell (nav / header / library rail) with view switching
- `kit.css` — shell + view styles, ported 1:1 from `app.css`, `inputs.css`, and view `<style>` blocks
- `kit-data.js` — fake cluster palette + SVG chart generators (polar, histogram, hue×lightness, values histogram)
- `KitBits.jsx` — ToggleGroup, KitRange, AnalysisCard, MediaBucket, LoadingOverlay
- `ColorsView.jsx` — Home: dropzone empty state, image preview, three analysis cards, Parameters panel
- `ValuesView.jsx` — neutral pair, range finder, values histogram, simplified-tones buckets
- `ExportsView.jsx` — builder sections (Colors / Values / Batch) + PNG scale
- `SettingsView.jsx` — preferences groups
- `AppShell.jsx` — shell + Media Bucket state; "Add media" fakes a 900ms analysis with the loading overlay

Interactions that work: nav switching, sidebar/library toggles, media bucket select/pin/remove/clear, all segmented toggles, range scrubbing, exports checkboxes, fake "Saving…" status, settings controls.

Intentionally not recreated: Batch results view (three-panel layout — see `BatchView.svelte`), video scrubber/filmstrip (video-specific), zoom overlay, context menus.
