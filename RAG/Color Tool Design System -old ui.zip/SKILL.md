---
name: color-tool-design
description: Use this skill to generate well-branded interfaces and assets for Color Tool (perceptual color & tonality analysis app for artists), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key facts: cream page #F5EFE1, canonical ink #262626, warm brown accent #866051, Fira Sans (UI) + Fira Code (vertical labels only), white 12px-radius cards with 0 2px 6px shadows, ink-alpha hairlines, pill segmented controls, bare dark scrollbars, no logo (render "Color Tool" in type).
