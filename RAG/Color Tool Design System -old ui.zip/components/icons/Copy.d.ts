import * as React from 'react';

/** Figma icon family "Copy" — renders the nearest authored size variant (16/20/24/32/40/48). */
export interface CopyProps extends React.SVGProps<SVGSVGElement> {
  /** Rendered size in px; snaps the glyph to the nearest authored variant */
  size?: number;
}
export declare const Copy: React.FC<CopyProps>;
export default Copy;
