import Icon from './Icon.jsx';

/* Figma icon family "Copy" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const COPY_SIZES = [16, 20, 24, 32, 40, 48];

export function Copy({ size = 24, ...rest }) {
  const s = COPY_SIZES.reduce((b, v) => (Math.abs(v - size) < Math.abs(b - size) ? v : b), 48);
  return <Icon name={'CopySize' + s} size={size} {...rest} />;
}
export default Copy;
