Figma icon family "Copy" (6 authored sizes) — convenience wrapper over `Icon`.

```jsx
const { Copy } = window.ColorToolDesignSystem_73584b;
<Copy size={24} style={{ color: 'var(--accent)' }} />
```

Paints via currentColor; picks the nearest authored variant (16/20/24/32/40/48) for correct stroke weight.
