import * as React from 'react';

/** Figma icon family "X square" — renders the nearest authored size variant (16/20/24/32/40/48). */
export interface XSquareProps extends React.SVGProps<SVGSVGElement> {
  /** Rendered size in px; snaps the glyph to the nearest authored variant */
  size?: number;
}
export declare const XSquare: React.FC<XSquareProps>;
export default XSquare;
