import * as React from 'react';

/** Figma icon family "Sun" — renders the nearest authored size variant (16/20/24/32/40/48). */
export interface SunProps extends React.SVGProps<SVGSVGElement> {
  /** Rendered size in px; snaps the glyph to the nearest authored variant */
  size?: number;
}
export declare const Sun: React.FC<SunProps>;
export default Sun;
