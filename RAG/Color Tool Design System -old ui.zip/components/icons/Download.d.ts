import * as React from 'react';

/** Figma icon family "Download" — renders the nearest authored size variant (16/20/24/32/40/48). */
export interface DownloadProps extends React.SVGProps<SVGSVGElement> {
  /** Rendered size in px; snaps the glyph to the nearest authored variant */
  size?: number;
}
export declare const Download: React.FC<DownloadProps>;
export default Download;
