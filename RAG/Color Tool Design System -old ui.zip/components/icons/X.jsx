import Icon from './Icon.jsx';

/* Figma icon family "X" — thin wrapper over icon-data.js; renders the
   nearest authored size variant (16/20/24/32/40/48), painted via currentColor. */
const X_SIZES = [16, 20, 24, 32, 40, 48];

export function X({ size = 24, ...rest }) {
  const s = X_SIZES.reduce((b, v) => (Math.abs(v - size) < Math.abs(b - size) ? v : b), 48);
  return <Icon name={'XSize' + s} size={size} {...rest} />;
}
export default X;
