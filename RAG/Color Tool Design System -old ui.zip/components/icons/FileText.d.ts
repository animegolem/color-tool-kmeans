import * as React from 'react';

/** Figma icon family "File text" — renders the nearest authored size variant (16/20/24/32/40/48). */
export interface FileTextProps extends React.SVGProps<SVGSVGElement> {
  /** Rendered size in px; snaps the glyph to the nearest authored variant */
  size?: number;
}
export declare const FileText: React.FC<FileTextProps>;
export default FileText;
