Renders any of the 12 Figma icon families (Check, Chevron up, Copy, Download, File text, Image, Loader, Sun, X, X circle, X square) at their 6 authored sizes — use whenever the UI needs a glyph.

```jsx
const { Icon } = window.ColorToolDesignSystem_73584b;
<Icon name="CheckSize24" />
<Icon name="LoaderSize32" style={{ color: 'var(--accent)' }} />
```

- `name` is `<Family>Size<16|20|24|32|40|48>` — see Icon.d.ts for the full list.
- Icons paint with `currentColor`; each size variant carries its authored stroke weight, so prefer the matching size over CSS scaling.
- `size` overrides the rendered box (defaults to the size in the name).
