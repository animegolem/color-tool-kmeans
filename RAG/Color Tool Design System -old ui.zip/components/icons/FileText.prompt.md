Figma icon family "File text" (6 authored sizes) — convenience wrapper over `Icon`.

```jsx
const { FileText } = window.ColorToolDesignSystem_73584b;
<FileText size={24} style={{ color: 'var(--accent)' }} />
```

Paints via currentColor; picks the nearest authored variant (16/20/24/32/40/48) for correct stroke weight.
