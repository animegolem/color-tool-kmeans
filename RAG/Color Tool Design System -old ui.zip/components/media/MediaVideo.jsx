import React from 'react';

/*
  MediaVideo — the standalone "Video" symbol from the .fig (node 87:372):
  stroked video-camera glyph, ink rgb(30,30,30). Same glyph the app ships
  as lib/assets/media-video.svg.
*/
export function MediaVideo({ size = 32, color = 'rgb(30,30,30)', style, className, title = 'Video' }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      role="img"
      aria-label={title}
      style={{ color, ...style }}
    >
      <path
        d="M30.6667 9.33329L21.3334 16L30.6667 22.6666V9.33329Z"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.6667 6.66663H4.00004C2.52728 6.66663 1.33337 7.86053 1.33337 9.33329V22.6666C1.33337 24.1394 2.52728 25.3333 4.00004 25.3333H18.6667C20.1395 25.3333 21.3334 24.1394 21.3334 22.6666V9.33329C21.3334 7.86053 20.1395 6.66663 18.6667 6.66663Z"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default MediaVideo;
