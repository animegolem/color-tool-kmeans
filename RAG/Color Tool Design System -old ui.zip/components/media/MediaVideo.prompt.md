Stroked "video camera" media symbol (the .fig's standalone Video component) — marks video media in buckets, badges, scrubber panels.

```jsx
const { MediaVideo } = window.ColorToolDesignSystem_73584b;
<MediaVideo />                      // 32px, ink
<MediaVideo size={16} color="#fff" /> // badge on a thumbnail
```

- Round-capped 3px stroke, paints via `color`.
- Sibling `MediaImage` is the image counterpart.
