import React from 'react';

/*
  MediaImage — the standalone "Image" symbol from the .fig (node 87:377):
  40×40 slot, 30×30 stroked image glyph inset 5px, ink rgb(30,30,30).
  Same glyph the app ships as lib/assets/media-image.svg.
*/
export function MediaImage({ size = 40, color = 'rgb(30,30,30)', style, className, title = 'Image' }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      role="img"
      aria-label={title}
      style={{ color, ...style }}
    >
      <path
        d="M8.33333 35H31.6667C33.5076 35 35 33.5076 35 31.6667V8.33333C35 6.49238 33.5076 5 31.6667 5H8.33333C6.49238 5 5 6.49238 5 8.33333V31.6667C5 33.5076 6.49238 35 8.33333 35ZM8.33333 35L26.6667 16.6667L35 25M16.6667 14.1667C16.6667 15.5474 15.5474 16.6667 14.1667 16.6667C12.786 16.6667 11.6667 15.5474 11.6667 14.1667C11.6667 12.786 12.786 11.6667 14.1667 11.6667C15.5474 11.6667 16.6667 12.786 16.6667 14.1667Z"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default MediaImage;
