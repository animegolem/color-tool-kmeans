import * as React from 'react';

/** The standalone "Video" media symbol from the .fig (node 87:372) — stroked video-camera glyph used to mark video media. */
export interface MediaVideoProps {
  /** Rendered square size in px (source: 32) */
  size?: number | string;
  /** Stroke color (source: rgb(30,30,30)) */
  color?: string;
  style?: React.CSSProperties;
  className?: string;
  title?: string;
}
export declare const MediaVideo: React.FC<MediaVideoProps>;
export default MediaVideo;
