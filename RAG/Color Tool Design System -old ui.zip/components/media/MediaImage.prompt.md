Stroked "image" media symbol (the .fig's standalone Image component) — marks image media in buckets, badges, empty slots.

```jsx
const { MediaImage } = window.ColorToolDesignSystem_73584b;
<MediaImage />                      // 40px, ink
<MediaImage size={16} color="#fff" /> // badge on a thumbnail
```

- Round-capped 3.5 stroke, paints via `color`.
- Sibling `MediaVideo` is the video counterpart.
