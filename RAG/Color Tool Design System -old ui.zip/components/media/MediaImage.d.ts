import * as React from 'react';

/** The standalone "Image" media symbol from the .fig (node 87:377) — stroked image glyph used to mark image media. */
export interface MediaImageProps {
  /** Rendered square size in px (source: 40) */
  size?: number | string;
  /** Stroke color (source: rgb(30,30,30)) */
  color?: string;
  style?: React.CSSProperties;
  className?: string;
  title?: string;
}
export declare const MediaImage: React.FC<MediaImageProps>;
export default MediaImage;
