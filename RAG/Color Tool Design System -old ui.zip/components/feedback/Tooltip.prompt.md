Bordered white tooltip with title + optional body and a directional beak — the richer of the two tooltip styles in the .fig.

```jsx
const { Tooltip } = window.ColorToolDesignSystem_73584b;
<Tooltip placement="top" title="Polar Chart" body="Hue × chroma in OKLCH" />
<Tooltip placement="bottom" title="Save PNG" hasBody={false} />
```

- `placement`: `top` | `bottom` | `left` | `right` (beak position).
- White surface, 1px `--border-default-default` border, radius 8, soft double shadow.
- Static-positioned: place it yourself (absolute wrapper) next to the anchor.
