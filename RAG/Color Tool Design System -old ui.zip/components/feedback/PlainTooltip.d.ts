import * as React from 'react';
export interface PlainTooltipProps {
  className?: string;
  style?: React.CSSProperties;
  type?: "single line" | "multi line";
  supportingText?: string;
}
export declare const PlainTooltip: React.FC<PlainTooltipProps>;
export default PlainTooltip;
