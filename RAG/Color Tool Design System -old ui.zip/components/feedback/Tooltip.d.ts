import * as React from 'react';
export interface TooltipProps {
  className?: string;
  style?: React.CSSProperties;
  placement?: "top" | "left" | "right" | "bottom";
  title?: string;
  hasBody?: boolean;
  body?: string;
}
export declare const Tooltip: React.FC<TooltipProps>;
export default Tooltip;
