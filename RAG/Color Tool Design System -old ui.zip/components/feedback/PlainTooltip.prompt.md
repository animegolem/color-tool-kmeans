Compact dark tooltip (Material "plain tooltip" style from the .fig) for one-liner hints.

```jsx
const { PlainTooltip } = window.ColorToolDesignSystem_73584b;
<PlainTooltip type="single line" supportingText="Snap to real pixels" />
<PlainTooltip type="multi line" supportingText="Longer wrapped explanation…" />
```

- `type`: `single line` (fit-content, nowrap) | `multi line` (200px wide, wraps).
- Inverse surface bg, 12px Roboto-stack text, radius 4.
