// figma node: 39:4750 Tooltip (4 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "placement=" + __venc(p.placement);

export function Tooltip(_p = {}) {
  const props = { ..._p, placement: _p.placement ?? "top", title: _p.title ?? "Title", hasBody: _p.hasBody ?? true, body: _p.body ?? "Body text" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,0.707,-0.707,0.707,44,52.050)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--background-default-default)",
      }}>
        <path d={"M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,0.707,-0.707,0.707,44,52.050)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--border-default-default)",
      }}>
        <path d={"M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
      }}>{props.title}</span>
      {props.hasBody && (
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.body}</span>
      )}
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,-0.707,-0.707,-0.707,44,5.950)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--background-default-default)",
      }}>
        <path d={"M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,-0.707,-0.707,-0.707,44,5.950)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--border-default-default)",
      }}>
        <path d={"M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
      }}>{props.title}</span>
      {props.hasBody && (
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.body}</span>
      )}
    </div>
  );
  const __body2 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,0.707,0.707,-0.707,82.050,29)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--background-default-default)",
      }}>
        <path d={"M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(0.707,0.707,0.707,-0.707,82.050,29)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--border-default-default)",
      }}>
        <path d={"M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
      }}>{props.title}</span>
      {props.hasBody && (
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.body}</span>
      )}
    </div>
  );
  const __body3 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      borderRadius: 8,
      backgroundColor: "var(--background-default-default)",
      borderTop: "1px solid var(--border-default-default)",
      borderRight: "1px solid var(--border-default-default)",
      borderBottom: "1px solid var(--border-default-default)",
      borderLeft: "1px solid var(--border-default-default)",
      boxShadow: "0px 1px 4px 0px rgba(12,12,13,0.1), 0px 1px 4px 0px rgba(12,12,13,0.05)",
      display: "flex",
      flexDirection: "column",
      padding: "8px 12px 8px 12px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      gap: "calc(var(--space-0) * 1px)",
      paddingLeft: "calc(var(--space-300) * 1px)",
      paddingTop: "calc(var(--space-200) * 1px)",
      paddingRight: "calc(var(--space-300) * 1px)",
      paddingBottom: "calc(var(--space-200) * 1px)",
      position: "relative",
      ...props.style,
    }}>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(-0.707,0.707,-0.707,-0.707,5.950,29)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--background-default-default)",
      }}>
        <path d={"M 0 0 L 8 0 L 8 8 L 0 8 L 0 0 Z"} fill="currentColor" fillRule="nonzero" />
      </svg>
      <svg width={8} height={8} viewBox="0 0 8 8" fill="none" style={{
        position: "absolute",
        left: 0,
        top: 0,
        transform: "matrix(-0.707,0.707,-0.707,-0.707,5.950,29)",
        transformOrigin: "0 0",
        width: 8,
        height: 8,
        color: "var(--border-default-default)",
      }}>
        <path d={"M 0 8 L 8 8 L 8 0 L 7 0 L 7 7 L 0 7 L 0 8 Z"} fill="currentColor" fillRule="evenodd" />
      </svg>
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 600,
        fontSize: 16,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
      }}>{props.title}</span>
      {props.hasBody && (
      <span style={{
        position: "relative",
        fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 14,
        textAlign: "center",
        whiteSpace: "nowrap",
        lineHeight: 1.399999976158142,
        color: "rgb(0,0,0)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.body}</span>
      )}
    </div>
  );
  const __impls = {
    // figma: Placement=Top
    "placement=top": __body0,
    // figma: Placement=Bottom
    "placement=bottom": __body1,
    // figma: Placement=Left
    "placement=left": __body2,
    // figma: Placement=Right
    "placement=right": __body3,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default Tooltip;
