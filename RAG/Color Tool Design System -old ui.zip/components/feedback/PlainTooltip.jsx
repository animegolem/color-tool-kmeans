// figma node: 39:4826 Plain Tooltip (2 variants)
const __venc = (v) => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = (p) => "type=" + __venc(p.type);

export function PlainTooltip(_p = {}) {
  const props = { ..._p, type: _p.type ?? "single line", supportingText: _p.supportingText ?? "Supporting text" };
  const __body0 = () => (
    <div className={props.className} style={{
      width: "fit-content",
      minHeight: 24,
      borderRadius: 4,
      backgroundColor: "var(--schemes-inverse-surface)",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "4px 8px 4px 8px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Roboto, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 12,
        whiteSpace: "nowrap",
        lineHeight: "16px",
        letterSpacing: "0.400px",
        color: "var(--schemes-inverse-on-surface)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.supportingText}</span>
    </div>
  );
  const __body1 = () => (
    <div className={props.className} style={{
      width: 200,
      minHeight: 24,
      borderRadius: 4,
      backgroundColor: "var(--schemes-inverse-surface)",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "4px 8px 4px 8px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style,
    }}>
      <span style={{
        position: "relative",
        fontFamily: "Roboto, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
        fontWeight: 400,
        fontSize: 12,
        lineHeight: "16px",
        letterSpacing: "0.400px",
        color: "var(--schemes-inverse-on-surface)",
        flexShrink: 0,
        alignSelf: "stretch",
      }}>{props.supportingText}</span>
    </div>
  );
  const __impls = {
    // figma: Type=Single line
    "type=single line": __body0,
    // figma: Type=Multi line
    "type=multi line": __body1,
  };
  return (__impls[__vkey(props)] ?? __body0)();
}
export default PlainTooltip;
