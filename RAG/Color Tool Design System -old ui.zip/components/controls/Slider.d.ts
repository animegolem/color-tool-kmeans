import * as React from 'react';

/**
 * Interactive port of the Figma "Slider - Default" family (node 2:4042).
 * Sizes map to exact variant heights: mini 12 / sm 16 / regular 28 / lg 44.
 * @startingPoint section="Controls" subtitle="Capsule slider — 4 sizes, hover thumb" viewport="700x220"
 */
export interface SliderProps {
  /** Variant axis "Size" — mini(12px) | sm(16px) | regular(28px) | lg(44px) */
  size?: 'mini' | 'sm' | 'regular' | 'lg';
  /** Controlled value */
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  /** Variant axis "State=Disabled" */
  disabled?: boolean;
  onChange?: (value: number) => void;
  /** Optional leading glyph rendered at 15% opacity (as in the source symbol slot) */
  symbol?: string;
  style?: React.CSSProperties;
  className?: string;
  'aria-label'?: string;
}
export declare const Slider: React.FC<SliderProps>;
export default Slider;
