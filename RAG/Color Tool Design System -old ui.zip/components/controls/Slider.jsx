import React, { useRef, useState, useCallback } from 'react';

/*
  Slider — faithful interactive port of the .fig "Slider - Default" family
  (figma node 2:4042, 80 variants: Size mini/sm/regular/lg × Value × State).
  Exact geometry & paint lifted from the source variants:
    heights: lg 44 / regular 28 / sm 16 / mini 12, width 288, radius 100
    track:  black 10% over rgba(208,208,208,0.5) + inset highlights/shadows
    fill:   rgba(255,255,255,0.6) capsule, drop-shadow(5px 0 4px rgba(0,0,0,0.18))
    thumb (hover/pinch, lg/regular only): 24px white circle, soft glow
*/

const SLIDER_HEIGHTS = { mini: 12, sm: 16, regular: 28, lg: 44 };

const TRACK_BG =
  'linear-gradient(rgba(0,0,0,0.1),rgba(0,0,0,0.1)), linear-gradient(rgba(208,208,208,0.5),rgba(208,208,208,0.5))';
const TRACK_INSET =
  'inset 0px -0.5px 1px 0px rgba(255,255,255,0.3), inset 0px -0.5px 1px 0px rgba(255,255,255,0.25), inset 1px 1.5px 4px 0px rgba(0,0,0,0.08), inset 1px 1.5px 4px 0px rgba(0,0,0,0.1)';

export function Slider({
  size = 'regular',
  value: valueProp,
  defaultValue = 50,
  min = 0,
  max = 100,
  disabled = false,
  onChange,
  symbol,
  style,
  className,
  'aria-label': ariaLabel,
}) {
  const [internal, setInternal] = useState(defaultValue);
  const [hover, setHover] = useState(false);
  const [pinch, setPinch] = useState(false);
  const trackRef = useRef(null);
  const value = valueProp !== undefined ? valueProp : internal;
  const h = SLIDER_HEIGHTS[size] || SLIDER_HEIGHTS.regular;
  const pct = max === min ? 0 : ((value - min) / (max - min)) * 100;

  const setFromEvent = useCallback(
    (e) => {
      const el = trackRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      const next = Math.round(min + Math.min(1, Math.max(0, x / rect.width)) * (max - min));
      if (valueProp === undefined) setInternal(next);
      if (onChange) onChange(next);
    },
    [min, max, onChange, valueProp]
  );

  const onPointerDown = (e) => {
    if (disabled) return;
    setPinch(true);
    setFromEvent(e);
    const move = (ev) => setFromEvent(ev);
    const up = () => {
      setPinch(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const onKeyDown = (e) => {
    if (disabled) return;
    const step = e.shiftKey ? 10 : 1;
    let next = value;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') next = Math.max(min, value - step);
    else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') next = Math.min(max, value + step);
    else return;
    e.preventDefault();
    if (valueProp === undefined) setInternal(next);
    if (onChange) onChange(next);
  };

  const showThumb = (hover || pinch) && !disabled && (size === 'lg' || size === 'regular');

  return (
    <div
      ref={trackRef}
      className={className}
      role="slider"
      tabIndex={disabled ? -1 : 0}
      aria-label={ariaLabel || 'Slider'}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuenow={value}
      aria-disabled={disabled || undefined}
      onPointerDown={onPointerDown}
      onKeyDown={onKeyDown}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: 288,
        height: h,
        borderRadius: 100,
        position: 'relative',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        outline: 'none',
        touchAction: 'none',
        ...style,
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          overflow: 'hidden',
          borderRadius: 100,
          background: TRACK_BG,
          boxShadow: TRACK_INSET,
        }}
      >
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            bottom: 0,
            width: `${pct}%`,
            minWidth: pct > 0 ? h : 0,
            borderRadius: 100,
            backgroundColor: 'rgba(255,255,255,0.6)',
            boxShadow: '5px 0px 4px 0px rgba(0,0,0,0.18)',
          }}
        />
      </div>
      {showThumb && (
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: `calc(${pct}% )`,
            transform: `translate(${pct > 92 ? '-100%' : pct < 8 ? '0' : '-50%'}, -50%)`,
            width: 24,
            height: 24,
            borderRadius: 100,
            backgroundColor: 'rgb(255,255,255)',
            filter:
              'drop-shadow(0px 0px 26px rgba(94,94,94,0.4)) drop-shadow(0px 0px 26px rgba(255,255,255,0.2))',
            pointerEvents: 'none',
          }}
        />
      )}
      {symbol && (
        <span
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: h,
            height: h,
            display: 'grid',
            placeItems: 'center',
            opacity: 0.15,
            fontFamily:
              '"SF Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
            fontWeight: 510,
            fontSize: 19,
            lineHeight: '22px',
            color: 'rgba(255,255,255,0.96)',
            pointerEvents: 'none',
          }}
        >
          {symbol}
        </span>
      )}
    </div>
  );
}

export default Slider;

// Alias matching the Figma family name "Slider - Default"
export const SliderDefault = Slider;
