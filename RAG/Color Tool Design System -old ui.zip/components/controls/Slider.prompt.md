Interactive capsule slider ported from the .fig "Slider - Default" family — frosted gray track with inset shadows, translucent white fill, hover thumb. Use for parameter scrubbing in mockups of the original concept direction.

```jsx
const { Slider } = window.ColorToolDesignSystem_73584b;
<Slider size="regular" defaultValue={50} onChange={(v) => …} aria-label="Number of clusters" />
```

- `size`: `mini` (12px) | `sm` (16px) | `regular` (28px) | `lg` (44px) — exact variant heights.
- Controlled (`value`) or uncontrolled (`defaultValue`); `min`/`max` default 0–100.
- `disabled` renders at 45% opacity; keyboard arrows work (Shift = ×10).
- Note: the *shipped app* instead styles native `<input type="range">` (bare 5px line + 22px ring thumb — see the "Scrollbar & range input" card). Pick per surface.
