# Code changes implied by the notebook redesign

Running list of changes the codebase needs (beyond pure restyling), collected as design decisions land. Paths refer to `tauri-app/src/lib/`.

## Decided

1. **Remove "Snap to real pixels" from the UI** — `views/home/ParameterControls.svelte`. No user reason to ever uncheck it. Keep `params.snapToReal` hardcoded `true` (or remove the param entirely if nothing else reads it).

2. **Hue × Lightness default size mode: `chroma` → `frequency`** — `stores/analysis.ts` (`hueLightnessSizeMode: 'chroma'` in the `params` writable). Toggle stays, order in UI reads `[frequency] chroma`.

3. **Surface the palette ledger in the Colors view** — currently the swatch list only exists at export time (`exports/palette.ts` → `generatePaletteSvg`). The Colors view needs a live top-N ledger (swatch + `[r:g:b] · count px · share%`) rendered from `AnalysisResult.clusters`, with quick actions: copy hex, save CSV / .ase / JSON (reuse the exports runners).

4. **Media Bucket restructure** — `components/MediaBucket.svelte` stops being a persistent right sidebar:
   - a "recent" strip (3–4 items) docked at the bottom of the Colors page;
   - a full bucket view as its own page ("turn the page" navigation); clicking a clip loads it and returns to Colors.

5. **Remove the dedicated upload affordance** (header button / ribbon concept). Ingestion = drag-and-drop anywhere on the sheet + click-to-browse on the image slot (both already exist in `services/media-ingestion.ts` / drag-drop).

6. **Nav becomes edge tabs** — `App.svelte` sidebar replaced by in-border notebook tabs (Colors / Values / Batch / Exports; Settings likely relegated to a corner affordance). The per-view header bar (title + italic description + collapse buttons) goes away; that vertical space returns to content.

7. **Chart toggles restyle, not rework** — the pill `toggle-group`s in `views/home/AnalysisCards.svelte` become inline bracket selectors (`[frequency] hue lightness`, `oklch [okhsv] hsv`, `[frequency] chroma`). Same state, same handlers.

8. **Metrics line moves** — `durationMs · iterations · samples` renders as a small caption under the histogram figure instead of inside the card header.

9. **Responsive reflow: spread → single column** — below a width threshold (~1100 px) the two-page spread folds into one scrolling single-column page (image → params → figures → palette), with a quick page-fold transition. Tabs stay in the border. Needs a layout breakpoint + transition state in the view shell.

10. **Values layout: original above neutral** — `views/ValuesView.svelte` `preview-pair` goes from 2-up columns to stacked full-width rows so both images render larger; scrubber sits directly beneath the pair.

11. **Display setting: chart ground — "flat ink" vs "pinned cards"** — a prefs toggle (Settings → Colors). Flat renders figures directly on the paper; pinned renders each figure (and the palette) on a white card pinned to the page. White ground reads color truer; skeuomorphic vs flat is user taste. Applies to Colors (and plausibly Batch aggregate) figures.

12. **Zoom overlay chrome + ground** — `components/ZoomOverlay.svelte` keeps its behavior (wheel zoom, drag pan, pinch, double-click fit, esc/backdrop close) and gains light chrome: title line (figure number + active toggle set), ✕ close, "fit" control, % readout, hint line. Frame shrinks from 92vw/92vh to ~70% of the window, centered with generous margin — it should float over the app, not fill it. Ground follows the chart-ground setting: flat = cream frame, pinned = white card that "lifts off the page" (open/close animates the lift; the page shows a pin hole + ghost outline while open). Hovering a histogram bar surfaces its ledger row.

## To watch (not yet decided)

- Parameters live on the left page next to the image — always visible, no scrolling (kills the `margin-top: 32px` below-the-fold `controls` section).
- Page-turn animation for bucket / view changes — needs a view-transition layer in `App.svelte`.
- Batch view layout in the notebook idiom is still approximate in the wireframes; revisit against `views/BatchView.svelte` before committing.
