// Reflow motion studies — three treatments of spread → single column
// Uses globals from animations.jsx: Stage, Sprite, useTime, useSprite, Easing, interpolate, clamp
(function () {
  const { Stage, Sprite, useSprite, Easing, interpolate, clamp } = window;
  const R = React;
  const h = R.createElement;

  // ---------- shared mini-page pieces (wireframe fills) ----------
  const CREAM = '#F5EFE1', CREAM2 = '#F8F2E5', INK = '#2b2926', DESK = '#6e6764';
  const hatch = (a, b, s) => `repeating-linear-gradient(45deg,${a},${a} ${s}px,${b} ${s}px,${b} ${s * 2}px)`;

  function Tabs({ h: hh }) {
    return h('div', { style: { position: 'absolute', left: 0, top: hh * 0.06, display: 'flex', flexDirection: 'column', gap: 8 } },
      ['#7a5343', '#8d6a5a', '#8d6a5a', '#8d6a5a'].map((c, i) =>
        h('div', { key: i, style: { width: i === 0 ? 9 : 7, height: hh * 0.11, background: c, borderRadius: '0 3px 3px 0' } })));
  }

  function ImgBlock({ w, hh }) {
    return h('div', { style: { width: w, height: hh, border: `1.5px solid ${INK}`, background: hatch('#e5ddc9', '#ede6d4', 8), boxSizing: 'border-box' } });
  }
  function Sliders({ w, n }) {
    return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 9, width: w } },
      Array.from({ length: n }, (_, i) =>
        h('div', { key: i, style: { height: 6, borderRadius: 99, background: '#ddd5c2', position: 'relative' } },
          h('div', { style: { position: 'absolute', left: `${25 + i * 18}%`, top: -3, width: 12, height: 12, borderRadius: '50%', background: '#fcf8ee', border: '1px solid rgba(43,41,38,.45)' } }))));
  }
  function Histo({ w, hh }) {
    const bars = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#696955', '#9e5738', '#2f5b6e'];
    return h('div', { style: { width: w, height: hh, display: 'flex', alignItems: 'flex-end', gap: 2, borderBottom: `1.5px solid ${INK}`, boxSizing: 'border-box' } },
      bars.map((c, i) => h('div', { key: i, style: { flex: 1, height: `${100 - i * 12}%`, background: c } })));
  }
  function Polar({ d }) {
    return h('div', { style: { width: d, height: d, position: 'relative' } },
      h('div', { style: { position: 'absolute', inset: d * 0.06, borderRadius: '50%', border: `1.5px solid ${INK}` } }),
      h('div', { style: { position: 'absolute', left: 0, right: 0, top: '50%', height: 1, background: 'rgba(43,41,38,.5)' } }),
      h('div', { style: { position: 'absolute', top: 0, bottom: 0, left: '50%', width: 1, background: 'rgba(43,41,38,.5)' } }),
      [['56%', '18%', '#6e3a1f', 0.09], ['48%', '40%', '#cfc4ae', 0.08], ['54%', '58%', '#3a4034', 0.1], ['40%', '64%', '#2f5b6e', 0.05]].map((p, i) =>
        h('div', { key: i, style: { position: 'absolute', left: p[0], top: p[1], width: d * p[3], height: d * p[3], borderRadius: '50%', background: p[2] } })));
  }
  function Ledger({ w }) {
    const rows = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#9e5738'];
    return h('div', { style: { width: w, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px 14px' } },
      rows.map((c, i) => h('div', { key: i, style: { display: 'flex', alignItems: 'center', gap: 5 } },
        h('div', { style: { width: 16, height: 9, background: c, borderRadius: 2 } }),
        h('div', { style: { flex: 1, height: 4, background: 'rgba(43,41,38,.25)', borderRadius: 99 } }))));
  }

  // Left page content (fixed across all treatments)
  function LeftPageContent({ pw, ph }) {
    return h('div', { style: { padding: `${ph * 0.055}px ${pw * 0.08}px`, paddingLeft: pw * 0.14, position: 'relative', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: ph * 0.05 } },
      h(Tabs, { h: ph }),
      h('div', { style: { width: '46%', height: 10, background: 'rgba(43,41,38,.55)', borderRadius: 2 } }),
      h(ImgBlock, { w: '100%', hh: ph * 0.34 }),
      h(Sliders, { w: '92%', n: 4 }));
  }

  // Right page figures — rendered via a layout map so treatments can animate positions
  function RightFigures({ pw, ph }) {
    return h('div', { style: { padding: `${ph * 0.055}px ${pw * 0.08}px`, height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: ph * 0.055 } },
      h(Histo, { w: '100%', hh: ph * 0.24 }),
      h('div', { style: { display: 'flex', gap: pw * 0.07, alignItems: 'flex-start' } },
        h(Polar, { d: ph * 0.3 }),
        h('div', { style: { flex: 1, height: ph * 0.3, borderLeft: `1.5px solid ${INK}`, borderBottom: `1.5px solid ${INK}` } })),
      h(Ledger, { w: '100%' }));
  }

  // window chrome that narrows over time
  function Win({ w, hh, children, label }) {
    return h('div', { style: { position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: w, height: hh, background: DESK, borderRadius: 10, boxShadow: '0 18px 50px rgba(0,0,0,.45)', overflow: 'hidden' } },
      h('div', { style: { position: 'absolute', left: 0, right: 0, top: 0, height: 26, background: '#3a3735', display: 'flex', alignItems: 'center', gap: 6, padding: '0 12px' } },
        ['#e0564f', '#e0a03c', '#57a45b'].map((c, i) => h('div', { key: i, style: { width: 9, height: 9, borderRadius: '50%', background: c } })),
        h('div', { style: { marginLeft: 'auto', font: '11px Fira Code, monospace', color: 'rgba(255,255,255,.55)' } }, label)),
      h('div', { style: { position: 'absolute', left: 0, right: 0, top: 26, bottom: 0 } }, children));
  }

  // ============================================================
  // Treatment A — CROSSFADE + RE-STACK (recommended)
  // Right page fades, figures slide into the column, spine fades.
  // ============================================================
  function SceneA({ t0 }) {
    const { localTime } = useSprite();
    const t = localTime;
    // window width narrows 0→2s, holds, widens 5.5→7.5s
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const compact = winW < 980;
    // reflow progress: 0 = spread, 1 = single column (with hysteresis feel)
    const p = interpolate([1.35, 1.95, 5.75, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);

    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const rightOpacity = 1 - clamp(p * 2.2, 0, 1);          // right page fades early
    const figuresIn = clamp((p - 0.35) / 0.6, 0, 1);        // figures slide in after
    const spineOp = 1 - clamp(p * 3, 0, 1);

    return h(Win, { w: winW, hh: H + 26, label: `${Math.round(winW)}px ${compact ? '· compact' : ''}` },
      // left page — grows into the single column
      h('div', { style: { position: 'absolute', left: '50%', top: 18, transform: `translateX(${-pageW * (1 - p * 0.5)}px)`, width: pageW, height: H - 60, background: CREAM, border: `1px solid ${INK}`, boxShadow: '0 4px 12px rgba(0,0,0,.3)' } },
        h(LeftPageContent, { pw: pageW, ph: (H - 60) * (1 - p * 0.42) }),
        // figures re-stacking into the column below the sliders
        h('div', { style: { position: 'absolute', left: '8%', right: '8%', bottom: 14, height: (H - 60) * 0.34, opacity: figuresIn, transform: `translateY(${(1 - figuresIn) * 40}px)`, display: figuresIn > 0.01 ? 'flex' : 'none', flexDirection: 'column', gap: 10 } },
          h(Histo, { w: '100%', hh: (H - 60) * 0.16 }),
          h('div', { style: { display: 'flex', gap: 16 } }, h(Polar, { d: (H - 60) * 0.14 }), h('div', { style: { flex: 1 } }, h(Ledger, { w: '100%' })))),
        // scroll hint in compact
        figuresIn > 0.9 && h('div', { style: { position: 'absolute', right: 5, top: 8, bottom: 8, width: 4, borderRadius: 99, background: 'rgba(43,41,38,.12)' } },
          h('div', { style: { position: 'absolute', left: 0, right: 0, top: '4%', height: '34%', borderRadius: 99, background: 'rgba(122,83,67,.55)' } }))),
      // spine
      h('div', { style: { position: 'absolute', left: '50%', top: 18, transform: 'translateX(-50%)', width: 10, height: H - 60, background: 'linear-gradient(90deg,rgba(0,0,0,.08),rgba(0,0,0,.28),rgba(0,0,0,.08))', opacity: spineOp } }),
      // right page — fades + drifts left
      h('div', { style: { position: 'absolute', left: '50%', top: 18, transform: `translateX(${p * -30}px)`, width: winW / 2 - 60, height: H - 60, background: CREAM2, border: `1px solid ${INK}`, boxShadow: '0 4px 12px rgba(0,0,0,.3)', opacity: rightOpacity, pointerEvents: 'none' } },
        h(RightFigures, { pw: winW / 2 - 60, ph: H - 60 })));
  }

  // ============================================================
  // Treatment B — PAGE FOLD (the heavy one, for comparison)
  // Right page rotates behind the left on a perspective hinge.
  // ============================================================
  function SceneB() {
    const { localTime } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.85, 5.85, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);

    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const foldDeg = p * -168;
    const figuresIn = clamp((p - 0.55) / 0.45, 0, 1);

    return h(Win, { w: winW, hh: H + 26, label: `${Math.round(winW)}px · fold` },
      h('div', { style: { position: 'absolute', left: '50%', top: 18, transform: `translateX(${-pageW * (1 - p * 0.5)}px)`, width: pageW, height: H - 60, background: CREAM, border: `1px solid ${INK}`, boxShadow: '0 4px 12px rgba(0,0,0,.3)' } },
        h(LeftPageContent, { pw: pageW, ph: (H - 60) * (1 - p * 0.42) }),
        h('div', { style: { position: 'absolute', left: '8%', right: '8%', bottom: 14, height: (H - 60) * 0.34, opacity: figuresIn, transform: `translateY(${(1 - figuresIn) * 40}px)`, display: figuresIn > 0.01 ? 'flex' : 'none', flexDirection: 'column', gap: 10 } },
          h(Histo, { w: '100%', hh: (H - 60) * 0.16 }),
          h('div', { style: { display: 'flex', gap: 16 } }, h(Polar, { d: (H - 60) * 0.14 }), h('div', { style: { flex: 1 } }, h(Ledger, { w: '100%' }))))),
      // folding right page, hinged at the spine
      h('div', { style: { position: 'absolute', left: '50%', top: 18, width: winW / 2 - 60, height: H - 60, perspective: 900, transformStyle: 'preserve-3d', pointerEvents: 'none' } },
        h('div', { style: { width: '100%', height: '100%', background: CREAM2, border: `1px solid ${INK}`, boxShadow: `${8 + p * 20}px 0 ${16 + p * 24}px rgba(0,0,0,${0.25 + p * 0.2})`, transform: `rotateY(${foldDeg}deg)`, transformOrigin: 'left center', backfaceVisibility: 'hidden' } },
          h(RightFigures, { pw: winW / 2 - 60, ph: H - 60 })),
        // back face (paper back)
        h('div', { style: { position: 'absolute', inset: 0, background: '#e8e1ce', border: `1px solid ${INK}`, transform: `rotateY(${foldDeg + 180}deg)`, transformOrigin: 'left center', backfaceVisibility: 'hidden' } })));
  }

  // ============================================================
  // Treatment C — SLIDE UNDER (right page slips beneath the left, like sliding a sheet under the top one)
  // ============================================================
  function SceneC() {
    const { localTime } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.9, 5.8, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);

    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const slideX = p * -(winW / 2 - 40);
    const figuresIn = clamp((p - 0.5) / 0.5, 0, 1);

    return h(Win, { w: winW, hh: H + 26, label: `${Math.round(winW)}px · slide-under` },
      // right page slides under: z-order below left, translates left + dims slightly
      h('div', { style: { position: 'absolute', left: '50%', top: 18 + p * 8, transform: `translateX(${slideX}px) scale(${1 - p * 0.06})`, width: winW / 2 - 60, height: H - 60, background: CREAM2, border: `1px solid ${INK}`, boxShadow: '0 4px 12px rgba(0,0,0,.3)', opacity: 1 - p * 0.55, zIndex: 1, pointerEvents: 'none' } },
        h(RightFigures, { pw: winW / 2 - 60, ph: H - 60 })),
      h('div', { style: { position: 'absolute', left: '50%', top: 18, transform: `translateX(${-pageW * (1 - p * 0.5)}px)`, width: pageW, height: H - 60, background: CREAM, border: `1px solid ${INK}`, boxShadow: `${p * 10}px 6px ${14 + p * 10}px rgba(0,0,0,.32)`, zIndex: 2 } },
        h(LeftPageContent, { pw: pageW, ph: (H - 60) * (1 - p * 0.42) }),
        h('div', { style: { position: 'absolute', left: '8%', right: '8%', bottom: 14, height: (H - 60) * 0.34, opacity: figuresIn, transform: `translateY(${(1 - figuresIn) * 40}px)`, display: figuresIn > 0.01 ? 'flex' : 'none', flexDirection: 'column', gap: 10 } },
          h(Histo, { w: '100%', hh: (H - 60) * 0.16 }),
          h('div', { style: { display: 'flex', gap: 16 } }, h(Polar, { d: (H - 60) * 0.14 }), h('div', { style: { flex: 1 } }, h(Ledger, { w: '100%' }))))));
  }

  function Caption({ text, sub }) {
    return h('div', { style: { position: 'absolute', left: 0, right: 0, bottom: 34, textAlign: 'center' } },
      h('div', { style: { font: '600 30px Fira Code, monospace', color: '#f3ece0' } }, text),
      h('div', { style: { font: '17px Fira Sans, sans-serif', color: 'rgba(243,236,224,.65)', marginTop: 6 } }, sub));
  }

  function ReflowStudies() {
    const DUR = 24;
    return h(Stage, { width: 1440, height: 810, duration: DUR, background: '#4a4340', loop: true },
      // A
      h(Sprite, { start: 0, end: 8 }, h(SceneA, null), h(Caption, { text: 'A · crossfade + re-stack', sub: 'right page fades ~120ms → figures slide into the column · cheap, interruptible — recommended for live resize' })),
      // B
      h(Sprite, { start: 8, end: 16 }, h(SceneB, null), h(Caption, { text: 'B · page fold', sub: 'right page folds behind on a spine hinge · charming but heavy — better saved for deliberate page turns' })),
      // C
      h(Sprite, { start: 16, end: 24 }, h(SceneC, null), h(Caption, { text: 'C · slide under', sub: 'right sheet slips beneath the left, column grows over it · middle ground, keeps paper physicality' })));
  }

  window.ReflowStudies = ReflowStudies;
})();
