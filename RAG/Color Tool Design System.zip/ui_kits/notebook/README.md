# Color Tool — notebook UI kit

The app in the notebook idiom, full size (wireframes ×2.25), interactive. Built from `design-docs/UI Shell Wireframes.dc.html`:

- **Colors** — 4a: taped photo, always-visible parameters, bucket strip, figures 01–04 + palette ledger
- **Values** — 5b: original stacked over neutral, scrubber beneath, range finder / values histogram / simplified tones
- **Batch** — 5d (approx, per the wireframe's own caveat): contact sheet + pinned aggregate
- **Exports** — 5c: single sheet, packing list, rubber-stamp composites
- **Bucket page** — 3b: via the folded corner or "view all ↘"; clicking a clip loads it and returns to Colors
- **Zoom overlay** — 7a/7b: click any figure or preview; Esc/✕/outside closes
- **Chart ground** — 6a: flat ink ↔ pinned cards toggle on the desk (top right)

Files: `index.html` (entry) · `kit-data.js` (palette data from the wireframes) · `ColorsSpread.jsx` (page shells, ink charts, Colors) · `Views.jsx` (Values, Exports, Batch, Bucket) · `NotebookApp.jsx` (desk shell, tabs, zoom).

Not built (undecided in the docs): compact single-column reflow, page-turn animation, Settings sheet, ingestion overlay states (see `design-docs/` 5a and 7c for specs).
