// Notebook UI kit — Values spread (5b), Exports sheet (5c), Batch spread (5d), Bucket page (3b)
const DS2 = window.ColorToolDesignSystem_73584b;
const { Figure: Fig2, BracketSelector: Brackets2, PaperSlider: Slider2, Scrubber, StampButton, FoldedCorner: Fold2, TapedPhoto: Taped2, BucketTile: Tile2 } = DS2;
const { valueBars, IMG: IMG2, bars: bars2, ledger: ledger2, polarDots: polar2 } = window.CTNotebook;

const MICRO = { font: '600 13px var(--font-mono)', letterSpacing: '.08em', color: 'var(--text-55)', marginBottom: 7 };

function ValuesSpread({ onZoom }) {
  const [t, setT] = React.useState(42);
  const [levels, setLevels] = React.useState(3);
  const shares = { 2: [58, 42], 3: [31, 46, 23], 4: [24, 30, 27, 19], 5: [18, 24, 25, 20, 13] }[levels];
  const tones = { 2: ['#2a2926', '#e4dbc2'], 3: ['#2a2926', '#837c69', '#e4dbc2'], 4: ['#1c1a17', '#5a5548', '#a89f89', '#e4dbc2'], 5: ['#1c1a17', '#454138', '#837c69', '#c2b9a1', '#eae1c8'] }[levels];
  return (
    <React.Fragment>
      <window.LeftPage>
        <window.PageTitle title="VALUES" filename="pan-shot.mp4" />
        <div style={{ marginTop: 22 }}>
          <div style={MICRO}>ORIGINAL</div>
          <div style={{ position: 'relative' }}>
            <img src={IMG2} alt="frame @ 00:42" style={{ display: 'block', width: '100%', height: 265, objectFit: 'cover', border: '1px solid var(--ink-line)', boxSizing: 'border-box', cursor: 'zoom-in' }}
              onClick={() => onZoom({ title: 'original', meta: 'frame @ 00:42', kind: 'image' })} />
            <span style={{ position: 'absolute', left: 7, bottom: 7, font: '11px var(--font-mono)', background: 'rgba(38,38,38,.75)', color: 'var(--tab-text)', padding: '1px 5px' }}>frame @ 00:42</span>
            <span style={{ position: 'absolute', right: 7, top: 7, width: 23, height: 23, border: '1px solid var(--ink-line)', borderRadius: 4, display: 'grid', placeItems: 'center', fontSize: 12, background: 'rgba(245,239,225,.85)' }}>✂</span>
          </div>
        </div>
        <div style={{ marginTop: 18 }}>
          <div style={MICRO}>NEUTRAL VALUES</div>
          <img src={IMG2} alt="neutral values" style={{ display: 'block', width: '100%', height: 265, objectFit: 'cover', border: '1px solid var(--ink-line)', boxSizing: 'border-box', filter: 'grayscale(1)', cursor: 'zoom-in' }}
            onClick={() => onZoom({ title: 'neutral values', meta: 'oklab L channel', kind: 'neutral' })} />
        </div>
        <Scrubber time={t} duration={121} onScrub={setT} onSnapshot={() => {}} style={{ marginTop: 20 }} />
      </window.LeftPage>
      <window.RightPage>
        <Fig2 number="01" title="range finder" control={<span style={{ font: '13px var(--font-mono)', color: 'var(--text-60)' }}>MID KEY · MODERATE CONTRAST</span>}>
          <div style={{ height: 50, border: '1px solid var(--ink-line)', borderRadius: 99, background: 'linear-gradient(90deg,#2a2926,#f8f2e3)', position: 'relative', marginTop: 13, overflow: 'hidden' }}>
            <div style={{ position: 'absolute', left: '2%', top: 4, bottom: 4, width: '95%', borderRadius: 99, background: 'rgba(38,38,38,.08)' }}></div>
            <div style={{ position: 'absolute', left: '14%', top: 11, bottom: 11, width: '68%', borderRadius: 99, background: 'rgba(38,38,38,.2)' }}></div>
            <div style={{ position: 'absolute', left: '2%', top: 2, bottom: 2, width: '95%', borderRadius: 99, border: '2px solid rgba(38,38,38,.75)', boxSizing: 'border-box' }}></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', font: '12px var(--font-mono)', color: 'var(--text-60)', marginTop: 7 }}>
            <span>0</span><span>mass 14–82% · extremes 2–97%</span><span>100</span>
          </div>
        </Fig2>
        <Fig2 number="02" title="values histogram">
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height: 117, borderBottom: '1px solid var(--ink-line)', marginTop: 11, cursor: 'zoom-in' }}
            onClick={() => onZoom({ title: '02 · values histogram', meta: '12 buckets · oklab L', kind: 'vhist' })}>
            {valueBars.map(([c, h], i) => <div key={i} style={{ flex: 1, height: h + '%', background: c }}></div>)}
          </div>
        </Fig2>
        <Fig2 number="03" title="simplified tones" divider style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
          control={
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 11, font: '13px var(--font-mono)', color: 'rgba(38,38,38,.7)' }}>
              levels
              <Slider2 label="" value={levels} min={2} max={5} onChange={setLevels} labelWidth={0} valueWidth={20} style={{ width: 170 }} />
            </span>
          }>
          <div style={{ display: 'flex', gap: 4, border: '1px solid var(--ink-40)', borderRadius: 9, overflow: 'hidden', marginTop: 16, height: 54 }}>
            {shares.map((s, i) => (
              <div key={i} style={{ flex: s, background: tones[i], display: 'grid', placeItems: 'center', color: i < shares.length / 2 ? '#e8e2d2' : '#14120f', font: '600 13px var(--font-mono)', cursor: 'pointer' }}>{s}%</div>
            ))}
          </div>
          <img src={IMG2} alt="simplified preview" style={{ display: 'block', width: '100%', flex: 1, minHeight: 126, objectFit: 'cover', border: '1px solid var(--ink-line)', boxSizing: 'border-box', marginTop: 18, filter: `grayscale(1) contrast(${0.7 + levels * 0.3})` }} />
        </Fig2>
        <Fold2 onClick={() => {}} />
      </window.RightPage>
    </React.Fragment>
  );
}

function ExportRow({ checked, label, note, dim }) {
  const [on, setOn] = React.useState(checked);
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', font: '15px var(--font-mono)', color: dim ? 'rgba(38,38,38,.4)' : 'inherit', cursor: dim ? 'default' : 'pointer' }} onClick={dim ? undefined : () => setOn(!on)}>
      <span>[{on && !dim ? 'x' : ' '}] {label} {note && <span style={{ color: 'var(--text-50)' }}>({note})</span>}</span>
      <span style={{ color: dim ? 'inherit' : 'var(--tab-active)' }}>↓</span>
    </div>
  );
}

function ExportsSheet() {
  const [scale, setScale] = React.useState(2);
  const [fmt, setFmt] = React.useState('svg');
  const rule = { fontSize: 16, fontWeight: 600, borderBottom: '1px solid var(--ink-line)', paddingBottom: 7, fontFamily: 'var(--font-mono)' };
  const col = { display: 'flex', flexDirection: 'column', gap: 11, marginTop: 14 };
  return (
    <div className="nb-ruled-left" style={{ width: 909, height: 958, background: 'var(--paper)', border: '1px solid var(--ink-line)', position: 'relative', padding: '34px 40px 27px 99px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', margin: '0 auto', fontFamily: 'var(--font-mono)' }}>
      <window.PageTitle title="EXPORTS" filename="study-014" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 40px', marginTop: 22, flex: 1 }}>
        <div>
          <div style={rule}>── colors ──</div>
          <div style={col}>
            <ExportRow checked label="source image" />
            <ExportRow checked label="polar chart" />
            <ExportRow checked label="cluster histogram" note="+all sorts" />
            <ExportRow label="hue × lightness" />
            <ExportRow checked label="palette strip" note="top 20" />
            <ExportRow label="video barcode" dim />
          </div>
          <div style={{ display: 'flex', gap: 18, fontSize: 14, color: 'var(--tab-active)', marginTop: 18 }}>
            <u style={{ cursor: 'pointer' }}>csv</u><u style={{ cursor: 'pointer' }}>.ase</u><u style={{ cursor: 'pointer' }}>json</u>
          </div>
          <div style={{ marginTop: 20 }}><StampButton>Export Colors Composite</StampButton></div>
        </div>
        <div>
          <div style={rule}>── values ──</div>
          <div style={col}>
            <ExportRow checked label="neutral values" note="+original" />
            <ExportRow checked label="range finder" />
            <ExportRow label="values histogram" />
            <ExportRow checked label="simplified values" note="+all studies" />
          </div>
          <div style={{ marginTop: 20 }}><StampButton rotate={0.5}>Export Values Composite</StampButton></div>
          <div style={{ marginTop: 32, borderTop: '1px dashed var(--ink-35)', paddingTop: 18 }}>
            <Slider2 label="png scale" value={scale} min={1} max={4} onChange={setScale} labelWidth={110} valueWidth={40} format={(v) => v + '×'} />
            <div style={{ display: 'flex', gap: 14, alignItems: 'center', fontSize: 13, color: 'var(--text-60)', marginTop: 16 }}>
              <span>format:</span>
              <Brackets2 options={['svg', 'png']} value={fmt} onChange={setFmt} />
            </div>
          </div>
        </div>
      </div>
      <div style={{ fontSize: 12, color: 'var(--text-50)' }}>saving to ~/art/studies/exports · <u style={{ color: 'var(--tab-active)', cursor: 'pointer' }}>change</u></div>
    </div>
  );
}

function BatchSpread({ onZoom }) {
  return (
    <React.Fragment>
      <window.LeftPage>
        <window.PageTitle title="BATCH" filename="6 items · 2 pinned" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20, marginTop: 27 }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} style={{ position: 'relative', height: 144, border: i < 2 ? '3px solid var(--tab-active)' : '2px solid var(--ink-40)', background: `url(${IMG2}) ${20 * i}% center / cover`, boxSizing: 'border-box' }}>
              {i < 2 && <span style={{ position: 'absolute', left: '50%', top: -9, transform: 'translateX(-50%)', width: 18, height: 18, borderRadius: '50%', background: 'var(--pin-red)', boxShadow: '0 2px 4px rgba(0,0,0,.3)' }}></span>}
            </div>
          ))}
          <div style={{ height: 144, border: '2px dashed var(--ink-40)', display: 'grid', placeItems: 'center', color: 'var(--tab-active)', fontSize: 27, boxSizing: 'border-box' }}>+</div>
        </div>
        <div style={{ font: '12px var(--font-mono)', color: 'var(--text-55)', marginTop: 14 }}>pin ◉ = include in aggregate · click to open in Colors</div>
        <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 18 }}>
          <Slider2 label="Clusters per image" defaultValue={45} min={1} max={200} labelWidth={230} />
          <Slider2 label="Speed ← → Quality" defaultValue={2} min={0} max={4} labelWidth={230} />
        </div>
      </window.LeftPage>
      <window.RightPage>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <span style={{ font: '600 17px var(--font-mono)' }}>aggregate · 2 pinned images</span>
          <span style={{ font: '14px var(--font-mono)', color: 'var(--text-60)', cursor: 'pointer' }}>recompute ↻</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 27 }}>
          <Fig2 number="01" title="combined polar">
            <window.Polar size={207} onZoom={() => onZoom({ title: '01 · combined polar', meta: '2 pinned images', kind: 'polar' })} />
          </Fig2>
          <Fig2 number="02" title="combined histogram">
            <window.Histogram height={180} onZoom={() => onZoom({ title: '02 · combined histogram', meta: '2 pinned images', kind: 'histogram' })} />
          </Fig2>
        </div>
        <Fig2 number="03" title="combined palette strip" divider>
          <div style={{ display: 'flex', height: 45, border: '1px solid var(--ink-line)', overflow: 'hidden', marginTop: 11 }}>
            {[['#3c3f38', 12], ['#1c1a17', 10], ['#898575', 9], ['#d2c5af', 8], ['#603425', 7], ['#696955', 6], ['#9e5738', 5], ['#2f5b6e', 4], ['#dbd1ba', 3], ['#10130f', 3]].map(([c, f], i) => (
              <div key={i} style={{ flex: f, background: c }}></div>
            ))}
          </div>
        </Fig2>
        <div style={{ flex: 1, minHeight: 117, border: '1px solid var(--ink-line)', background: 'var(--hatch)', display: 'grid', placeItems: 'center', marginTop: 4 }}>
          <span style={{ font: '13px var(--font-mono)', color: 'var(--hatch-text)' }}>composite grid preview</span>
        </div>
        <Fold2 onClick={() => {}} />
      </window.RightPage>
    </React.Fragment>
  );
}

function BucketPage({ onLoad, onBack }) {
  const items = [
    { name: 'study-014.png', loaded: true }, { name: 'ref-cafe.jpg' }, { name: 'pan-shot.mp4', video: true, chip: '02:01' },
    { name: 'pan-shot_0042.png', chip: 'frame @ 00:42' }, { name: 'notan-ref.png' }, { name: 'plein-air-03.jpg' }, { name: 'paste-091412.png' }
  ];
  return (
    <div className="nb-ruled-left" style={{ width: 1320, height: 958, background: 'var(--paper)', border: '1px solid var(--ink-line)', position: 'relative', padding: '36px 45px 27px 50px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: '1px solid var(--ink-line)', paddingBottom: 11 }}>
        <span style={{ font: '600 18px var(--font-mono)', letterSpacing: '.08em' }}>MEDIA BUCKET · 7 items</span>
        <span style={{ font: '13px var(--font-mono)', color: 'var(--text-60)' }}>drag to reorder · right-click to remove</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '27px 32px', marginTop: 32 }}>
        {items.map((it, i) => (
          <div key={it.name} style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <div onClick={() => onLoad(it.name)} style={{ height: 167, border: it.loaded ? '4px solid var(--tab-active)' : '2px solid var(--ink-40)', background: `url(${window.CTNotebook.IMG}) ${14 * i}% center / cover`, position: 'relative', cursor: 'pointer', boxSizing: 'border-box' }}>
              {it.loaded && <span style={{ position: 'absolute', left: 7, top: 7, font: '11px var(--font-mono)', background: 'var(--tab-active)', color: 'var(--tab-text)', padding: '1px 7px' }}>loaded</span>}
              {it.video && <span style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 36, height: 36, border: '1px solid var(--ink-line)', borderRadius: '50%', display: 'grid', placeItems: 'center', fontSize: 16, background: 'rgba(245,239,225,.8)' }}>▶</span>}
              {it.chip && <span style={{ position: 'absolute', left: 7, bottom: 7, font: '11px var(--font-mono)', background: 'rgba(38,38,38,.7)', color: 'var(--tab-text)', padding: '1px 7px' }}>{it.chip}</span>}
            </div>
            <span style={{ font: '13px var(--font-mono)', color: 'rgba(38,38,38,.75)' }}>{it.name}</span>
          </div>
        ))}
        <div style={{ height: 167, border: '3px dashed var(--ink-40)', display: 'grid', placeItems: 'center', color: 'var(--tab-active)', fontSize: 29, boxSizing: 'border-box', cursor: 'pointer' }}>+</div>
      </div>
      <window.CTFold corner="bottom-left" onClick={onBack} />
      <span onClick={onBack} style={{ position: 'absolute', left: 90, bottom: 20, font: '15px var(--font-mono)', color: 'var(--tab-active)', cursor: 'pointer' }}>↖ turn back to Colors</span>
    </div>
  );
}

window.CTFold = Fold2;
Object.assign(window, { ValuesSpread, ExportsSheet, BatchSpread, BucketPage });
