// Notebook UI kit — Colors spread (wireframe 4a) + shared page/chart bits
const DS = window.ColorToolDesignSystem_73584b;
const { Figure, BracketSelector, PaletteLedger, BucketStrip, BucketTile, PaperSlider, PaperCheckbox, TapedPhoto, PinnedCard, FoldedCorner } = DS;
const { bars, ledger, polarDots, hlDots, IMG } = window.CTNotebook;

// Page shells — full size: each page 794×958 (wf 353×426 ×2.25)
function LeftPage({ children, style }) {
  return (
    <div className="nb-ruled-left" style={{ background: 'var(--paper)', border: '1px solid var(--ink-line)', borderRight: 'none', padding: '34px 45px 22px 99px', position: 'relative', display: 'flex', flexDirection: 'column', boxSizing: 'border-box', ...style }}>
      {children}
    </div>
  );
}
function RightPage({ children, style }) {
  return (
    <div className="nb-ruled-right" style={{ background: 'var(--paper-right)', border: '1px solid var(--ink-line)', borderLeft: 'none', padding: '34px 40px 22px 36px', position: 'relative', display: 'flex', flexDirection: 'column', gap: 25, boxSizing: 'border-box', ...style }}>
      {children}
    </div>
  );
}
function PageTitle({ title, filename, meta }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <span style={{ font: '600 25px var(--font-mono)', letterSpacing: '.06em' }}>
        {title} {filename && <span style={{ fontWeight: 400, color: 'var(--muted-filename)' }}>· {filename}</span>}
      </span>
      {meta && <span style={{ font: '14px var(--font-mono)', color: 'var(--text-55)' }}>{meta}</span>}
    </div>
  );
}

// Ink charts (drawn as divs, like the wireframes)
function Histogram({ height = 126, onZoom }) {
  return (
    <div onClick={onZoom} style={{ display: 'flex', alignItems: 'flex-end', gap: 2, height, borderBottom: '1px solid var(--ink-line)', marginTop: 11, cursor: onZoom ? 'zoom-in' : 'default' }}>
      {bars.map(([c, h], i) => <div key={i} style={{ flex: 1, height: h + '%', background: c }}></div>)}
    </div>
  );
}
function Polar({ size = 234, onZoom, axisLabels = true }) {
  return (
    <div onClick={onZoom} style={{ width: size, height: size, position: 'relative', margin: '13px auto 0', cursor: onZoom ? 'zoom-in' : 'default' }}>
      <div style={{ position: 'absolute', inset: size * 0.058, borderRadius: '50%', border: '1px solid var(--ink-line)' }}></div>
      <div style={{ position: 'absolute', inset: size * 0.23, borderRadius: '50%', border: '1px dashed var(--ink-30)' }}></div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: '50%', height: 1, background: 'var(--ink-55)' }}></div>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', width: 1, background: 'var(--ink-55)' }}></div>
      {axisLabels && <span style={{ position: 'absolute', right: size * 0.04, top: size * 0.11, font: '11px var(--font-mono)', transform: 'rotate(40deg)', color: 'var(--text-60)' }}>← hue →</span>}
      {polarDots.map(([x, y, s, c], i) => (
        <div key={i} style={{ position: 'absolute', left: x + '%', top: y + '%', width: s, height: s, borderRadius: '50%', background: c }}></div>
      ))}
    </div>
  );
}
function HueLightness({ height = 216, onZoom, axisLabels = true }) {
  return (
    <div onClick={onZoom} style={{ height, borderLeft: '1px solid var(--ink-line)', borderBottom: '1px solid var(--ink-line)', position: 'relative', marginTop: 13, cursor: onZoom ? 'zoom-in' : 'default' }}>
      {axisLabels && <span style={{ position: 'absolute', left: -8, top: 0, font: '11px var(--font-mono)', writingMode: 'vertical-rl', transform: 'rotate(180deg)', color: 'var(--text-60)' }}>lightness</span>}
      {axisLabels && <span style={{ position: 'absolute', right: 0, bottom: -16, font: '11px var(--font-mono)', color: 'var(--text-60)' }}>hue °</span>}
      {hlDots.map(([x, y, s, c], i) => (
        <div key={i} style={{ position: 'absolute', left: x + '%', top: y + '%', width: s, height: s, borderRadius: '50%', background: c }}></div>
      ))}
    </div>
  );
}
function GroundWrap({ ground, pin, rotate, children, style }) {
  if (ground === 'pinned') return <PinnedCard pin={pin} rotate={rotate} style={style}>{children}</PinnedCard>;
  return <div style={style}>{children}</div>;
}

function ColorsSpread({ ground, onZoom, onTurnToBucket, loadedName, params, setParam }) {
  const [sort, setSort] = React.useState('frequency');
  const [polarMode, setPolarMode] = React.useState('okhsv');
  const [hlMode, setHlMode] = React.useState('frequency');
  return (
    <React.Fragment>
      <LeftPage>
        <PageTitle title="COLORS" filename={loadedName} meta="3840×2160" />
        <TapedPhoto style={{ width: '86%', margin: '27px auto 0' }} onClose={() => {}}>
          <img src={IMG} alt={loadedName} style={{ display: 'block', width: '100%', height: 275, objectFit: 'cover', border: '1px solid var(--ink-line)', boxSizing: 'border-box' }} />
        </TapedPhoto>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20, marginTop: 36 }}>
          <PaperSlider label="Number of clusters" value={params.clusters} min={1} max={200} onChange={setParam('clusters')} />
          <PaperSlider label="Speed ← → Quality" value={params.quality} min={0} max={4} onChange={setParam('quality')} />
          <PaperSlider label="Exclude top clusters" value={params.exclude} min={0} max={50} onChange={setParam('exclude')} />
          <PaperSlider label="Merge threshold ΔE" value={params.merge} min={0} max={0.1} step={0.01} format={(v) => v.toFixed(2)} onChange={setParam('merge')} />
          <PaperSlider label="Symbol size" value={params.symbol} min={0.5} max={2} step={0.1} format={(v) => v.toFixed(1)} onChange={setParam('symbol')} />
          <div style={{ display: 'flex', gap: 40, alignItems: 'center', marginTop: 4 }}>
            <PaperCheckbox label="Cluster outline" checked={params.outline} onChange={setParam('outline')} />
            <PaperCheckbox label="Axis labels" checked={params.axisLabels} onChange={setParam('axisLabels')} />
          </div>
        </div>
        <BucketStrip total={7} onViewAll={onTurnToBucket} style={{ marginTop: 'auto' }}>
          <BucketTile src={IMG} active alt={loadedName} />
          <BucketTile chip="▶ 02:01" alt="pan-shot.mp4" />
          <BucketTile alt="ref-cafe.jpg" />
          <BucketTile add onClick={() => {}} />
        </BucketStrip>
      </LeftPage>
      <RightPage>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 27 }}>
          <GroundWrap ground={ground} pin="var(--pin-blue)" rotate={0.8}>
            <Figure number="01" title="polar" sub="hue · saturation"
              control={<BracketSelector options={['oklch', 'okhsv', 'hsv']} value={polarMode} onChange={setPolarMode} />}>
              <Polar axisLabels={params.axisLabels} onZoom={() => onZoom({ title: '01 · polar', meta: `oklch [${polarMode}] hsv · hue · saturation`, kind: 'polar' })} />
            </Figure>
          </GroundWrap>
          <GroundWrap ground={ground} pin="var(--pin-green)" rotate={-0.9}>
            <Figure number="02" title="hue × lightness" sub="rendered in oklch"
              control={<BracketSelector options={['frequency', 'chroma']} value={hlMode} onChange={setHlMode} />}>
              <HueLightness axisLabels={params.axisLabels} onZoom={() => onZoom({ title: '02 · hue × lightness', meta: `[${hlMode}] chroma · rendered in oklch`, kind: 'hl' })} />
            </Figure>
          </GroundWrap>
        </div>
        <GroundWrap ground={ground} pin="var(--pin-red)" rotate={-0.6}>
          <Figure number="03" title="cluster histogram" caption="486 ms · 14 iterations · 84,211 samples" divider={ground === 'flat'}
            control={<BracketSelector options={['frequency', 'hue', 'lightness']} value={sort} onChange={setSort} />}>
            <Histogram onZoom={() => onZoom({ title: '03 · cluster histogram', meta: `[${sort}] · 486 ms · 14 iter · 84,211 samples`, kind: 'histogram' })} />
          </Figure>
        </GroundWrap>
        <GroundWrap ground={ground} pin="var(--pin-brown)" rotate={0.4} style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <Figure number="04" title="palette" divider={ground === 'flat'} style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            control={<span style={{ font: '14px var(--font-mono)', color: 'var(--text-60)' }}>{params.clusters} clusters</span>}>
            <PaletteLedger entries={ledger.map(([color, label]) => ({ color, label }))} moreCount={params.clusters - ledger.length} style={{ marginTop: 11, flex: 1 }} />
          </Figure>
        </GroundWrap>
        <FoldedCorner onClick={onTurnToBucket} />
      </RightPage>
    </React.Fragment>
  );
}

Object.assign(window, { LeftPage, RightPage, PageTitle, Histogram, Polar, HueLightness, GroundWrap, ColorsSpread });
