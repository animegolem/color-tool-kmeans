// Notebook UI kit — app shell: desk, spread, edge tabs, view switching, zoom overlay, ground toggle
const DS3 = window.ColorToolDesignSystem_73584b;
const { EdgeTabs: Tabs3, Spine: Spine3, ZoomOverlay: Zoom3, BracketSelector: Brackets3 } = DS3;

const TABS = ['Colors', 'Values', 'Batch', 'Exports'];

function ZoomContent({ kind, axisLabels }) {
  if (kind === 'polar') return <window.Polar size={430} axisLabels={axisLabels} />;
  if (kind === 'histogram') return <div style={{ width: '86%' }}><window.Histogram height={340} /></div>;
  if (kind === 'hl') return <div style={{ width: '80%' }}><window.HueLightness height={360} axisLabels={axisLabels} /></div>;
  if (kind === 'vhist')
    return (
      <div style={{ width: '86%', display: 'flex', alignItems: 'flex-end', gap: 4, height: 320, borderBottom: '1px solid var(--ink-line)' }}>
        {window.CTNotebook.valueBars.map(([c, h], i) => <div key={i} style={{ flex: 1, height: h + '%', background: c }}></div>)}
      </div>
    );
  return (
    <img
      src={window.CTNotebook.IMG}
      alt="zoomed"
      style={{ maxWidth: '100%', maxHeight: '100%', border: '1px solid var(--ink-line)', filter: kind === 'neutral' ? 'grayscale(1)' : 'none' }}
    />
  );
}

function NotebookApp() {
  const [view, setView] = React.useState('Colors');
  const [bucketOpen, setBucketOpen] = React.useState(false);
  const [zoomed, setZoomed] = React.useState(null);
  const [ground, setGround] = React.useState('flat');
  const [loadedName, setLoadedName] = React.useState('study-014.png');
  const [params, setParams] = React.useState({ clusters: 45, quality: 2, exclude: 0, merge: 0, symbol: 1.0, outline: false, axisLabels: true });
  const setParam = (k) => (v) => setParams((p) => ({ ...p, [k]: v }));

  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') setZoomed(null); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const isSpread = !bucketOpen && (view === 'Colors' || view === 'Values' || view === 'Batch');

  return (
    <div data-screen-label={bucketOpen ? 'Media Bucket page' : view + ' view'} style={{ position: 'relative', width: 1720, height: 1030, background: 'var(--desk)', overflow: 'hidden', display: 'grid', placeItems: 'center' }}>
      {/* ground toggle on the desk */}
      <div style={{ position: 'absolute', right: 27, top: 18, font: '13px var(--font-mono)', color: 'rgba(255,255,255,.75)', display: 'flex', gap: 10, alignItems: 'center', zIndex: 3 }}>
        <span>chart ground</span>
        <Brackets3 options={['flat', 'pinned']} value={ground} onChange={setGround} style={{ color: 'rgba(255,255,255,.75)', filter: 'invert(1) hue-rotate(180deg)' }} />
      </div>

      <div style={{ position: 'relative', filter: 'var(--sheet-shadow)' }}>
        {bucketOpen ? (
          <div style={{ position: 'relative' }}>
            {/* the Colors sheet edge peeking left */}
            <div style={{ position: 'absolute', left: -13, top: 4, bottom: 4, width: 13, background: '#e8e1ce', border: '1px solid var(--ink-35)', borderRight: 'none' }}></div>
            <window.BucketPage
              onLoad={(name) => { setLoadedName(name); setBucketOpen(false); setView('Colors'); }}
              onBack={() => setBucketOpen(false)}
            />
          </div>
        ) : isSpread ? (
          <div style={{ width: 1588, height: 958, display: 'grid', gridTemplateColumns: '1fr 1fr', position: 'relative' }}>
            {view === 'Colors' && (
              <window.ColorsSpread ground={ground} onZoom={setZoomed} onTurnToBucket={() => setBucketOpen(true)} loadedName={loadedName} params={params} setParam={setParam} />
            )}
            {view === 'Values' && <window.ValuesSpread onZoom={setZoomed} />}
            {view === 'Batch' && <window.BatchSpread onZoom={setZoomed} />}
            <Spine3 stitched={ground === 'pinned'} />
          </div>
        ) : (
          <window.ExportsSheet />
        )}
        {/* tabs ride the left border of the sheet */}
        <Tabs3
          tabs={TABS}
          active={bucketOpen ? '' : view}
          onSelect={(t) => { setBucketOpen(false); setView(t); }}
        />
      </div>

      <Zoom3
        open={!!zoomed}
        title={zoomed ? zoomed.title : ''}
        meta={zoomed ? zoomed.meta : ''}
        ground={ground}
        zoom={100}
        onClose={() => setZoomed(null)}
        onFit={() => {}}
      >
        {zoomed && <ZoomContent kind={zoomed.kind} axisLabels={params.axisLabels} />}
      </Zoom3>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<NotebookApp />);
