The loaded image taped to the page — slight rotation, tape at the top corners, ✕ unload.

```jsx
const { TapedPhoto } = window.ColorToolDesignSystem_73584b;
<TapedPhoto onClose={unload}>
  <img src={preview} alt={name} style={{ display: 'block', width: '100%', border: '1px solid var(--ink-line)' }} />
</TapedPhoto>
```

closeLabel="✂" for the Values frame-snapshot variant. Give the child its own 1px ink border.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
