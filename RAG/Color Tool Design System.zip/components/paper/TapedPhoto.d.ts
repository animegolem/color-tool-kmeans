import * as React from 'react';

/** The loaded image taped to the page — slight rotation, tape at the top corners, optional ✕ unload (or ✂ snapshot) button. */
export interface TapedPhotoProps {
  /** The image (or hatch placeholder) element */
  children?: React.ReactNode;
  /** Rotation in degrees (default -0.8) */
  rotate?: number;
  onClose?: () => void;
  /** Corner button glyph (default "✕"; Values uses "✂") */
  closeLabel?: string;
  style?: React.CSSProperties;
  className?: string;
}
export declare const TapedPhoto: React.FC<TapedPhotoProps>;
export default TapedPhoto;
