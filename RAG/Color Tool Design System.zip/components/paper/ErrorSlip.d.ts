import * as React from 'react';

/** Errors are paper slips laid on the desk, not toasts. Mono, calm, factual. */
export interface ErrorSlipProps {
  /** Microlabel header, e.g. "ERROR — bad format" */
  label: string;
  /** Error line, e.g. "unsupported format — sketch.heic" */
  message: string;
  /** Quiet detail line, e.g. "try png · jpeg · webp · bmp · gif · tiff · mp4" */
  detail?: string;
  /** Underlined action link, e.g. "retry" */
  action?: string;
  onAction?: () => void;
  onDismiss?: () => void;
  /** Rotation in degrees (slips alternate ±0.4–0.8) */
  rotate?: number;
  style?: React.CSSProperties;
  className?: string;
}
export declare const ErrorSlip: React.FC<ErrorSlipProps>;
export default ErrorSlip;
