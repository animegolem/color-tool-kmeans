import * as React from 'react';

/** A figure on white stock pinned to the page — the "pinned cards" chart ground. Pin colors: --pin-red/-blue/-green/-brown. */
export interface PinnedCardProps {
  children?: React.ReactNode;
  /** Pin color (default var(--pin-red)) */
  pin?: string;
  /** Rotation in degrees; alternate cards between ±0.4–0.9 */
  rotate?: number;
  style?: React.CSSProperties;
  className?: string;
}
export declare const PinnedCard: React.FC<PinnedCardProps>;

/** The ghost outline + pin hole a lifted card leaves on the page (zoom open state). */
export interface PinHoleProps {
  style?: React.CSSProperties;
  className?: string;
}
export declare const PinHole: React.FC<PinHoleProps>;
export default PinnedCard;
