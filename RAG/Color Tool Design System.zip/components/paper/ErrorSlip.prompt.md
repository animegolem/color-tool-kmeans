Errors are paper slips laid on the desk, not toasts — mono, calm, factual, lowercase.

```jsx
const { ErrorSlip } = window.ColorToolDesignSystem_73584b;
<ErrorSlip label="ERROR — bad format" message="unsupported format — sketch.heic"
           detail="try png · jpeg · webp · bmp · gif · tiff · mp4" onDismiss={close} />
<ErrorSlip label="ERROR — analysis failed" message="analysis failed — worker timeout"
           action="retry" onAction={retry} onDismiss={close} rotate={0.4} />
```

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
