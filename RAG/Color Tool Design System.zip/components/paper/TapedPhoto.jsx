import React from 'react';

/*
  TapedPhoto — the loaded image taped to the page (wireframe 4a):
  slight rotation, two tape pieces at the top corners, optional ✕ unload button.
*/
export function TapedPhoto({ children, rotate = -0.8, onClose, closeLabel = '✕', style, className }) {
  return (
    <div className={className} style={{ position: 'relative', transform: `rotate(${rotate}deg)`, ...style }}>
      {children}
      <span
        style={{
          position: 'absolute',
          left: -16,
          top: -11,
          width: 68,
          height: 23,
          background: 'var(--tape)',
          transform: 'rotate(-40deg)',
          pointerEvents: 'none',
        }}
      ></span>
      <span
        style={{
          position: 'absolute',
          right: -16,
          top: -11,
          width: 68,
          height: 23,
          background: 'var(--tape)',
          transform: 'rotate(40deg)',
          pointerEvents: 'none',
        }}
      ></span>
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Unload image"
          style={{
            position: 'absolute',
            right: 7,
            bottom: 7,
            width: 23,
            height: 23,
            border: '1px solid var(--ink-line)',
            borderRadius: 4,
            display: 'grid',
            placeItems: 'center',
            fontSize: 13,
            lineHeight: 1,
            background: 'rgba(245,239,225,.85)',
            padding: 0,
            cursor: 'pointer',
          }}
        >
          {closeLabel}
        </button>
      )}
    </div>
  );
}

export default TapedPhoto;
