A figure on white stock pinned to the page — the "pinned cards" chart ground (display setting; white reads color truer).

```jsx
const { PinnedCard, PinHole } = window.ColorToolDesignSystem_73584b;
<PinnedCard pin="var(--pin-blue)" rotate={0.8}>{chart}</PinnedCard>
<PinHole style={{ height: 140 }} />  // ghost left behind while the card is lifted (zoom open)
```

Pin colors: --pin-red / -blue / -green / -brown; alternate rotations ±0.4–0.9°.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
