import React from 'react';

/*
  PinnedCard — a figure on white stock, pinned to the page (wireframes 6a/7b):
  white card, faint ink border, soft shadow, colored pin at top center, slight rotation.
  The "pinned cards" chart ground (Code Change Notes #11).
*/
export function PinnedCard({ children, pin = 'var(--pin-red)', rotate = -0.6, style, className }) {
  return (
    <div
      className={className}
      style={{
        position: 'relative',
        background: 'var(--card)',
        border: '1px solid var(--ink-25)',
        boxShadow: 'var(--card-shadow)',
        padding: '16px 20px 14px',
        transform: `rotate(${rotate}deg)`,
        ...style,
      }}
    >
      <span
        style={{
          position: 'absolute',
          left: '50%',
          top: -9,
          transform: 'translateX(-50%)',
          width: 20,
          height: 20,
          borderRadius: '50%',
          background: pin,
          boxShadow: '0 2px 4px rgba(0,0,0,.35)',
        }}
      ></span>
      {children}
    </div>
  );
}

/*
  PinHole — what the pinned card leaves behind while lifted (wireframe 7b):
  ghost outline + pin hole.
*/
export function PinHole({ style, className }) {
  return (
    <div
      className={className}
      style={{
        border: '1px dashed var(--ink-35)',
        background: 'rgba(43,41,38,.04)',
        position: 'relative',
        ...style,
      }}
    >
      <span
        style={{
          position: 'absolute',
          left: '50%',
          top: -4,
          transform: 'translateX(-50%)',
          width: 9,
          height: 9,
          borderRadius: '50%',
          background: 'rgba(43,41,38,.45)',
          boxShadow: 'inset 0 2px 2px rgba(0,0,0,.5)',
        }}
      ></span>
    </div>
  );
}

export default PinnedCard;
