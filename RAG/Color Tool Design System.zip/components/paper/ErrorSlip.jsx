import React from 'react';

/*
  ErrorSlip — errors are paper slips laid on the desk, not toasts (wireframe 5a):
  cream slip, ink border, microlabel header, ✗ + message, optional action link, ✕ dismiss.
*/
export function ErrorSlip({ label, message, detail, action, onAction, onDismiss, rotate = -0.8, style, className }) {
  return (
    <div
      className={className}
      style={{
        background: 'var(--paper)',
        border: '1px solid var(--ink-line)',
        boxShadow: 'var(--slip-shadow)',
        padding: '22px 27px',
        transform: `rotate(${rotate}deg)`,
        position: 'relative',
        ...style,
      }}
    >
      <div
        style={{
          fontFamily: 'var(--font-mono)',
          fontWeight: 600,
          fontSize: 14,
          letterSpacing: '0.08em',
          color: 'var(--text-50)',
          textTransform: 'uppercase',
        }}
      >
        {label}
      </div>
      <div style={{ display: 'flex', gap: 18, alignItems: 'center', marginTop: 13 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 25, color: 'var(--error)' }}>✗</span>
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 16, color: 'var(--error)' }}>{message}</div>
          {detail && (
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--text-60)', marginTop: 4 }}>{detail}</div>
          )}
          {action && (
            <button
              type="button"
              onClick={onAction}
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: 13,
                color: 'var(--tab-active)',
                textDecoration: 'underline',
                background: 'none',
                border: 'none',
                padding: 0,
                marginTop: 4,
                cursor: 'pointer',
                display: 'block',
              }}
            >
              {action}
            </button>
          )}
        </div>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss"
          style={{
            position: 'absolute',
            right: 18,
            top: 18,
            fontFamily: 'var(--font-mono)',
            fontSize: 13,
            color: 'rgba(38,38,38,.45)',
            background: 'none',
            border: 'none',
            padding: 0,
            cursor: 'pointer',
          }}
        >
          ✕
        </button>
      )}
    </div>
  );
}

export default ErrorSlip;
