import React from 'react';

/*
  Spine — the spread's center gutter (wireframes 4a/6a):
  a dark vertical gradient; stitched variant adds sewing holes (6a).
*/
export function Spine({ stitched = false, holes = 4, style, className }) {
  return (
    <div
      className={className}
      style={{
        position: 'absolute',
        left: '50%',
        top: 0,
        bottom: 0,
        width: stitched ? 27 : 27,
        transform: 'translateX(-50%)',
        background: 'var(--spine)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        pointerEvents: 'none',
        ...style,
      }}
    >
      {stitched &&
        Array.from({ length: holes }).map((_, i) => (
          <span
            key={i}
            style={{
              width: 16,
              height: 16,
              borderRadius: '50%',
              background: '#55504d',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,.6)',
            }}
          ></span>
        ))}
    </div>
  );
}

export default Spine;
