import React from 'react';

/*
  EdgeTabs — notebook nav: vertical tabs riding the page's left border.
  Wireframe 4a: active #7a5343 w16, inactive #8d6a5a w14, h54, radius 0 3 3 0,
  label cream, letter-spacing .05em. Full size = ×2.25.
*/
export function EdgeTabs({ tabs, active, onSelect, style, className }) {
  return (
    <div
      className={className}
      style={{ position: 'absolute', left: 0, top: 58, display: 'flex', flexDirection: 'column', gap: 27, zIndex: 2, ...style }}
    >
      {tabs.map((t) => {
        const isActive = t === active;
        return (
          <button
            key={t}
            type="button"
            onClick={onSelect ? () => onSelect(t) : undefined}
            style={{
              writingMode: 'vertical-rl',
              fontFamily: 'inherit',
              fontSize: 15,
              letterSpacing: '0.05em',
              background: isActive ? 'var(--tab-active)' : 'var(--tab-inactive)',
              color: 'var(--tab-text)',
              width: isActive ? 36 : 32,
              height: 122,
              display: 'grid',
              placeItems: 'center',
              border: 'none',
              padding: 0,
              borderRadius: '0 7px 7px 0',
              boxShadow: '2px 2px 4px rgba(0,0,0,.25)',
              cursor: onSelect ? 'pointer' : 'default',
              transition: 'width 150ms var(--ease-out), background 150ms var(--ease-out)',
            }}
          >
            {t}
          </button>
        );
      })}
    </div>
  );
}

export default EdgeTabs;
