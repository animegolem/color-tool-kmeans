The spread's center gutter — dark vertical gradient between the two pages.

```jsx
const { Spine } = window.ColorToolDesignSystem_73584b;
<Spine />            // flat ground
<Spine stitched />   // pinned-cards ground: sewing holes
```

Absolutely positioned at the spread's horizontal center (parent position:relative).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
