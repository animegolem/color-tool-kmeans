import * as React from 'react';

/** Notebook nav — vertical tabs riding the page's left border (wireframe 4a). Active tab is wider and darker. */
export interface EdgeTabsProps {
  /** Tab labels in order, e.g. ['Colors','Values','Batch','Exports'] */
  tabs: string[];
  /** Currently active tab label */
  active: string;
  onSelect?: (tab: string) => void;
  style?: React.CSSProperties;
  className?: string;
}
export declare const EdgeTabs: React.FC<EdgeTabsProps>;
export default EdgeTabs;
