import * as React from 'react';

/** The lifted paper corner that turns the page (bucket page, spreads). Absolutely positioned inside a page. */
export interface FoldedCornerProps {
  corner?: 'bottom-right' | 'bottom-left';
  /** Square size in px (default 68 = wf 30 ×2.25) */
  size?: number;
  onClick?: () => void;
  title?: string;
  style?: React.CSSProperties;
  className?: string;
}
export declare const FoldedCorner: React.FC<FoldedCornerProps>;
export default FoldedCorner;
