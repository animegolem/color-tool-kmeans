import * as React from 'react';

/** The spread's center gutter. stitched adds sewing holes (pinned-cards ground). Absolutely positioned inside a spread. */
export interface SpineProps {
  stitched?: boolean;
  holes?: number;
  style?: React.CSSProperties;
  className?: string;
}
export declare const Spine: React.FC<SpineProps>;
export default Spine;
