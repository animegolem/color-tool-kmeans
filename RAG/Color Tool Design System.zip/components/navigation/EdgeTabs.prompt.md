Notebook nav — vertical tabs riding the page's left border; active tab is wider (36px) and darker (#7a5343).

```jsx
const { EdgeTabs } = window.ColorToolDesignSystem_73584b;
<EdgeTabs tabs={['Colors','Values','Batch','Exports']} active={view} onSelect={setView} />
```

Absolutely positioned at left:0 of a page — the parent needs position:relative and left padding (~100px) to clear the tabs.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
