import React from 'react';

/*
  FoldedCorner — the "turn the page" affordance (wireframes 3a/3b/4a):
  a lifted paper corner over the desk. corner="bottom-right" (default) or "bottom-left".
*/
export function FoldedCorner({ corner = 'bottom-right', size = 68, onClick, title = 'Turn the page', style, className }) {
  const right = corner === 'bottom-right';
  return (
    <button
      type="button"
      className={className}
      onClick={onClick}
      aria-label={title}
      title={title}
      style={{
        position: 'absolute',
        bottom: -1,
        [right ? 'right' : 'left']: -1,
        width: size,
        height: size,
        padding: 0,
        background: right
          ? 'linear-gradient(315deg, var(--desk) 48%, #d5ccb6 50%, #ece5d2 100%)'
          : 'linear-gradient(45deg, var(--desk) 48%, #d5ccb6 50%, #ece5d2 100%)',
        border: 'none',
        [right ? 'borderLeft' : 'borderRight']: '1px solid var(--ink-25)',
        borderTop: '1px solid var(--ink-25)',
        boxShadow: right ? '-4px -4px 9px rgba(0,0,0,.12)' : '4px -4px 9px rgba(0,0,0,.12)',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
    ></button>
  );
}

export default FoldedCorner;
