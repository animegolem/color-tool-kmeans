The lifted paper corner that turns the page (bucket page, back to Colors).

```jsx
const { FoldedCorner } = window.ColorToolDesignSystem_73584b;
<FoldedCorner onClick={turnPage} />                    // bottom-right (default)
<FoldedCorner corner="bottom-left" onClick={goBack} />
```

Absolutely positioned inside a page (parent position:relative). Page-turn motion = spine-hinge fold, var(--fold-duration).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
