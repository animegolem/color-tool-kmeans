import * as React from 'react';

/** A numbered figure on the page — mono header "01 · cluster histogram", right-side control slot, metrics caption below. */
export interface FigureProps {
  /** Zero-padded figure number, e.g. "01" */
  number: string;
  /** Lowercase title, e.g. "cluster histogram" */
  title: string;
  /** Right-aligned control, typically a BracketSelector */
  control?: React.ReactNode;
  /** Small sub line under the header, e.g. "hue · saturation" */
  sub?: string;
  /** Metrics caption under the content, e.g. "486 ms · 14 iterations · 84,211 samples" */
  caption?: string;
  /** Draw a dashed divider above (between stacked figures) */
  divider?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
}
export declare const Figure: React.FC<FigureProps>;
export default Figure;
