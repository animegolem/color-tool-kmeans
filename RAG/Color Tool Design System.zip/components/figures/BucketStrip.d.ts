import * as React from 'react';

export interface BucketTileProps {
  /** Thumbnail url; omitted = hatch placeholder */
  src?: string;
  /** Loaded/selected — brown border */
  active?: boolean;
  /** Render the dashed "+" add tile instead */
  add?: boolean;
  /** Corner chip, e.g. "▶ 02:01" or "frame @ 00:42" */
  chip?: string;
  onClick?: () => void;
  alt?: string;
  style?: React.CSSProperties;
}
export declare const BucketTile: React.FC<BucketTileProps>;

/** Recent-media strip docked at the page bottom; "view all (N) ↘" turns the page to the full bucket. */
export interface BucketStripProps {
  /** BucketTile children */
  children?: React.ReactNode;
  /** Total items — renders "view all (N) ↘" */
  total?: number;
  onViewAll?: () => void;
  style?: React.CSSProperties;
  className?: string;
}
export declare const BucketStrip: React.FC<BucketStripProps>;
export default BucketStrip;
