Video timeline on the page — mono time labels, ticked film track, brown playhead.

```jsx
const { Scrubber } = window.ColorToolDesignSystem_73584b;
<Scrubber time={t} duration={121} onScrub={setT} onSnapshot={snap} />
```

Sits directly beneath the stacked original/neutral previews on the Values spread.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
