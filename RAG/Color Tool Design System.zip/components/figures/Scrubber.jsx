import React, { useRef, useCallback } from 'react';

/*
  Scrubber — video timeline on the page (wireframe 5b): mono time labels,
  36px ticked film track, 4px brown playhead, hint line below.
*/
function fmt(s) {
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
}

export function Scrubber({ time = 0, duration = 121, onScrub, onSnapshot, hint = '◂ ▸ step frames · drag to scrub', style, className }) {
  const trackRef = useRef(null);
  const pct = duration === 0 ? 0 : (time / duration) * 100;

  const setFromEvent = useCallback(
    (e) => {
      const el = trackRef.current;
      if (!el || !onScrub) return;
      const rect = el.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      onScrub(Math.min(1, Math.max(0, x / rect.width)) * duration);
    },
    [duration, onScrub]
  );

  const onPointerDown = (e) => {
    setFromEvent(e);
    const move = (ev) => setFromEvent(ev);
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <div className={className} style={style}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, color: 'var(--text-60)' }}>{fmt(time)}</span>
        <div
          ref={trackRef}
          role="slider"
          aria-label="Timeline"
          aria-valuemin={0}
          aria-valuemax={duration}
          aria-valuenow={time}
          tabIndex={0}
          onPointerDown={onPointerDown}
          onKeyDown={(e) => {
            if (!onScrub) return;
            if (e.key === 'ArrowLeft') onScrub(Math.max(0, time - 1));
            else if (e.key === 'ArrowRight') onScrub(Math.min(duration, time + 1));
            else return;
            e.preventDefault();
          }}
          style={{
            flex: 1,
            height: 36,
            border: '1px solid var(--ink-line)',
            background: 'repeating-linear-gradient(90deg, #e0d8c4, #e0d8c4 32px, #d5ccb6 32px, #d5ccb6 34px)',
            position: 'relative',
            cursor: onScrub ? 'pointer' : 'default',
            touchAction: 'none',
            boxSizing: 'border-box',
            outlineColor: 'var(--tab-active)',
          }}
        >
          <div
            style={{
              position: 'absolute',
              left: `${pct}%`,
              top: -7,
              bottom: -7,
              width: 4,
              background: 'var(--tab-active)',
              pointerEvents: 'none',
            }}
          ></div>
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, color: 'var(--text-60)' }}>{fmt(duration)}</span>
      </div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          fontFamily: 'var(--font-mono)',
          fontSize: 12,
          color: 'var(--text-50)',
          marginTop: 7,
        }}
      >
        <span>{hint}</span>
        {onSnapshot && (
          <button
            type="button"
            onClick={onSnapshot}
            style={{
              font: 'inherit',
              color: 'inherit',
              background: 'none',
              border: 'none',
              padding: 0,
              cursor: 'pointer',
            }}
          >
            snapshot frame ✂
          </button>
        )}
      </div>
    </div>
  );
}

export default Scrubber;
