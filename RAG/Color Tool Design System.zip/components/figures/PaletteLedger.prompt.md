The live palette in export format — swatch + "[r:g:b] · N px · P%" rows, two columns, footer action link.

```jsx
const { PaletteLedger } = window.ColorToolDesignSystem_73584b;
<PaletteLedger
  entries={[{ color: '#3c3f38', label: '[60:63:56] · 594 px · 2.35%', onCopy }]}
  moreCount={31} onMore={openExports} />
```

Usually the content of `<Figure number="04" title="palette">`. LedgerRow is exported for single rows (e.g. histogram hover).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
