import React from 'react';

/*
  PaletteLedger — the live palette in export format (Code Change Notes #3, wireframe 4a):
  two-column grid of swatch + "[r:g:b] · N px · P%" rows, footer action link.
*/
export function LedgerRow({ color, label, onCopy, style }) {
  return (
    <div
      style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: onCopy ? 'pointer' : 'default', ...style }}
      onClick={onCopy}
      title={onCopy ? 'copy hex' : undefined}
    >
      <span style={{ width: 29, height: 18, borderRadius: 3, background: color, flexShrink: 0 }}></span>
      <span
        style={{
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-ledger)',
          color: 'var(--text-85)',
          whiteSpace: 'nowrap',
        }}
      >
        {label}
      </span>
    </div>
  );
}

export function PaletteLedger({ entries, moreCount = 0, actions = 'hex / csv / ase ▸', onMore, columns = 2, style, className }) {
  return (
    <div className={className} style={{ display: 'flex', flexDirection: 'column', ...style }}>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${columns}, 1fr)`,
          gap: '6px 32px',
          alignContent: 'start',
        }}
      >
        {entries.map((e, i) => (
          <LedgerRow key={i} color={e.color} label={e.label} onCopy={e.onCopy} />
        ))}
      </div>
      {(moreCount > 0 || actions) && (
        <button
          type="button"
          onClick={onMore}
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: 'var(--text-micro)',
            color: 'var(--tab-active)',
            background: 'none',
            border: 'none',
            padding: '9px 0 0',
            textAlign: 'left',
            cursor: onMore ? 'pointer' : 'default',
          }}
        >
          {moreCount > 0 ? `+ ${moreCount} more · ${actions}` : actions}
        </button>
      )}
    </div>
  );
}

export default PaletteLedger;
