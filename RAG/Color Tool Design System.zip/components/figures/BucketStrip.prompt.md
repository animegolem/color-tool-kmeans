Recent media docked at the page bottom — BUCKET label, 100×64 tiles, "view all (N) ↘" turns the page.

```jsx
const { BucketStrip, BucketTile } = window.ColorToolDesignSystem_73584b;
<BucketStrip total={7} onViewAll={turnToBucket}>
  <BucketTile src={thumb} active onClick={load} alt="study-014.png" />
  <BucketTile chip="▶ 02:01" onClick={load} alt="pan-shot.mp4" />
  <BucketTile add onClick={browse} />
</BucketStrip>
```

Strip shows recent 3–4; the full bucket is its own page (Code Change Notes #4).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
