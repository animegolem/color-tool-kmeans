import React from 'react';

/*
  Figure — a numbered figure on the page (wireframe 4a): mono 600 header
  "01 · cluster histogram", optional right-side control (BracketSelector),
  optional sub line and metrics caption. Content = children.
*/
export function Figure({ number, title, control, sub, caption, divider = false, children, style, className }) {
  return (
    <div
      className={className}
      style={{
        borderTop: divider ? '1px dashed var(--ink-35)' : 'none',
        paddingTop: divider ? 16 : 0,
        ...style,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 18 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 'var(--text-figure-title)' }}>
          {number} · {title}
        </span>
        {control}
      </div>
      {sub && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-micro)', color: 'var(--text-50)', marginTop: 2 }}>
          {sub}
        </div>
      )}
      {children}
      {caption && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-micro)', color: 'var(--text-50)', marginTop: 5 }}>
          {caption}
        </div>
      )}
    </div>
  );
}

export default Figure;
