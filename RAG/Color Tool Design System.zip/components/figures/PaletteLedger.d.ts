import * as React from 'react';

export interface LedgerEntry {
  /** Swatch color (css color) */
  color: string;
  /** Export-format row, e.g. "[60:63:56] · 594 px · 2.35%" */
  label: string;
  onCopy?: () => void;
}

/** The live palette in export format — swatch + [r:g:b] · count px · share% rows, footer action link. */
export interface PaletteLedgerProps {
  entries: LedgerEntry[];
  /** "+ N more" in the footer */
  moreCount?: number;
  /** Footer actions text (default "hex / csv / ase ▸") */
  actions?: string;
  onMore?: () => void;
  columns?: number;
  style?: React.CSSProperties;
  className?: string;
}
export declare const PaletteLedger: React.FC<PaletteLedgerProps>;
export default PaletteLedger;
