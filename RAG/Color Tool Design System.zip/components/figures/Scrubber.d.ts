import * as React from 'react';

/** Video timeline on the page — mono time labels, ticked film track, brown playhead, "snapshot frame ✂" action (Values spread). */
export interface ScrubberProps {
  /** Current time in seconds */
  time?: number;
  /** Duration in seconds */
  duration?: number;
  onScrub?: (time: number) => void;
  /** Shows "snapshot frame ✂" when provided */
  onSnapshot?: () => void;
  hint?: string;
  style?: React.CSSProperties;
  className?: string;
}
export declare const Scrubber: React.FC<ScrubberProps>;
export default Scrubber;
