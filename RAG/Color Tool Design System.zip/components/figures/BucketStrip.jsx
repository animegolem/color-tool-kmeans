import React from 'react';

/*
  BucketStrip — recent media docked at the page bottom (Code Change Notes #4, wireframes 3a/4a):
  BUCKET microlabel · 100×64 tiles (active = brown border, video = timestamp chip,
  add = dashed +) · "view all (N) ↘" turns the page.
*/
export function BucketTile({ src, active = false, add = false, chip, onClick, alt = '', style }) {
  if (add) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-label="Add media"
        style={{
          width: 100,
          height: 64,
          border: '2px dashed var(--ink-40)',
          background: 'transparent',
          display: 'grid',
          placeItems: 'center',
          color: 'var(--tab-active)',
          fontSize: 23,
          padding: 0,
          cursor: 'pointer',
          boxSizing: 'border-box',
          ...style,
        }}
      >
        +
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={alt}
      style={{
        width: 100,
        height: 64,
        border: active ? '3px solid var(--tab-active)' : '2px solid var(--ink-40)',
        background: src ? `url(${src}) center / cover` : 'var(--hatch)',
        position: 'relative',
        padding: 0,
        cursor: onClick ? 'pointer' : 'default',
        boxSizing: 'border-box',
        ...style,
      }}
    >
      {chip && (
        <span
          style={{
            position: 'absolute',
            left: 4,
            bottom: 4,
            fontFamily: 'var(--font-mono)',
            fontSize: 11,
            background: 'rgba(38,38,38,.75)',
            color: 'var(--tab-text)',
            padding: '0 5px',
            lineHeight: 1.5,
          }}
        >
          {chip}
        </span>
      )}
    </button>
  );
}

export function BucketStrip({ children, total, onViewAll, style, className }) {
  return (
    <div
      className={className}
      style={{
        borderTop: '1px solid var(--ink-30)',
        paddingTop: 14,
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        ...style,
      }}
    >
      <span
        style={{
          fontFamily: 'var(--font-mono)',
          fontWeight: 600,
          fontSize: 12,
          color: 'var(--text-55)',
          letterSpacing: '0.06em',
        }}
      >
        BUCKET
      </span>
      {children}
      {total !== undefined && (
        <button
          type="button"
          onClick={onViewAll}
          style={{
            marginLeft: 'auto',
            fontFamily: 'var(--font-mono)',
            fontSize: 15,
            color: 'var(--tab-active)',
            background: 'none',
            border: 'none',
            padding: 0,
            cursor: onViewAll ? 'pointer' : 'default',
          }}
        >
          view all ({total}) ↘
        </button>
      )}
    </div>
  );
}

export default BucketStrip;
