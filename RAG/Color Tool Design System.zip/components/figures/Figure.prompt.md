A numbered figure on the page — mono 600 header "01 · cluster histogram", right control slot, metrics caption.

```jsx
const { Figure, BracketSelector } = window.ColorToolDesignSystem_73584b;
<Figure number="01" title="cluster histogram"
        control={<BracketSelector options={['frequency','hue','lightness']} value={sort} onChange={setSort} />}
        caption="486 ms · 14 iterations · 84,211 samples">
  {/* the chart, drawn in ink on the paper */}
</Figure>
```

divider draws the dashed rule between stacked figures. Titles are lowercase; numbers zero-padded.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
