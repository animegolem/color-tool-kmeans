import React from 'react';

/*
  ZoomOverlay — click any figure to lift it to the light (wireframes 7a/7b):
  dark scrim over the app, frame ≈70% of the window, centered.
  ground="flat" = cream frame (the page lifts); ground="pinned" = white card lifts.
  Chrome: mono title, fit ⤢, ✕, hint line, % readout.
*/
export function ZoomOverlay({
  open = true,
  title,
  meta,
  ground = 'flat',
  zoom = 100,
  hint = 'scroll to zoom · drag to pan · double-click to fit · esc or click outside to close',
  onClose,
  onFit,
  children,
  style,
  className,
}) {
  if (!open) return null;
  return (
    <div
      className={className}
      style={{ position: 'absolute', inset: 0, zIndex: 10, ...style }}
      onClick={onClose}
    >
      <div style={{ position: 'absolute', inset: 0, background: 'var(--zoom-scrim)' }}></div>
      <div
        role="dialog"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        style={{
          position: 'absolute',
          left: '50%',
          top: '50%',
          transform: 'translate(-50%,-50%)',
          width: '70%',
          height: '72%',
          background: ground === 'pinned' ? 'var(--card)' : 'var(--zoom-frame-bg)',
          border: '1px solid var(--zoom-frame-border)',
          borderRadius: 18,
          boxShadow: 'var(--zoom-shadow)',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            position: 'absolute',
            left: 32,
            top: 25,
            fontFamily: 'var(--font-mono)',
            fontWeight: 600,
            fontSize: 18,
            color: 'rgba(38,38,38,.75)',
          }}
        >
          {title}
          {meta && <span style={{ fontWeight: 400, color: 'var(--text-50)' }}> · {meta}</span>}
        </div>
        <div style={{ position: 'absolute', right: 22, top: 18, display: 'flex', gap: 14, alignItems: 'center' }}>
          <button
            type="button"
            onClick={onFit}
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 15,
              color: 'var(--text-55)',
              background: 'none',
              border: 'none',
              padding: 0,
              cursor: onFit ? 'pointer' : 'default',
            }}
          >
            fit ⤢
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            style={{
              width: 34,
              height: 34,
              border: '1px solid rgba(43,41,38,.5)',
              borderRadius: 7,
              display: 'grid',
              placeItems: 'center',
              fontSize: 18,
              lineHeight: 1,
              background: 'none',
              padding: 0,
              cursor: 'pointer',
              color: 'inherit',
            }}
          >
            ✕
          </button>
        </div>
        <div style={{ position: 'absolute', inset: '64px 32px 58px', display: 'grid', placeItems: 'center' }}>{children}</div>
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 18,
            textAlign: 'center',
            fontFamily: 'var(--font-mono)',
            fontSize: 13,
            color: 'var(--text-50)',
          }}
        >
          {hint}
        </div>
        <div
          style={{
            position: 'absolute',
            right: 27,
            bottom: 18,
            fontFamily: 'var(--font-mono)',
            fontSize: 15,
            color: 'var(--text-60)',
          }}
        >
          {zoom}%
        </div>
      </div>
    </div>
  );
}

export default ZoomOverlay;
