import * as React from 'react';

/**
 * The lifted zoom frame — dark scrim, frame ≈70% of window, mono chrome (fit ⤢, ✕, hint, % readout).
 * ground follows the chart-ground setting: 'flat' = cream page lifts to the light, 'pinned' = white card lifts off the page.
 */
export interface ZoomOverlayProps {
  open?: boolean;
  /** Mono title, e.g. "02 · polar" */
  title?: string;
  /** Quiet meta after the title, e.g. "oklch [okhsv] hsv · hue · saturation" */
  meta?: string;
  ground?: 'flat' | 'pinned';
  /** Zoom % readout (default 100) */
  zoom?: number;
  hint?: string;
  onClose?: () => void;
  onFit?: () => void;
  /** The zoomed figure content */
  children?: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
}
export declare const ZoomOverlay: React.FC<ZoomOverlayProps>;
export default ZoomOverlay;
