Click any figure to lift it to the light — dark scrim, frame ≈70% of the window, mono chrome (fit ⤢, ✕, hint, %).

```jsx
const { ZoomOverlay } = window.ColorToolDesignSystem_73584b;
<ZoomOverlay open={!!zoomed} title="02 · polar" meta="oklch [okhsv] hsv · hue · saturation"
             ground={chartGround} zoom={pct} onClose={close} onFit={fit}>
  {bigChart}
</ZoomOverlay>
```

ground='flat' = cream page lifts; 'pinned' = white card lifts (leave a PinHole behind on the page). Position:absolute over the app root (parent position:relative).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
