import React from 'react';

/*
  BracketSelector — the notebook's segmented control (Code Change Notes #7):
  inline mono text where the active option wears square brackets:
  "[frequency] hue lightness". Same state, same handlers as the old pills.
*/
export function BracketSelector({ options, value, onChange, style, className }) {
  return (
    <span
      className={className}
      style={{
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-bracket)',
        color: 'var(--text-60)',
        display: 'inline-flex',
        gap: '0.55em',
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {options.map((o) => {
        const isActive = o === value;
        return (
          <button
            key={o}
            type="button"
            onClick={onChange ? () => onChange(o) : undefined}
            style={{
              font: 'inherit',
              color: isActive ? 'var(--ink)' : 'inherit',
              fontWeight: isActive ? 600 : 400,
              background: 'none',
              border: 'none',
              padding: 0,
              cursor: onChange ? 'pointer' : 'default',
            }}
          >
            {isActive ? `[${o}]` : o}
          </button>
        );
      })}
    </span>
  );
}

export default BracketSelector;
