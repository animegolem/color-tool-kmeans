Notebook parameter row — sans label, flat paper track, stock thumb, mono value column.

```jsx
const { PaperSlider } = window.ColorToolDesignSystem_73584b;
<PaperSlider label="Number of clusters" value={n} min={1} max={400} onChange={setN} />
<PaperSlider label="Merge threshold ΔE" value={dE} max={0.1} step={0.01} format={(v) => v.toFixed(2)} onChange={setDE} />
```

labelWidth (270) and valueWidth (59) align stacked rows into columns. Controlled or uncontrolled.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
