The notebook's segmented control — inline mono text, active option wears square brackets: "[frequency] hue lightness".

```jsx
const { BracketSelector } = window.ColorToolDesignSystem_73584b;
<BracketSelector options={['frequency','hue','lightness']} value={sort} onChange={setSort} />
```

Typically the `control` slot of a Figure header. Replaces pill toggle-groups 1:1 (Code Change Notes #7).

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
