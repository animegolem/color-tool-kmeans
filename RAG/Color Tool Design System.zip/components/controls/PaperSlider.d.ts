import * as React from 'react';

/**
 * Notebook parameter slider — flat paper track, stock thumb, mono value column (wireframe 4a).
 */
export interface PaperSliderProps {
  label: string;
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
  /** Format the value column, e.g. (v) => v.toFixed(2) */
  format?: (value: number) => string;
  onChange?: (value: number) => void;
  /** Label column width (default 270) */
  labelWidth?: number;
  /** Value column width (default 59) */
  valueWidth?: number;
  disabled?: boolean;
  style?: React.CSSProperties;
  className?: string;
}
export declare const PaperSlider: React.FC<PaperSliderProps>;
export default PaperSlider;
