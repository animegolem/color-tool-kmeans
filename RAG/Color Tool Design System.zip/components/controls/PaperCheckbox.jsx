import React, { useState } from 'react';

/*
  PaperCheckbox — square ink checkbox (wireframe 4a): 15px box, 2px ink border;
  checked = filled ink with a cream ✓.
*/
export function PaperCheckbox({ label, checked: checkedProp, defaultChecked = false, onChange, disabled = false, style, className }) {
  const [internal, setInternal] = useState(defaultChecked);
  const checked = checkedProp !== undefined ? checkedProp : internal;
  const toggle = () => {
    if (disabled) return;
    const next = !checked;
    if (checkedProp === undefined) setInternal(next);
    if (onChange) onChange(next);
  };
  return (
    <button
      type="button"
      className={className}
      role="checkbox"
      aria-checked={checked}
      onClick={toggle}
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 9,
        fontSize: 'var(--text-label)',
        fontFamily: 'inherit',
        background: 'none',
        border: 'none',
        padding: 0,
        color: 'inherit',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        ...style,
      }}
    >
      <span
        style={{
          width: 15,
          height: 15,
          border: '2px solid var(--ink-line)',
          background: checked ? 'var(--ink-line)' : 'transparent',
          display: 'grid',
          placeItems: 'center',
          color: 'var(--paper)',
          fontSize: 13,
          lineHeight: 1,
          boxSizing: 'border-box',
          flexShrink: 0,
        }}
      >
        {checked ? '✓' : ''}
      </span>
      {label}
    </button>
  );
}

export default PaperCheckbox;
