import React from 'react';

/*
  StampButton — composite/export action as a rubber stamp (wireframe 5c):
  brown 3px border, mono 600 uppercase, slight rotation, transparent fill.
*/
export function StampButton({ children, rotate = -0.6, onClick, disabled = false, style, className }) {
  return (
    <button
      type="button"
      className={className}
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'block',
        width: '100%',
        border: '3px solid var(--tab-active)',
        color: 'var(--tab-active)',
        background: 'transparent',
        fontFamily: 'var(--font-mono)',
        fontWeight: 600,
        fontSize: 15,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        textAlign: 'center',
        padding: '11px 0',
        transform: `rotate(${rotate}deg)`,
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'background 120ms var(--ease-out), color 120ms var(--ease-out)',
        ...style,
      }}
      onMouseEnter={(e) => {
        if (!disabled) {
          e.currentTarget.style.background = 'var(--tab-active)';
          e.currentTarget.style.color = 'var(--tab-text)';
        }
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = 'transparent';
        e.currentTarget.style.color = 'var(--tab-active)';
      }}
    >
      {children}
    </button>
  );
}

export default StampButton;
