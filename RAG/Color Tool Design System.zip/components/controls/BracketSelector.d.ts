import * as React from 'react';

/** Inline mono segmented control — active option wears square brackets: "[frequency] hue lightness". */
export interface BracketSelectorProps {
  options: string[];
  value: string;
  onChange?: (option: string) => void;
  style?: React.CSSProperties;
  className?: string;
}
export declare const BracketSelector: React.FC<BracketSelectorProps>;
export default BracketSelector;
