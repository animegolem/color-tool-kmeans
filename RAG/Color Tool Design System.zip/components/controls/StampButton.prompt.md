Composite/export action as a rubber stamp — brown 3px border, mono uppercase, slight rotation.

```jsx
const { StampButton } = window.ColorToolDesignSystem_73584b;
<StampButton onClick={run}>Export Colors Composite</StampButton>
<StampButton rotate={0.5} disabled>Export Batch Composite</StampButton>
```

Alternate rotate between stamps (−0.6 / +0.5). Fills its container width.

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
