Square ink checkbox — 15px box, filled ink + cream ✓ when on.

```jsx
const { PaperCheckbox } = window.ColorToolDesignSystem_73584b;
<PaperCheckbox label="Cluster outline" checked={on} onChange={setOn} />
```

Intentional addition — notebook-idiom component from design-docs/, not a .fig kit family.
