import React, { useRef, useState, useCallback } from 'react';

/*
  PaperSlider — notebook parameter row (wireframe 4a):
  Fira Sans label · flat track #ddd5c2 with inset shadow · paper-stock thumb ·
  mono 600 value column. Full size ×2.25: track 13px, thumb 25px.
*/
export function PaperSlider({
  label,
  value: valueProp,
  defaultValue = 0,
  min = 0,
  max = 100,
  step = 1,
  format,
  onChange,
  labelWidth = 270,
  valueWidth = 59,
  disabled = false,
  style,
  className,
}) {
  const [internal, setInternal] = useState(defaultValue);
  const trackRef = useRef(null);
  const value = valueProp !== undefined ? valueProp : internal;

  const setFromEvent = useCallback(
    (e) => {
      const el = trackRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      const raw = min + Math.min(1, Math.max(0, x / rect.width)) * (max - min);
      const next = Math.round(raw / step) * step;
      const clamped = Math.min(max, Math.max(min, next));
      if (valueProp === undefined) setInternal(clamped);
      if (onChange) onChange(clamped);
    },
    [min, max, step, onChange, valueProp]
  );

  const onPointerDown = (e) => {
    if (disabled) return;
    setFromEvent(e);
    const move = (ev) => setFromEvent(ev);
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const pct = max === min ? 0 : ((value - min) / (max - min)) * 100;
  const display = format ? format(value) : String(value);

  return (
    <div
      className={className}
      style={{ display: 'flex', alignItems: 'center', gap: 18, opacity: disabled ? 0.45 : 1, ...style }}
    >
      <span style={{ fontSize: 'var(--text-label)', width: labelWidth, flexShrink: 0 }}>{label}</span>
      <span
        ref={trackRef}
        role="slider"
        tabIndex={disabled ? -1 : 0}
        aria-label={label}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={value}
        onPointerDown={onPointerDown}
        onKeyDown={(e) => {
          if (disabled) return;
          let d = 0;
          if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') d = -step;
          else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') d = step;
          else return;
          e.preventDefault();
          const next = Math.min(max, Math.max(min, value + d));
          if (valueProp === undefined) setInternal(next);
          if (onChange) onChange(next);
        }}
        style={{
          flex: 1,
          height: 13,
          background: 'var(--slider-track)',
          borderRadius: 99,
          boxShadow: 'var(--slider-track-inset)',
          position: 'relative',
          cursor: disabled ? 'default' : 'pointer',
          touchAction: 'none',
          outlineColor: 'var(--tab-active)',
        }}
      >
        <span
          style={{
            position: 'absolute',
            left: `calc(${pct}% - 12px)`,
            top: -6,
            width: 25,
            height: 25,
            borderRadius: '50%',
            background: 'var(--paper-thumb)',
            border: '2px solid var(--ink-40)',
            boxShadow: 'var(--slider-thumb-shadow)',
            boxSizing: 'border-box',
            pointerEvents: 'none',
          }}
        ></span>
      </span>
      <b
        style={{
          fontFamily: 'var(--font-mono)',
          fontWeight: 600,
          fontSize: 'var(--text-figure-title)',
          width: valueWidth,
          textAlign: 'right',
          flexShrink: 0,
        }}
      >
        {display}
      </b>
    </div>
  );
}

export default PaperSlider;
