import * as React from 'react';

/** Composite/export action as a rubber stamp — brown border, mono uppercase, slight rotation (wireframe 5c). */
export interface StampButtonProps {
  children?: React.ReactNode;
  /** Rotation in degrees (default -0.6; alternate stamps use +0.5) */
  rotate?: number;
  onClick?: () => void;
  disabled?: boolean;
  style?: React.CSSProperties;
  className?: string;
}
export declare const StampButton: React.FC<StampButtonProps>;
export default StampButton;
