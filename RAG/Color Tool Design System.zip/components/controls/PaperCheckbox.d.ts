import * as React from 'react';

/** Square ink checkbox — filled ink box with cream check when on (wireframe 4a). */
export interface PaperCheckboxProps {
  label: string;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  style?: React.CSSProperties;
  className?: string;
}
export declare const PaperCheckbox: React.FC<PaperCheckboxProps>;
export default PaperCheckbox;
