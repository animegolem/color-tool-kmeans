# Color Tool — Notebook Design System

**Perceptual color & tonality analysis for artists.** Color Tool is a local-first desktop app (Tauri 2 + Svelte 5 + Rust): k-means clustering in OKLab/OKLch, polar hue×chroma charts, cluster histograms, value/notan studies, video frame analysis, batch palettes, rich exports.

This design system captures the **notebook redesign** — the target the UI layer is being rebuilt toward. The app as shipped was effectively the wireframe; the redesign returns to the original Figma vision (a cream sheet on a desk) and develops it into a **lab-notebook idiom**: the app is a two-page spread of paper on a dark desk, navigation is edge tabs riding the page border, figures are numbered ink drawings on ruled paper, the palette is a ledger in export format, errors are paper slips, and the media bucket is a page you turn to.

## Sources (in priority order)

1. **`design-docs/UI Shell Wireframes.dc.html`** — THE source of truth. Numbered exploration turns; the landed direction is **4a** (Colors spread, refined) + **6a** (pinned-cards ground) + **5a–5e** (ingestion, Values, Exports, Batch, compact reflow) + **7a–7c** (zoom overlay, reflow storyboard) + **3a/3b** (bucket strip → bucket page). Drawn at ~0.4× of a 16″ MBP; all sizes here are scaled ×2.25 to full size.
2. **`design-docs/Code Change Notes.md`** — 12 decided code changes the redesign implies (remove snap toggle, ledger surfaces live, bucket restructure, edge tabs replace the sidebar, bracket selectors, metrics under figures, spread→column reflow, stacked Values previews, chart-ground display setting, zoom overlay chrome).
3. **`design-docs/reflow-studies.jsx` / `Reflow Motion Studies.dc.html`** — motion studies for the spread→single-column reflow (A crossfade+re-stack recommended for resize; B page fold saved for deliberate page turns; C slide-under).
4. Codebase `color-tool-kmeans/` (attached, read-only) — feature set, copy, and data shapes; **not** visual truth.
5. `Colors Tool.fig` (attached) — the original inspiration (sheet-on-desk, ribbon tabs, "canonical black = 262626"). Superseded by the design docs for componentry.

## Content fundamentals

- **Mono lowercase is the app's handwriting.** Figure titles are numbered and lowercase: `01 · cluster histogram`, `02 · polar`, `03 · hue × lightness`, `04 · palette`. Page titles are the exception: mono UPPERCASE — `COLORS · study-014.png`, `MEDIA BUCKET · 7 items`.
- **The interpunct (·) joins everything**: titles to filenames, metrics (`486 ms · 14 iterations · 84,211 samples`), format lists (`png · jpeg · webp · bmp · gif · tiff · mp4`), hints (`◂ ▸ step frames · drag to scrub`).
- **Ledger rows are export format**: `[60:63:56] · 594 px · 2.35%` (r:g:b in brackets, count, share).
- **Errors are calm, factual, lowercase**: `unsupported format — sketch.heic`, `analysis failed — worker timeout`, with a quiet underlined action (`retry`, `browse files`). Never toasts — slips of paper on the desk.
- **Sans is for sentences** (parameter labels: "Number of clusters", "Speed ← → Quality"); mono for everything structural. No emoji; glyphs are unicode: ✕ ✂ ▶ ⤓ ↓ ⤢ ◂ ▸ ↘ ✗ ✓ +.

## Visual foundations

All tokens in `tokens/notebook.css` (full-size; wireframe 0.4× sources noted inline).

- **The desk**: everything sits on `--desk #6e6764`. The spread (`--paper #F5EFE1` left, `--paper-right #F8F2E5` right) carries a heavy drop shadow (`--sheet-shadow`), 1px `--ink-line #2b2926` borders, and a dark `--spine` gutter (stitched holes in the pinned ground).
- **Ruled paper**: faint brown rules every `--rule-pitch 50px` (`--rule-left/.09`, `--rule-right/.07`) — helpers `.nb-ruled-left/right`.
- **Ink, not chrome**: figures draw directly on the paper with 1px `--ink-line` axes; hierarchy comes from ink alphas (`--ink-55/40/35/30/25`, text `--text-85/60/55/50`). No cards in the flat ground; the optional "pinned cards" ground puts figures on white stock with colored pins (`--pin-red/-blue/-green/-brown`).
- **Warm leather browns**: `--tab-active #7a5343` (active tab, links, stamps, playhead, drop-target dash), `--tab-inactive #8d6a5a`. Links are mono, underlined, brown.
- **Controls are paper**: slider = flat `--slider-track #ddd5c2` capsule with inset shadow + 25px `--paper-thumb` disc; checkbox = 15px square ink box, filled when checked; segmented control = **bracket selector** text (`[frequency] hue lightness`); big actions = **rubber stamps** (brown border, mono uppercase, slightly rotated).
- **Placeholders are hatched** (`--hatch` diagonal stripes) with mono `--hatch-text` captions.
- **Photos are taped** (`--tape`, ±40° pieces, −0.8° rotation); tiles/pages that turn get a `--corner-fold` folded corner.
- **Errors**: `--error #8a1f2b` on paper slips with slight rotations.
- **Zoom**: dark `--zoom-scrim`, frame ≈70% of window (`--zoom-frame-bg` cream or white card per ground), radius 18, `--zoom-shadow`; pinned cards leave a pin hole + ghost outline behind.
- **Motion**: resize reflow = crossfade + re-stack `--reflow-fade 120ms` (cheap, interruptible); deliberate page turns = spine-hinge fold `--fold-duration 250ms` ease-out; zoom = the card lift/return. Below ~1100px the spread folds to one scrolling column (image → params → figures → palette), tabs stay in the border.

## Iconography

No icon set. Glyphs are unicode characters in Fira Code (✕ close, ✂ snapshot, ▶ video, ⤓ drop, ↓ save, ⤢ fit, ◂ ▸ step, ↘ turn page, ✗ error, ✓ check, + add). The .fig's Feather-style icon families are intentionally not part of the notebook idiom.

## Logo

No logo or wordmark is defined anywhere in the sources. Render "Color Tool" (or the mono page-title style) in type; do not invent a mark.

## Typography

- **Fira Code** (mono, 400/500/600 via 500 file/700) — structural voice: page titles (25px, 600, ls .06em), figure titles (17px, 600), bracket selectors (14px), ledger rows (12px), microlabels/captions (12px, often letter-spaced uppercase).
- **Fira Sans** (400/500/700) — sentence voice: parameter labels (18px), checkbox labels, empty-state lines.
- Vendored in `assets/fonts/`, declared in `tokens/fonts.css`. Never CDN.

## Components

All built from the wireframes; **all names are intentional additions** — the notebook vocabulary comes from `design-docs/` (which supersedes the attached .fig kit; its `Check`/`Chevron up`/`Copy`/`Download`/`File text`/`Image`/`Loader`/`Sun`/`X`/`X circle`/`X square`/`Slider - Default`/`Tooltip`/`Plain Tooltip` families are intentionally skipped — not part of the notebook idiom).

- `components/navigation/` — **EdgeTabs** (vertical tabs riding the page border), **FoldedCorner** (turn-the-page affordance), **Spine** (spread gutter, stitched variant)
- `components/controls/` — **PaperSlider** (parameter row), **PaperCheckbox** (square ink box), **BracketSelector** (`[active] other` segmented text), **StampButton** (rubber-stamp action)
- `components/figures/` — **Figure** (numbered header + control slot + caption), **PaletteLedger** + **LedgerRow** (export-format palette), **BucketStrip** + **BucketTile** (recent media dock), **Scrubber** (video timeline)
- `components/paper/` — **TapedPhoto** (loaded image), **PinnedCard** + **PinHole** (pinned-cards ground), **ErrorSlip** (errors on the desk)
- `components/overlay/` — **ZoomOverlay** (lifted zoom frame)

## Intentional additions

All 18 components are intentional additions — the notebook vocabulary is defined by `design-docs/` (the redesign), not the attached .fig kit: `EdgeTabs`, `FoldedCorner`, `Spine`, `PaperSlider`, `PaperCheckbox`, `BracketSelector`, `StampButton`, `Figure`, `PaletteLedger`, `LedgerRow`, `BucketStrip`, `BucketTile`, `Scrubber`, `TapedPhoto`, `PinnedCard`, `PinHole`, `ErrorSlip`, `ZoomOverlay`.

## UI kit

- `ui_kits/notebook/` — full-size interactive spread on the desk: Colors (4a), Values (5b), Exports (5c), Batch (5d, approximate), the bucket page (3b) via the folded corner, zoom overlay, flat/pinned chart-ground toggle.

## Index

- `styles.css` → `tokens/fonts.css` + `tokens/notebook.css` + `tokens/base.css`
- `components/<group>/` — see above (each with `.d.ts`, `.prompt.md`, card HTML)
- `guidelines/` — foundation specimen cards
- `ui_kits/notebook/` — the app in the notebook idiom
- `design-docs/` — the wireframes, code-change notes, motion studies, reference screenshots (`refs/`)
- `assets/fonts/`, `assets/sample/` (study image from the .fig)
- `SKILL.md` — agent skill entry point

## Caveats

- Wireframes are ~0.4×; token sizes are ×2.25 and rounded — treat them as strong defaults, not measured finals.
- Batch spread (5d) is marked "approx — to be checked against BatchView before committing" in the wireframes; same caveat applies here.
- Undecided in the docs (watch list): params always visible on the left page, page-turn animation for view changes, Settings placement (likely a corner affordance).
