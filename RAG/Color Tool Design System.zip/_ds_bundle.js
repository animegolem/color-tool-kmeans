/* @ds-bundle: {"format":4,"namespace":"ColorToolDesignSystem_73584b","components":[{"name":"BracketSelector","sourcePath":"components/controls/BracketSelector.jsx"},{"name":"PaperCheckbox","sourcePath":"components/controls/PaperCheckbox.jsx"},{"name":"PaperSlider","sourcePath":"components/controls/PaperSlider.jsx"},{"name":"StampButton","sourcePath":"components/controls/StampButton.jsx"},{"name":"BucketTile","sourcePath":"components/figures/BucketStrip.jsx"},{"name":"BucketStrip","sourcePath":"components/figures/BucketStrip.jsx"},{"name":"Figure","sourcePath":"components/figures/Figure.jsx"},{"name":"LedgerRow","sourcePath":"components/figures/PaletteLedger.jsx"},{"name":"PaletteLedger","sourcePath":"components/figures/PaletteLedger.jsx"},{"name":"Scrubber","sourcePath":"components/figures/Scrubber.jsx"},{"name":"EdgeTabs","sourcePath":"components/navigation/EdgeTabs.jsx"},{"name":"FoldedCorner","sourcePath":"components/navigation/FoldedCorner.jsx"},{"name":"Spine","sourcePath":"components/navigation/Spine.jsx"},{"name":"ZoomOverlay","sourcePath":"components/overlay/ZoomOverlay.jsx"},{"name":"ErrorSlip","sourcePath":"components/paper/ErrorSlip.jsx"},{"name":"PinnedCard","sourcePath":"components/paper/PinnedCard.jsx"},{"name":"PinHole","sourcePath":"components/paper/PinnedCard.jsx"},{"name":"TapedPhoto","sourcePath":"components/paper/TapedPhoto.jsx"}],"sourceHashes":{"components/controls/BracketSelector.jsx":"6fdc4745cac5","components/controls/PaperCheckbox.jsx":"ab13920ed7a2","components/controls/PaperSlider.jsx":"918f3d08c244","components/controls/StampButton.jsx":"df7310182b6d","components/figures/BucketStrip.jsx":"6ac1c79c7c2d","components/figures/Figure.jsx":"d50f4e3d3a9c","components/figures/PaletteLedger.jsx":"92a9db649919","components/figures/Scrubber.jsx":"f4a8727ea86a","components/navigation/EdgeTabs.jsx":"0033907e727c","components/navigation/FoldedCorner.jsx":"31021f4e2220","components/navigation/Spine.jsx":"4521518f89d6","components/overlay/ZoomOverlay.jsx":"f19b88c6c475","components/paper/ErrorSlip.jsx":"74b5c67a2fda","components/paper/PinnedCard.jsx":"927f31cf3e86","components/paper/TapedPhoto.jsx":"386859c452ce","design-docs/animations.jsx":"a8d2a696abaa","design-docs/reflow-studies.jsx":"b99d3e75bc93","ui_kits/notebook/ColorsSpread.jsx":"ec10d384909e","ui_kits/notebook/NotebookApp.jsx":"3e760f3358d8","ui_kits/notebook/Views.jsx":"d49987636679","ui_kits/notebook/kit-data.js":"b5021c7ed3ac","uploads/UI review and feedback/animations.jsx":"a8d2a696abaa","uploads/UI review and feedback/reflow-studies.jsx":"b99d3e75bc93"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ColorToolDesignSystem_73584b = window.ColorToolDesignSystem_73584b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/controls/BracketSelector.jsx
try { (() => {
/*
  BracketSelector — the notebook's segmented control (Code Change Notes #7):
  inline mono text where the active option wears square brackets:
  "[frequency] hue lightness". Same state, same handlers as the old pills.
*/
function BracketSelector({
  options,
  value,
  onChange,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-bracket)',
      color: 'var(--text-60)',
      display: 'inline-flex',
      gap: '0.55em',
      whiteSpace: 'nowrap',
      ...style
    }
  }, options.map(o => {
    const isActive = o === value;
    return /*#__PURE__*/React.createElement("button", {
      key: o,
      type: "button",
      onClick: onChange ? () => onChange(o) : undefined,
      style: {
        font: 'inherit',
        color: isActive ? 'var(--ink)' : 'inherit',
        fontWeight: isActive ? 600 : 400,
        background: 'none',
        border: 'none',
        padding: 0,
        cursor: onChange ? 'pointer' : 'default'
      }
    }, isActive ? `[${o}]` : o);
  }));
}
Object.assign(__ds_scope, { BracketSelector, __ds_default_components_controls_BracketSelector_137xtp6: BracketSelector });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/BracketSelector.jsx", error: String((e && e.message) || e) }); }

// components/controls/PaperCheckbox.jsx
try { (() => {
const {
  useState
} = React;
/*
  PaperCheckbox — square ink checkbox (wireframe 4a): 15px box, 2px ink border;
  checked = filled ink with a cream ✓.
*/
function PaperCheckbox({
  label,
  checked: checkedProp,
  defaultChecked = false,
  onChange,
  disabled = false,
  style,
  className
}) {
  const [internal, setInternal] = useState(defaultChecked);
  const checked = checkedProp !== undefined ? checkedProp : internal;
  const toggle = () => {
    if (disabled) return;
    const next = !checked;
    if (checkedProp === undefined) setInternal(next);
    if (onChange) onChange(next);
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: className,
    role: "checkbox",
    "aria-checked": checked,
    onClick: toggle,
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 9,
      fontSize: 'var(--text-label)',
      fontFamily: 'inherit',
      background: 'none',
      border: 'none',
      padding: 0,
      color: 'inherit',
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 15,
      height: 15,
      border: '2px solid var(--ink-line)',
      background: checked ? 'var(--ink-line)' : 'transparent',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--paper)',
      fontSize: 13,
      lineHeight: 1,
      boxSizing: 'border-box',
      flexShrink: 0
    }
  }, checked ? '✓' : ''), label);
}
Object.assign(__ds_scope, { PaperCheckbox, __ds_default_components_controls_PaperCheckbox_jga6n0: PaperCheckbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/PaperCheckbox.jsx", error: String((e && e.message) || e) }); }

// components/controls/PaperSlider.jsx
try { (() => {
const {
  useRef,
  useState,
  useCallback
} = React;
/*
  PaperSlider — notebook parameter row (wireframe 4a):
  Fira Sans label · flat track #ddd5c2 with inset shadow · paper-stock thumb ·
  mono 600 value column. Full size ×2.25: track 13px, thumb 25px.
*/
function PaperSlider({
  label,
  value: valueProp,
  defaultValue = 0,
  min = 0,
  max = 100,
  step = 1,
  format,
  onChange,
  labelWidth = 270,
  valueWidth = 59,
  disabled = false,
  style,
  className
}) {
  const [internal, setInternal] = useState(defaultValue);
  const trackRef = useRef(null);
  const value = valueProp !== undefined ? valueProp : internal;
  const setFromEvent = useCallback(e => {
    const el = trackRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const raw = min + Math.min(1, Math.max(0, x / rect.width)) * (max - min);
    const next = Math.round(raw / step) * step;
    const clamped = Math.min(max, Math.max(min, next));
    if (valueProp === undefined) setInternal(clamped);
    if (onChange) onChange(clamped);
  }, [min, max, step, onChange, valueProp]);
  const onPointerDown = e => {
    if (disabled) return;
    setFromEvent(e);
    const move = ev => setFromEvent(ev);
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  const pct = max === min ? 0 : (value - min) / (max - min) * 100;
  const display = format ? format(value) : String(value);
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 18,
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-label)',
      width: labelWidth,
      flexShrink: 0
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    ref: trackRef,
    role: "slider",
    tabIndex: disabled ? -1 : 0,
    "aria-label": label,
    "aria-valuemin": min,
    "aria-valuemax": max,
    "aria-valuenow": value,
    onPointerDown: onPointerDown,
    onKeyDown: e => {
      if (disabled) return;
      let d = 0;
      if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') d = -step;else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') d = step;else return;
      e.preventDefault();
      const next = Math.min(max, Math.max(min, value + d));
      if (valueProp === undefined) setInternal(next);
      if (onChange) onChange(next);
    },
    style: {
      flex: 1,
      height: 13,
      background: 'var(--slider-track)',
      borderRadius: 99,
      boxShadow: 'var(--slider-track-inset)',
      position: 'relative',
      cursor: disabled ? 'default' : 'pointer',
      touchAction: 'none',
      outlineColor: 'var(--tab-active)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: `calc(${pct}% - 12px)`,
      top: -6,
      width: 25,
      height: 25,
      borderRadius: '50%',
      background: 'var(--paper-thumb)',
      border: '2px solid var(--ink-40)',
      boxShadow: 'var(--slider-thumb-shadow)',
      boxSizing: 'border-box',
      pointerEvents: 'none'
    }
  })), /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 'var(--text-figure-title)',
      width: valueWidth,
      textAlign: 'right',
      flexShrink: 0
    }
  }, display));
}
Object.assign(__ds_scope, { PaperSlider, __ds_default_components_controls_PaperSlider_ia4raw: PaperSlider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/PaperSlider.jsx", error: String((e && e.message) || e) }); }

// components/controls/StampButton.jsx
try { (() => {
/*
  StampButton — composite/export action as a rubber stamp (wireframe 5c):
  brown 3px border, mono 600 uppercase, slight rotation, transparent fill.
*/
function StampButton({
  children,
  rotate = -0.6,
  onClick,
  disabled = false,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: className,
    onClick: onClick,
    disabled: disabled,
    style: {
      display: 'block',
      width: '100%',
      border: '3px solid var(--tab-active)',
      color: 'var(--tab-active)',
      background: 'transparent',
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 15,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      textAlign: 'center',
      padding: '11px 0',
      transform: `rotate(${rotate}deg)`,
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'background 120ms var(--ease-out), color 120ms var(--ease-out)',
      ...style
    },
    onMouseEnter: e => {
      if (!disabled) {
        e.currentTarget.style.background = 'var(--tab-active)';
        e.currentTarget.style.color = 'var(--tab-text)';
      }
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = 'transparent';
      e.currentTarget.style.color = 'var(--tab-active)';
    }
  }, children);
}
Object.assign(__ds_scope, { StampButton, __ds_default_components_controls_StampButton_1tn2u66: StampButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/StampButton.jsx", error: String((e && e.message) || e) }); }

// components/figures/BucketStrip.jsx
try { (() => {
/*
  BucketStrip — recent media docked at the page bottom (Code Change Notes #4, wireframes 3a/4a):
  BUCKET microlabel · 100×64 tiles (active = brown border, video = timestamp chip,
  add = dashed +) · "view all (N) ↘" turns the page.
*/
function BucketTile({
  src,
  active = false,
  add = false,
  chip,
  onClick,
  alt = '',
  style
}) {
  if (add) {
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onClick,
      "aria-label": "Add media",
      style: {
        width: 100,
        height: 64,
        border: '2px dashed var(--ink-40)',
        background: 'transparent',
        display: 'grid',
        placeItems: 'center',
        color: 'var(--tab-active)',
        fontSize: 23,
        padding: 0,
        cursor: 'pointer',
        boxSizing: 'border-box',
        ...style
      }
    }, "+");
  }
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    "aria-label": alt,
    style: {
      width: 100,
      height: 64,
      border: active ? '3px solid var(--tab-active)' : '2px solid var(--ink-40)',
      background: src ? `url(${src}) center / cover` : 'var(--hatch)',
      position: 'relative',
      padding: 0,
      cursor: onClick ? 'pointer' : 'default',
      boxSizing: 'border-box',
      ...style
    }
  }, chip && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 4,
      bottom: 4,
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      background: 'rgba(38,38,38,.75)',
      color: 'var(--tab-text)',
      padding: '0 5px',
      lineHeight: 1.5
    }
  }, chip));
}
function BucketStrip({
  children,
  total,
  onViewAll,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      borderTop: '1px solid var(--ink-30)',
      paddingTop: 14,
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--text-55)',
      letterSpacing: '0.06em'
    }
  }, "BUCKET"), children, total !== undefined && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onViewAll,
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--tab-active)',
      background: 'none',
      border: 'none',
      padding: 0,
      cursor: onViewAll ? 'pointer' : 'default'
    }
  }, "view all (", total, ") \u2198"));
}
Object.assign(__ds_scope, { BucketTile, BucketStrip, __ds_default_components_figures_BucketStrip_ryzyry: BucketStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/figures/BucketStrip.jsx", error: String((e && e.message) || e) }); }

// components/figures/Figure.jsx
try { (() => {
/*
  Figure — a numbered figure on the page (wireframe 4a): mono 600 header
  "01 · cluster histogram", optional right-side control (BracketSelector),
  optional sub line and metrics caption. Content = children.
*/
function Figure({
  number,
  title,
  control,
  sub,
  caption,
  divider = false,
  children,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      borderTop: divider ? '1px dashed var(--ink-35)' : 'none',
      paddingTop: divider ? 16 : 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 'var(--text-figure-title)'
    }
  }, number, " \xB7 ", title), control), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--text-50)',
      marginTop: 2
    }
  }, sub), children, caption && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--text-50)',
      marginTop: 5
    }
  }, caption));
}
Object.assign(__ds_scope, { Figure, __ds_default_components_figures_Figure_1rb87uo: Figure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/figures/Figure.jsx", error: String((e && e.message) || e) }); }

// components/figures/PaletteLedger.jsx
try { (() => {
/*
  PaletteLedger — the live palette in export format (Code Change Notes #3, wireframe 4a):
  two-column grid of swatch + "[r:g:b] · N px · P%" rows, footer action link.
*/
function LedgerRow({
  color,
  label,
  onCopy,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      cursor: onCopy ? 'pointer' : 'default',
      ...style
    },
    onClick: onCopy,
    title: onCopy ? 'copy hex' : undefined
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 29,
      height: 18,
      borderRadius: 3,
      background: color,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-ledger)',
      color: 'var(--text-85)',
      whiteSpace: 'nowrap'
    }
  }, label));
}
function PaletteLedger({
  entries,
  moreCount = 0,
  actions = 'hex / csv / ase ▸',
  onMore,
  columns = 2,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${columns}, 1fr)`,
      gap: '6px 32px',
      alignContent: 'start'
    }
  }, entries.map((e, i) => /*#__PURE__*/React.createElement(LedgerRow, {
    key: i,
    color: e.color,
    label: e.label,
    onCopy: e.onCopy
  }))), (moreCount > 0 || actions) && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onMore,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--tab-active)',
      background: 'none',
      border: 'none',
      padding: '9px 0 0',
      textAlign: 'left',
      cursor: onMore ? 'pointer' : 'default'
    }
  }, moreCount > 0 ? `+ ${moreCount} more · ${actions}` : actions));
}
Object.assign(__ds_scope, { LedgerRow, PaletteLedger, __ds_default_components_figures_PaletteLedger_1n2a9hc: PaletteLedger });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/figures/PaletteLedger.jsx", error: String((e && e.message) || e) }); }

// components/figures/Scrubber.jsx
try { (() => {
const {
  useRef,
  useCallback
} = React;
/*
  Scrubber — video timeline on the page (wireframe 5b): mono time labels,
  36px ticked film track, 4px brown playhead, hint line below.
*/
function fmt(s) {
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
}
function Scrubber({
  time = 0,
  duration = 121,
  onScrub,
  onSnapshot,
  hint = '◂ ▸ step frames · drag to scrub',
  style,
  className
}) {
  const trackRef = useRef(null);
  const pct = duration === 0 ? 0 : time / duration * 100;
  const setFromEvent = useCallback(e => {
    const el = trackRef.current;
    if (!el || !onScrub) return;
    const rect = el.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    onScrub(Math.min(1, Math.max(0, x / rect.width)) * duration);
  }, [duration, onScrub]);
  const onPointerDown = e => {
    setFromEvent(e);
    const move = ev => setFromEvent(ev);
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-60)'
    }
  }, fmt(time)), /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "slider",
    "aria-label": "Timeline",
    "aria-valuemin": 0,
    "aria-valuemax": duration,
    "aria-valuenow": time,
    tabIndex: 0,
    onPointerDown: onPointerDown,
    onKeyDown: e => {
      if (!onScrub) return;
      if (e.key === 'ArrowLeft') onScrub(Math.max(0, time - 1));else if (e.key === 'ArrowRight') onScrub(Math.min(duration, time + 1));else return;
      e.preventDefault();
    },
    style: {
      flex: 1,
      height: 36,
      border: '1px solid var(--ink-line)',
      background: 'repeating-linear-gradient(90deg, #e0d8c4, #e0d8c4 32px, #d5ccb6 32px, #d5ccb6 34px)',
      position: 'relative',
      cursor: onScrub ? 'pointer' : 'default',
      touchAction: 'none',
      boxSizing: 'border-box',
      outlineColor: 'var(--tab-active)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${pct}%`,
      top: -7,
      bottom: -7,
      width: 4,
      background: 'var(--tab-active)',
      pointerEvents: 'none'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-60)'
    }
  }, fmt(duration))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-50)',
      marginTop: 7
    }
  }, /*#__PURE__*/React.createElement("span", null, hint), onSnapshot && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSnapshot,
    style: {
      font: 'inherit',
      color: 'inherit',
      background: 'none',
      border: 'none',
      padding: 0,
      cursor: 'pointer'
    }
  }, "snapshot frame \u2702")));
}
Object.assign(__ds_scope, { Scrubber, __ds_default_components_figures_Scrubber_1viivcm: Scrubber });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/figures/Scrubber.jsx", error: String((e && e.message) || e) }); }

// components/navigation/EdgeTabs.jsx
try { (() => {
/*
  EdgeTabs — notebook nav: vertical tabs riding the page's left border.
  Wireframe 4a: active #7a5343 w16, inactive #8d6a5a w14, h54, radius 0 3 3 0,
  label cream, letter-spacing .05em. Full size = ×2.25.
*/
function EdgeTabs({
  tabs,
  active,
  onSelect,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'absolute',
      left: 0,
      top: 58,
      display: 'flex',
      flexDirection: 'column',
      gap: 27,
      zIndex: 2,
      ...style
    }
  }, tabs.map(t => {
    const isActive = t === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      type: "button",
      onClick: onSelect ? () => onSelect(t) : undefined,
      style: {
        writingMode: 'vertical-rl',
        fontFamily: 'inherit',
        fontSize: 15,
        letterSpacing: '0.05em',
        background: isActive ? 'var(--tab-active)' : 'var(--tab-inactive)',
        color: 'var(--tab-text)',
        width: isActive ? 36 : 32,
        height: 122,
        display: 'grid',
        placeItems: 'center',
        border: 'none',
        padding: 0,
        borderRadius: '0 7px 7px 0',
        boxShadow: '2px 2px 4px rgba(0,0,0,.25)',
        cursor: onSelect ? 'pointer' : 'default',
        transition: 'width 150ms var(--ease-out), background 150ms var(--ease-out)'
      }
    }, t);
  }));
}
Object.assign(__ds_scope, { EdgeTabs, __ds_default_components_navigation_EdgeTabs_b8pprs: EdgeTabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/EdgeTabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/FoldedCorner.jsx
try { (() => {
/*
  FoldedCorner — the "turn the page" affordance (wireframes 3a/3b/4a):
  a lifted paper corner over the desk. corner="bottom-right" (default) or "bottom-left".
*/
function FoldedCorner({
  corner = 'bottom-right',
  size = 68,
  onClick,
  title = 'Turn the page',
  style,
  className
}) {
  const right = corner === 'bottom-right';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: className,
    onClick: onClick,
    "aria-label": title,
    title: title,
    style: {
      position: 'absolute',
      bottom: -1,
      [right ? 'right' : 'left']: -1,
      width: size,
      height: size,
      padding: 0,
      background: right ? 'linear-gradient(315deg, var(--desk) 48%, #d5ccb6 50%, #ece5d2 100%)' : 'linear-gradient(45deg, var(--desk) 48%, #d5ccb6 50%, #ece5d2 100%)',
      border: 'none',
      [right ? 'borderLeft' : 'borderRight']: '1px solid var(--ink-25)',
      borderTop: '1px solid var(--ink-25)',
      boxShadow: right ? '-4px -4px 9px rgba(0,0,0,.12)' : '4px -4px 9px rgba(0,0,0,.12)',
      cursor: onClick ? 'pointer' : 'default',
      ...style
    }
  });
}
Object.assign(__ds_scope, { FoldedCorner, __ds_default_components_navigation_FoldedCorner_189dj2o: FoldedCorner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/FoldedCorner.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Spine.jsx
try { (() => {
/*
  Spine — the spread's center gutter (wireframes 4a/6a):
  a dark vertical gradient; stitched variant adds sewing holes (6a).
*/
function Spine({
  stitched = false,
  holes = 4,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'absolute',
      left: '50%',
      top: 0,
      bottom: 0,
      width: stitched ? 27 : 27,
      transform: 'translateX(-50%)',
      background: 'var(--spine)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-evenly',
      alignItems: 'center',
      pointerEvents: 'none',
      ...style
    }
  }, stitched && Array.from({
    length: holes
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: '#55504d',
      boxShadow: 'inset 0 2px 4px rgba(0,0,0,.6)'
    }
  })));
}
Object.assign(__ds_scope, { Spine, __ds_default_components_navigation_Spine_1fsqzdk: Spine });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Spine.jsx", error: String((e && e.message) || e) }); }

// components/overlay/ZoomOverlay.jsx
try { (() => {
/*
  ZoomOverlay — click any figure to lift it to the light (wireframes 7a/7b):
  dark scrim over the app, frame ≈70% of the window, centered.
  ground="flat" = cream frame (the page lifts); ground="pinned" = white card lifts.
  Chrome: mono title, fit ⤢, ✕, hint line, % readout.
*/
function ZoomOverlay({
  open = true,
  title,
  meta,
  ground = 'flat',
  zoom = 100,
  hint = 'scroll to zoom · drag to pan · double-click to fit · esc or click outside to close',
  onClose,
  onFit,
  children,
  style,
  className
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 10,
      ...style
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--zoom-scrim)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-label": title,
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      transform: 'translate(-50%,-50%)',
      width: '70%',
      height: '72%',
      background: ground === 'pinned' ? 'var(--card)' : 'var(--zoom-frame-bg)',
      border: '1px solid var(--zoom-frame-border)',
      borderRadius: 18,
      boxShadow: 'var(--zoom-shadow)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 32,
      top: 25,
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 18,
      color: 'rgba(38,38,38,.75)'
    }
  }, title, meta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--text-50)'
    }
  }, " \xB7 ", meta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 22,
      top: 18,
      display: 'flex',
      gap: 14,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onFit,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-55)',
      background: 'none',
      border: 'none',
      padding: 0,
      cursor: onFit ? 'pointer' : 'default'
    }
  }, "fit \u2922"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Close",
    style: {
      width: 34,
      height: 34,
      border: '1px solid rgba(43,41,38,.5)',
      borderRadius: 7,
      display: 'grid',
      placeItems: 'center',
      fontSize: 18,
      lineHeight: 1,
      background: 'none',
      padding: 0,
      cursor: 'pointer',
      color: 'inherit'
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: '64px 32px 58px',
      display: 'grid',
      placeItems: 'center'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 18,
      textAlign: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--text-50)'
    }
  }, hint), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 27,
      bottom: 18,
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-60)'
    }
  }, zoom, "%")));
}
Object.assign(__ds_scope, { ZoomOverlay, __ds_default_components_overlay_ZoomOverlay_19iqxma: ZoomOverlay });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/ZoomOverlay.jsx", error: String((e && e.message) || e) }); }

// components/paper/ErrorSlip.jsx
try { (() => {
/*
  ErrorSlip — errors are paper slips laid on the desk, not toasts (wireframe 5a):
  cream slip, ink border, microlabel header, ✗ + message, optional action link, ✕ dismiss.
*/
function ErrorSlip({
  label,
  message,
  detail,
  action,
  onAction,
  onDismiss,
  rotate = -0.8,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      background: 'var(--paper)',
      border: '1px solid var(--ink-line)',
      boxShadow: 'var(--slip-shadow)',
      padding: '22px 27px',
      transform: `rotate(${rotate}deg)`,
      position: 'relative',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 14,
      letterSpacing: '0.08em',
      color: 'var(--text-50)',
      textTransform: 'uppercase'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      alignItems: 'center',
      marginTop: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 25,
      color: 'var(--error)'
    }
  }, "\u2717"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: 16,
      color: 'var(--error)'
    }
  }, message), detail && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--text-60)',
      marginTop: 4
    }
  }, detail), action && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--tab-active)',
      textDecoration: 'underline',
      background: 'none',
      border: 'none',
      padding: 0,
      marginTop: 4,
      cursor: 'pointer',
      display: 'block'
    }
  }, action))), onDismiss && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      position: 'absolute',
      right: 18,
      top: 18,
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'rgba(38,38,38,.45)',
      background: 'none',
      border: 'none',
      padding: 0,
      cursor: 'pointer'
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { ErrorSlip, __ds_default_components_paper_ErrorSlip_m2mpv: ErrorSlip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/paper/ErrorSlip.jsx", error: String((e && e.message) || e) }); }

// components/paper/PinnedCard.jsx
try { (() => {
/*
  PinnedCard — a figure on white stock, pinned to the page (wireframes 6a/7b):
  white card, faint ink border, soft shadow, colored pin at top center, slight rotation.
  The "pinned cards" chart ground (Code Change Notes #11).
*/
function PinnedCard({
  children,
  pin = 'var(--pin-red)',
  rotate = -0.6,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'relative',
      background: 'var(--card)',
      border: '1px solid var(--ink-25)',
      boxShadow: 'var(--card-shadow)',
      padding: '16px 20px 14px',
      transform: `rotate(${rotate}deg)`,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '50%',
      top: -9,
      transform: 'translateX(-50%)',
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: pin,
      boxShadow: '0 2px 4px rgba(0,0,0,.35)'
    }
  }), children);
}

/*
  PinHole — what the pinned card leaves behind while lifted (wireframe 7b):
  ghost outline + pin hole.
*/
function PinHole({
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      border: '1px dashed var(--ink-35)',
      background: 'rgba(43,41,38,.04)',
      position: 'relative',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '50%',
      top: -4,
      transform: 'translateX(-50%)',
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: 'rgba(43,41,38,.45)',
      boxShadow: 'inset 0 2px 2px rgba(0,0,0,.5)'
    }
  }));
}
Object.assign(__ds_scope, { PinnedCard, PinHole, __ds_default_components_paper_PinnedCard_i940hl: PinnedCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/paper/PinnedCard.jsx", error: String((e && e.message) || e) }); }

// components/paper/TapedPhoto.jsx
try { (() => {
/*
  TapedPhoto — the loaded image taped to the page (wireframe 4a):
  slight rotation, two tape pieces at the top corners, optional ✕ unload button.
*/
function TapedPhoto({
  children,
  rotate = -0.8,
  onClose,
  closeLabel = '✕',
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'relative',
      transform: `rotate(${rotate}deg)`,
      ...style
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: -16,
      top: -11,
      width: 68,
      height: 23,
      background: 'var(--tape)',
      transform: 'rotate(-40deg)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -16,
      top: -11,
      width: 68,
      height: 23,
      background: 'var(--tape)',
      transform: 'rotate(40deg)',
      pointerEvents: 'none'
    }
  }), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Unload image",
    style: {
      position: 'absolute',
      right: 7,
      bottom: 7,
      width: 23,
      height: 23,
      border: '1px solid var(--ink-line)',
      borderRadius: 4,
      display: 'grid',
      placeItems: 'center',
      fontSize: 13,
      lineHeight: 1,
      background: 'rgba(245,239,225,.85)',
      padding: 0,
      cursor: 'pointer'
    }
  }, closeLabel));
}
Object.assign(__ds_scope, { TapedPhoto, __ds_default_components_paper_TapedPhoto_1l6sra1: TapedPhoto });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/paper/TapedPhoto.jsx", error: String((e && e.message) || e) }); }

// design-docs/animations.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// animations.jsx — timeline engine. Exports (on window): Stage, Sprite,
//   TextSprite, ImageSprite, RectSprite, VideoSprite, PlaybackBar,
//   useTime, useTimeline, useSprite, Easing, interpolate, animate, clamp.
//
//   <Stage width={1280} height={720} duration={10} background="#f6f4ef">
//     <Sprite start={0} end={3}>
//       <TextSprite text="Hello" x={100} y={300} size={72} color="#111" />
//     </Sprite>
//     <Sprite start={2} end={8}>
//       <ImageSprite src="hero.png" x={200} y={120} width={640} height={360} kenBurns />
//     </Sprite>
//   </Stage>
//
// Stage({width,height,duration,background,fps,loop,autoplay}) — auto-scales to
//   viewport; scrubber + play/pause + ←/→ seek + space + 0-reset; persists
//   playhead. The canvas is an <svg><foreignObject>, export-ready: Share →
//   Export → Video (or the PlaybackBar's download button) renders it to .mp4.
//   Screenshot tools DOM-rerender (not pixel-capture) and unwrap this wrapper
//   so captures should work — but if one comes back black, that's a capture
//   artifact, not a render bug; trust the live preview.
// Sprite({start,end,keepMounted}) — mounts children only while playhead is in
//   [start,end]. Children read {localTime, progress, duration} via useSprite().
// useTime() → seconds; useTimeline() → {time,duration,playing,setTime,setPlaying}.
// TextSprite({text,x,y,size,color,font,weight,align,entryDur,exitDur}) — fades/scales in+out.
// ImageSprite({src,x,y,width,height,fit,radius,kenBurns,placeholder}) — same, with optional ken-burns.
// RectSprite({x,y,width,height,color,radius}) — solid box with entry/exit.
// VideoSprite({src,start,end,speed,style}) — looped <video> clip synced to the
//   timeline; its audio is mixed into the exported video.
// Easing.{linear,easeIn/Out/InOut Quad/Cubic/Quart/Quint/Expo/Back, …}
// interpolate([t0,t1,…],[v0,v1,…],ease?) → (t)=>v  — piecewise tween.
// animate({from,to,start,end,ease}) → (t)=>v  — single tween.
//
// Build scenes by composing Sprites inside Stage. Absolutely-position elements.
//
// In a .dc.html project, put your scene in a sibling my-scene.jsx (reading
// {Stage, Sprite, useTime, Easing, …} from window is safe) and mount BOTH:
//   <x-import component-from-global-scope="MyScene"
//             from="./animations.jsx ./my-scene.jsx"></x-import>
// The two files in from= load in order, so my-scene.jsx can use the globals
// animations.jsx set.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

// ── Easing functions (hand-rolled, Popmotion-style) ─────────────────────────
// All easings take t ∈ [0,1] and return eased t ∈ [0,1] (may overshoot for back/elastic).
const Easing = {
  linear: t => t,
  // Quad
  easeInQuad: t => t * t,
  easeOutQuad: t => t * (2 - t),
  easeInOutQuad: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  // Cubic
  easeInCubic: t => t * t * t,
  easeOutCubic: t => --t * t * t + 1,
  easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  // Quart
  easeInQuart: t => t * t * t * t,
  easeOutQuart: t => 1 - --t * t * t * t,
  easeInOutQuart: t => t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t,
  // Expo
  easeInExpo: t => t === 0 ? 0 : Math.pow(2, 10 * (t - 1)),
  easeOutExpo: t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  easeInOutExpo: t => {
    if (t === 0) return 0;
    if (t === 1) return 1;
    if (t < 0.5) return 0.5 * Math.pow(2, 20 * t - 10);
    return 1 - 0.5 * Math.pow(2, -20 * t + 10);
  },
  // Sine
  easeInSine: t => 1 - Math.cos(t * Math.PI / 2),
  easeOutSine: t => Math.sin(t * Math.PI / 2),
  easeInOutSine: t => -(Math.cos(Math.PI * t) - 1) / 2,
  // Back (overshoot)
  easeOutBack: t => {
    const c1 = 1.70158,
      c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  },
  easeInBack: t => {
    const c1 = 1.70158,
      c3 = c1 + 1;
    return c3 * t * t * t - c1 * t * t;
  },
  easeInOutBack: t => {
    const c1 = 1.70158,
      c2 = c1 * 1.525;
    return t < 0.5 ? Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2) / 2 : (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
  },
  // Elastic
  easeOutElastic: t => {
    const c4 = 2 * Math.PI / 3;
    if (t === 0) return 0;
    if (t === 1) return 1;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
  }
};

// ── Core interpolation helpers ──────────────────────────────────────────────

// Clamp a value to [min, max]
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

// interpolate([0, 0.5, 1], [0, 100, 50], ease?) -> fn(t)
// Popmotion-style: linearly maps t across input keyframes to output values,
// with optional easing per segment (single fn or array of fns).
function interpolate(input, output, ease = Easing.linear) {
  return t => {
    if (t <= input[0]) return output[0];
    if (t >= input[input.length - 1]) return output[output.length - 1];
    for (let i = 0; i < input.length - 1; i++) {
      if (t >= input[i] && t <= input[i + 1]) {
        const span = input[i + 1] - input[i];
        const local = span === 0 ? 0 : (t - input[i]) / span;
        const easeFn = Array.isArray(ease) ? ease[i] || Easing.linear : ease;
        const eased = easeFn(local);
        return output[i] + (output[i + 1] - output[i]) * eased;
      }
    }
    return output[output.length - 1];
  };
}

// animate({from, to, start, end, ease})(t) — simpler single-segment tween.
// Returns `from` before `start`, `to` after `end`.
function animate({
  from = 0,
  to = 1,
  start = 0,
  end = 1,
  ease = Easing.easeInOutCubic
}) {
  return t => {
    if (t <= start) return from;
    if (t >= end) return to;
    const local = (t - start) / (end - start);
    return from + (to - from) * ease(local);
  };
}

// ── Timeline context ────────────────────────────────────────────────────────

const TimelineContext = React.createContext({
  time: 0,
  duration: 10,
  playing: false
});
const useTime = () => React.useContext(TimelineContext).time;
const useTimeline = () => React.useContext(TimelineContext);

// ── Sprite ──────────────────────────────────────────────────────────────────
// Renders children only when the playhead is inside [start, end]. Provides
// a sub-context with `localTime` (seconds since start) and `progress` (0..1).
//
//   <Sprite start={2} end={5}>
//     {({ localTime, progress }) => <Thing x={progress * 100} />}
//   </Sprite>
//
// Or as a plain wrapper — children can call useSprite() themselves.

const SpriteContext = React.createContext({
  localTime: 0,
  progress: 0,
  duration: 0
});
const useSprite = () => React.useContext(SpriteContext);
function Sprite({
  start = 0,
  end = Infinity,
  children,
  keepMounted = false
}) {
  const {
    time
  } = useTimeline();
  const visible = time >= start && time <= end;
  if (!visible && !keepMounted) return null;
  const duration = end - start;
  const localTime = Math.max(0, time - start);
  const progress = duration > 0 && isFinite(duration) ? clamp(localTime / duration, 0, 1) : 0;
  const value = {
    localTime,
    progress,
    duration,
    visible
  };
  return /*#__PURE__*/React.createElement(SpriteContext.Provider, {
    value: value
  }, typeof children === 'function' ? children(value) : children);
}

// ── Sample sprite components ────────────────────────────────────────────────

// TextSprite: fades/slides text in on entry, holds, then fades out on exit.
// Props: text, x, y, size, color, font, entryDur, exitDur, align
function TextSprite({
  text,
  x = 0,
  y = 0,
  size = 48,
  color = '#111',
  font = 'Inter, system-ui, sans-serif',
  weight = 600,
  entryDur = 0.45,
  exitDur = 0.35,
  entryEase = Easing.easeOutBack,
  exitEase = Easing.easeInCubic,
  align = 'left',
  letterSpacing = '-0.01em'
}) {
  const {
    localTime,
    duration
  } = useSprite();
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let ty = 0;
  if (localTime < entryDur) {
    const t = entryEase(clamp(localTime / entryDur, 0, 1));
    opacity = t;
    ty = (1 - t) * 16;
  } else if (localTime > exitStart) {
    const t = exitEase(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    ty = -t * 8;
  }
  const translateX = align === 'center' ? '-50%' : align === 'right' ? '-100%' : '0';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      transform: `translate(${translateX}, ${ty}px)`,
      opacity,
      fontFamily: font,
      fontSize: size,
      fontWeight: weight,
      color,
      letterSpacing,
      whiteSpace: 'pre',
      lineHeight: 1.1,
      willChange: 'transform, opacity'
    }
  }, text);
}

// ImageSprite: scales + fades in; optional Ken Burns drift during hold.
function ImageSprite({
  src,
  x = 0,
  y = 0,
  width = 400,
  height = 300,
  entryDur = 0.6,
  exitDur = 0.4,
  kenBurns = false,
  kenBurnsScale = 1.08,
  radius = 12,
  fit = 'cover',
  placeholder = null // {label: string} for striped placeholder
}) {
  const {
    localTime,
    duration
  } = useSprite();
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let scale = 1;
  if (localTime < entryDur) {
    const t = Easing.easeOutCubic(clamp(localTime / entryDur, 0, 1));
    opacity = t;
    scale = 0.96 + 0.04 * t;
  } else if (localTime > exitStart) {
    const t = Easing.easeInCubic(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    scale = (kenBurns ? kenBurnsScale : 1) + 0.02 * t;
  } else if (kenBurns) {
    const holdSpan = exitStart - entryDur;
    const holdT = holdSpan > 0 ? (localTime - entryDur) / holdSpan : 0;
    scale = 1 + (kenBurnsScale - 1) * holdT;
  }
  const content = placeholder ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'repeating-linear-gradient(135deg, #e9e6df 0 10px, #dcd8cf 10px 20px)',
      color: '#6b6458',
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontSize: 13,
      letterSpacing: '0.04em',
      textTransform: 'uppercase'
    }
  }, placeholder.label || 'image') : /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: fit,
      display: 'block'
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      width,
      height,
      opacity,
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      borderRadius: radius,
      overflow: 'hidden',
      willChange: 'transform, opacity'
    }
  }, content);
}

// RectSprite: simple rectangle that animates position/size/color via props.
// Useful demo primitive — takes a `render` fn for per-frame customization.
function RectSprite({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  color = '#111',
  radius = 8,
  entryDur = 0.4,
  exitDur = 0.3,
  render // optional: (ctx) => style overrides
}) {
  const spriteCtx = useSprite();
  const {
    localTime,
    duration
  } = spriteCtx;
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let scale = 1;
  if (localTime < entryDur) {
    const t = Easing.easeOutBack(clamp(localTime / entryDur, 0, 1));
    opacity = clamp(localTime / entryDur, 0, 1);
    scale = 0.4 + 0.6 * t;
  } else if (localTime > exitStart) {
    const t = Easing.easeInQuad(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    scale = 1 - 0.15 * t;
  }
  const overrides = render ? render(spriteCtx) : {};
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      width,
      height,
      background: color,
      borderRadius: radius,
      opacity,
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      willChange: 'transform, opacity',
      ...overrides
    }
  });
}

// ── Font inlining ───────────────────────────────────────────────────────────
// Copy every @font-face rule from the page into a <style> inside the svg's
// foreignObject, with font URLs rewritten to data: URLs. Makes the svg
// self-describing so serializing it alone (video export fast path) still
// renders with the right fonts. Sets data-om-fonts-inlined on the svg when
// done so the exporter can wait for it.

function useInlineFontsInto(svgRef) {
  React.useEffect(() => {
    const svg = svgRef.current;
    const host = svg && svg.querySelector('foreignObject > div');
    if (!svg || !host) return;
    let cancelled = false;
    (async () => {
      const rules = [];
      for (const ss of document.styleSheets) {
        let cssRules;
        try {
          cssRules = ss.cssRules;
        } catch {
          // Cross-origin sheet without crossorigin attr (e.g. the standard
          // fonts.googleapis.com <link>) — fetch the CSS text directly and
          // regex-extract the @font-face blocks.
          if (ss.href) {
            try {
              const txt = await fetch(ss.href).then(r => {
                if (!r.ok) throw 0;
                return r.text();
              });
              for (const ff of txt.match(/@font-face\s*{[^}]*}/g) || []) rules.push({
                css: ff,
                base: ss.href
              });
            } catch {}
          }
          continue;
        }
        if (!cssRules) continue;
        for (const r of cssRules) {
          if (r.type === CSSRule.FONT_FACE_RULE) {
            rules.push({
              css: r.cssText,
              base: ss.href || location.href
            });
          }
        }
      }
      const toDataURL = url => fetch(url).then(r => {
        if (!r.ok) throw 0;
        return r.blob();
      }).then(b => new Promise(res => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = () => res(url);
        fr.readAsDataURL(b);
      })).catch(() => url);
      const parts = await Promise.all(rules.map(async ({
        css,
        base
      }) => {
        const re = /url\((['"]?)([^'")]+)\1\)/g;
        let out = css,
          m;
        while (m = re.exec(css)) {
          const u = m[2];
          if (u.startsWith('data:')) continue;
          let abs;
          try {
            abs = new URL(u, base).href;
          } catch {
            continue;
          }
          out = out.split(m[0]).join(`url("${await toDataURL(abs)}")`);
        }
        return out;
      }));
      if (cancelled || !parts.length) {
        svg.setAttribute('data-om-fonts-inlined', 'true');
        return;
      }
      const style = document.createElement('style');
      style.textContent = parts.join('\n');
      host.insertBefore(style, host.firstChild);
      svg.setAttribute('data-om-fonts-inlined', 'true');
    })();
    return () => {
      cancelled = true;
    };
  }, []);
}
function Stage({
  width = 1280,
  height = 720,
  duration = 10,
  background = '#f6f4ef',
  fps = 60,
  loop = true,
  autoplay = true,
  persistKey = 'animstage',
  children
}) {
  // Props arrive as strings when Stage is mounted via <x-import> (DC
  // projects) — coerce so style={{width}} gets a number React can px-ify.
  width = +width || 1280;
  height = +height || 720;
  duration = +duration || 10;
  fps = +fps || 60;
  if (typeof loop === 'string') loop = loop !== 'false';
  if (typeof autoplay === 'string') autoplay = autoplay !== 'false';
  const [time, setTime] = React.useState(() => {
    try {
      const v = parseFloat(localStorage.getItem(persistKey + ':t') || '0');
      return isFinite(v) ? clamp(v, 0, duration) : 0;
    } catch {
      return 0;
    }
  });
  const [playing, setPlaying] = React.useState(autoplay);
  const [hoverTime, setHoverTime] = React.useState(null);
  const [scale, setScale] = React.useState(1);
  const stageRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  const rafRef = React.useRef(null);
  const lastTsRef = React.useRef(null);

  // Persist playhead
  React.useEffect(() => {
    try {
      localStorage.setItem(persistKey + ':t', String(time));
    } catch {}
  }, [time, persistKey]);

  // Auto-scale to fit viewport
  React.useEffect(() => {
    if (!stageRef.current) return;
    const el = stageRef.current;
    const measure = () => {
      const barH = 44; // playback bar height
      const s = Math.min(el.clientWidth / width, (el.clientHeight - barH) / height);
      setScale(Math.max(0.05, s));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [width, height]);

  // Animation loop
  React.useEffect(() => {
    if (!playing) {
      lastTsRef.current = null;
      return;
    }
    const step = ts => {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;
      setTime(t => {
        let next = t + dt;
        if (next >= duration) {
          if (loop) next = next % duration;else {
            next = duration;
            setPlaying(false);
          }
        }
        return next;
      });
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
    };
  }, [playing, duration, loop]);

  // Keyboard: space = play/pause, ← → = seek
  React.useEffect(() => {
    const onKey = e => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setPlaying(p => !p);
      } else if (e.code === 'ArrowLeft') {
        setTime(t => clamp(t - (e.shiftKey ? 1 : 0.1), 0, duration));
      } else if (e.code === 'ArrowRight') {
        setTime(t => clamp(t + (e.shiftKey ? 1 : 0.1), 0, duration));
      } else if (e.key === '0' || e.code === 'Home') {
        setTime(0);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [duration]);

  // Video-export protocol: the exporter dispatches this event per frame;
  // pause + sync the playhead so the capture sees exactly that timestamp.
  React.useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const onSeek = e => {
      setPlaying(false);
      setTime(clamp(e.detail.time, 0, duration));
    };
    el.addEventListener('data-om-seek-to-time-frame', onSeek);
    return () => el.removeEventListener('data-om-seek-to-time-frame', onSeek);
  }, [duration]);

  // Inline @font-face rules into the svg's foreignObject so the svg is
  // self-describing — serializing it alone (for video export) then renders
  // with the right fonts. Sets data-om-fonts-inlined once done.
  useInlineFontsInto(canvasRef);
  const displayTime = hoverTime != null ? hoverTime : time;
  const ctxValue = React.useMemo(() => ({
    time: displayTime,
    duration,
    playing,
    setTime,
    setPlaying
  }), [displayTime, duration, playing]);
  return /*#__PURE__*/React.createElement("div", {
    ref: stageRef,
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      background: '#0a0a0a',
      fontFamily: 'Inter, system-ui, sans-serif'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    ref: canvasRef,
    width: width,
    height: height,
    "data-om-exportable-video-with-duration-secs": duration,
    style: {
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      flexShrink: 0,
      boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("foreignObject", {
    x: "0",
    y: "0",
    width: "100%",
    height: "100%"
  }, /*#__PURE__*/React.createElement("div", {
    xmlns: "http://www.w3.org/1999/xhtml",
    style: {
      width,
      height,
      background,
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(TimelineContext.Provider, {
    value: ctxValue
  }, children))))), /*#__PURE__*/React.createElement(PlaybackBar, {
    time: displayTime,
    actualTime: time,
    duration: duration,
    playing: playing,
    onPlayPause: () => setPlaying(p => !p),
    onReset: () => {
      setTime(0);
    },
    onSeek: t => setTime(t),
    onHover: t => setHoverTime(t)
  }));
}

// ── Playback bar ────────────────────────────────────────────────────────────
// Play/pause, return-to-begin, scrub track, time display.
// Uses fixed-width time fields so layout doesn't thrash.

function PlaybackBar({
  time,
  duration,
  playing,
  onPlayPause,
  onReset,
  onSeek,
  onHover
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  const timeFromEvent = React.useCallback(e => {
    const rect = trackRef.current.getBoundingClientRect();
    const x = clamp((e.clientX - rect.left) / rect.width, 0, 1);
    return x * duration;
  }, [duration]);
  const onTrackMove = e => {
    if (!trackRef.current) return;
    const t = timeFromEvent(e);
    if (dragging) {
      onSeek(t);
    } else {
      onHover(t);
    }
  };
  const onTrackLeave = () => {
    if (!dragging) onHover(null);
  };
  const onTrackDown = e => {
    setDragging(true);
    const t = timeFromEvent(e);
    onSeek(t);
    onHover(null);
  };
  React.useEffect(() => {
    if (!dragging) return;
    const onUp = () => setDragging(false);
    const onMove = e => {
      if (!trackRef.current) return;
      const t = timeFromEvent(e);
      onSeek(t);
    };
    window.addEventListener('mouseup', onUp);
    window.addEventListener('mousemove', onMove);
    return () => {
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('mousemove', onMove);
    };
  }, [dragging, timeFromEvent, onSeek]);
  const pct = duration > 0 ? time / duration * 100 : 0;
  const fmt = t => {
    const total = Math.max(0, t);
    const m = Math.floor(total / 60);
    const s = Math.floor(total % 60);
    const cs = Math.floor(total * 100 % 100);
    return `${String(m).padStart(1, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
  };
  const mono = 'JetBrains Mono, ui-monospace, SFMono-Regular, monospace';
  return /*#__PURE__*/React.createElement("div", {
    "data-omelette-chrome": true,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '8px 16px',
      background: 'rgba(20,20,20,0.92)',
      borderTop: '1px solid rgba(255,255,255,0.08)',
      width: '100%',
      maxWidth: 680,
      alignSelf: 'center',
      borderRadius: 8,
      color: '#f6f4ef',
      fontFamily: 'Inter, system-ui, sans-serif',
      userSelect: 'none',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    onClick: onReset,
    title: "Return to start (0)"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 2v10M12 2L5 7l7 5V2z",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }))), /*#__PURE__*/React.createElement(IconButton, {
    onClick: onPlayPause,
    title: "Play/pause (space)"
  }, playing ? /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "2",
    width: "3",
    height: "10",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "8",
    y: "2",
    width: "3",
    height: "10",
    fill: "currentColor"
  })) : /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 2l9 5-9 5V2z",
    fill: "currentColor"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      width: 64,
      textAlign: 'right',
      color: '#f6f4ef'
    }
  }, fmt(time)), /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    onMouseMove: onTrackMove,
    onMouseLeave: onTrackLeave,
    onMouseDown: onTrackDown,
    style: {
      flex: 1,
      height: 22,
      position: 'relative',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      height: 4,
      background: 'rgba(255,255,255,0.12)',
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      width: `${pct}%`,
      height: 4,
      background: 'oklch(72% 0.12 250)',
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${pct}%`,
      top: '50%',
      width: 12,
      height: 12,
      marginLeft: -6,
      marginTop: -6,
      background: '#fff',
      borderRadius: 6,
      boxShadow: '0 2px 4px rgba(0,0,0,0.4)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      width: 64,
      textAlign: 'left',
      color: 'rgba(246,244,239,0.55)'
    }
  }, fmt(duration)), typeof VideoEncoder !== 'undefined' && /*#__PURE__*/React.createElement(IconButton, {
    title: "Export video",
    onClick: () => window.parent.postMessage({
      type: 'omelette:request-video-export'
    }, '*')
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 2v7m0 0L4 6m3 3l3-3M2 12h10",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))));
}
function IconButton({
  children,
  onClick,
  title
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    title: title,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 28,
      height: 28,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: hover ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.04)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: 6,
      color: '#f6f4ef',
      cursor: 'pointer',
      padding: 0,
      transition: 'background 120ms'
    }
  }, children);
}

// ── VideoSprite ─────────────────────────────────────────────────────────────
// Renders a <video> that loops within [start,end] of its source at `speed`,
// kept in sync with the Stage's playhead. Carries the
// data-om-exportable-video-play-* attrs so video export can mix its audio.
//
//   <VideoSprite src="clip.mp4" start={2} end={5} speed={1}
//     style={{ width: 640, height: 360 }} />

function VideoSprite({
  src,
  start = 0,
  end,
  speed = 1,
  style,
  ...rest
}) {
  start = +start || 0;
  speed = +speed || 1;
  if (end != null) end = +end || undefined;
  const t = useTime();
  const ref = React.useRef(null);
  const span = Math.max(0.001, (end ?? start + 1) - start);
  React.useEffect(() => {
    const v = ref.current;
    if (!v || v.readyState < 1) return;
    const target = start + t * speed % span;
    if (Math.abs(v.currentTime - target) > 0.05) v.currentTime = target;
  }, [t, start, span, speed]);
  return /*#__PURE__*/React.createElement("video", _extends({
    ref: ref,
    src: src,
    muted: true,
    playsInline: true,
    preload: "auto",
    "data-om-exportable-video-play-start": start,
    "data-om-exportable-video-play-end": end ?? start + span,
    "data-om-exportable-video-play-speed": speed,
    style: {
      display: 'block',
      objectFit: 'cover',
      ...style
    }
  }, rest));
}
Object.assign(window, {
  Easing,
  interpolate,
  animate,
  clamp,
  TimelineContext,
  useTime,
  useTimeline,
  Sprite,
  SpriteContext,
  useSprite,
  TextSprite,
  ImageSprite,
  RectSprite,
  VideoSprite,
  Stage,
  PlaybackBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "design-docs/animations.jsx", error: String((e && e.message) || e) }); }

// design-docs/reflow-studies.jsx
try { (() => {
// Reflow motion studies — three treatments of spread → single column
// Uses globals from animations.jsx: Stage, Sprite, useTime, useSprite, Easing, interpolate, clamp
(function () {
  const {
    Stage,
    Sprite,
    useSprite,
    Easing,
    interpolate,
    clamp
  } = window;
  const R = React;
  const h = R.createElement;

  // ---------- shared mini-page pieces (wireframe fills) ----------
  const CREAM = '#F5EFE1',
    CREAM2 = '#F8F2E5',
    INK = '#2b2926',
    DESK = '#6e6764';
  const hatch = (a, b, s) => `repeating-linear-gradient(45deg,${a},${a} ${s}px,${b} ${s}px,${b} ${s * 2}px)`;
  function Tabs({
    h: hh
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: 0,
        top: hh * 0.06,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, ['#7a5343', '#8d6a5a', '#8d6a5a', '#8d6a5a'].map((c, i) => h('div', {
      key: i,
      style: {
        width: i === 0 ? 9 : 7,
        height: hh * 0.11,
        background: c,
        borderRadius: '0 3px 3px 0'
      }
    })));
  }
  function ImgBlock({
    w,
    hh
  }) {
    return h('div', {
      style: {
        width: w,
        height: hh,
        border: `1.5px solid ${INK}`,
        background: hatch('#e5ddc9', '#ede6d4', 8),
        boxSizing: 'border-box'
      }
    });
  }
  function Sliders({
    w,
    n
  }) {
    return h('div', {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 9,
        width: w
      }
    }, Array.from({
      length: n
    }, (_, i) => h('div', {
      key: i,
      style: {
        height: 6,
        borderRadius: 99,
        background: '#ddd5c2',
        position: 'relative'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: `${25 + i * 18}%`,
        top: -3,
        width: 12,
        height: 12,
        borderRadius: '50%',
        background: '#fcf8ee',
        border: '1px solid rgba(43,41,38,.45)'
      }
    }))));
  }
  function Histo({
    w,
    hh
  }) {
    const bars = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#696955', '#9e5738', '#2f5b6e'];
    return h('div', {
      style: {
        width: w,
        height: hh,
        display: 'flex',
        alignItems: 'flex-end',
        gap: 2,
        borderBottom: `1.5px solid ${INK}`,
        boxSizing: 'border-box'
      }
    }, bars.map((c, i) => h('div', {
      key: i,
      style: {
        flex: 1,
        height: `${100 - i * 12}%`,
        background: c
      }
    })));
  }
  function Polar({
    d
  }) {
    return h('div', {
      style: {
        width: d,
        height: d,
        position: 'relative'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        inset: d * 0.06,
        borderRadius: '50%',
        border: `1.5px solid ${INK}`
      }
    }), h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: '50%',
        height: 1,
        background: 'rgba(43,41,38,.5)'
      }
    }), h('div', {
      style: {
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: '50%',
        width: 1,
        background: 'rgba(43,41,38,.5)'
      }
    }), [['56%', '18%', '#6e3a1f', 0.09], ['48%', '40%', '#cfc4ae', 0.08], ['54%', '58%', '#3a4034', 0.1], ['40%', '64%', '#2f5b6e', 0.05]].map((p, i) => h('div', {
      key: i,
      style: {
        position: 'absolute',
        left: p[0],
        top: p[1],
        width: d * p[3],
        height: d * p[3],
        borderRadius: '50%',
        background: p[2]
      }
    })));
  }
  function Ledger({
    w
  }) {
    const rows = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#9e5738'];
    return h('div', {
      style: {
        width: w,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '4px 14px'
      }
    }, rows.map((c, i) => h('div', {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5
      }
    }, h('div', {
      style: {
        width: 16,
        height: 9,
        background: c,
        borderRadius: 2
      }
    }), h('div', {
      style: {
        flex: 1,
        height: 4,
        background: 'rgba(43,41,38,.25)',
        borderRadius: 99
      }
    }))));
  }

  // Left page content (fixed across all treatments)
  function LeftPageContent({
    pw,
    ph
  }) {
    return h('div', {
      style: {
        padding: `${ph * 0.055}px ${pw * 0.08}px`,
        paddingLeft: pw * 0.14,
        position: 'relative',
        height: '100%',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: ph * 0.05
      }
    }, h(Tabs, {
      h: ph
    }), h('div', {
      style: {
        width: '46%',
        height: 10,
        background: 'rgba(43,41,38,.55)',
        borderRadius: 2
      }
    }), h(ImgBlock, {
      w: '100%',
      hh: ph * 0.34
    }), h(Sliders, {
      w: '92%',
      n: 4
    }));
  }

  // Right page figures — rendered via a layout map so treatments can animate positions
  function RightFigures({
    pw,
    ph
  }) {
    return h('div', {
      style: {
        padding: `${ph * 0.055}px ${pw * 0.08}px`,
        height: '100%',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: ph * 0.055
      }
    }, h(Histo, {
      w: '100%',
      hh: ph * 0.24
    }), h('div', {
      style: {
        display: 'flex',
        gap: pw * 0.07,
        alignItems: 'flex-start'
      }
    }, h(Polar, {
      d: ph * 0.3
    }), h('div', {
      style: {
        flex: 1,
        height: ph * 0.3,
        borderLeft: `1.5px solid ${INK}`,
        borderBottom: `1.5px solid ${INK}`
      }
    })), h(Ledger, {
      w: '100%'
    }));
  }

  // window chrome that narrows over time
  function Win({
    w,
    hh,
    children,
    label
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%,-50%)',
        width: w,
        height: hh,
        background: DESK,
        borderRadius: 10,
        boxShadow: '0 18px 50px rgba(0,0,0,.45)',
        overflow: 'hidden'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        height: 26,
        background: '#3a3735',
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '0 12px'
      }
    }, ['#e0564f', '#e0a03c', '#57a45b'].map((c, i) => h('div', {
      key: i,
      style: {
        width: 9,
        height: 9,
        borderRadius: '50%',
        background: c
      }
    })), h('div', {
      style: {
        marginLeft: 'auto',
        font: '11px Fira Code, monospace',
        color: 'rgba(255,255,255,.55)'
      }
    }, label)), h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 26,
        bottom: 0
      }
    }, children));
  }

  // ============================================================
  // Treatment A — CROSSFADE + RE-STACK (recommended)
  // Right page fades, figures slide into the column, spine fades.
  // ============================================================
  function SceneA({
    t0
  }) {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    // window width narrows 0→2s, holds, widens 5.5→7.5s
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const compact = winW < 980;
    // reflow progress: 0 = spread, 1 = single column (with hysteresis feel)
    const p = interpolate([1.35, 1.95, 5.75, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const rightOpacity = 1 - clamp(p * 2.2, 0, 1); // right page fades early
    const figuresIn = clamp((p - 0.35) / 0.6, 0, 1); // figures slide in after
    const spineOp = 1 - clamp(p * 3, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px ${compact ? '· compact' : ''}`
    },
    // left page — grows into the single column
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)'
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }),
    // figures re-stacking into the column below the sliders
    h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    })))),
    // scroll hint in compact
    figuresIn > 0.9 && h('div', {
      style: {
        position: 'absolute',
        right: 5,
        top: 8,
        bottom: 8,
        width: 4,
        borderRadius: 99,
        background: 'rgba(43,41,38,.12)'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: '4%',
        height: '34%',
        borderRadius: 99,
        background: 'rgba(122,83,67,.55)'
      }
    }))),
    // spine
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: 'translateX(-50%)',
        width: 10,
        height: H - 60,
        background: 'linear-gradient(90deg,rgba(0,0,0,.08),rgba(0,0,0,.28),rgba(0,0,0,.08))',
        opacity: spineOp
      }
    }),
    // right page — fades + drifts left
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${p * -30}px)`,
        width: winW / 2 - 60,
        height: H - 60,
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)',
        opacity: rightOpacity,
        pointerEvents: 'none'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })));
  }

  // ============================================================
  // Treatment B — PAGE FOLD (the heavy one, for comparison)
  // Right page rotates behind the left on a perspective hinge.
  // ============================================================
  function SceneB() {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.85, 5.85, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const foldDeg = p * -168;
    const figuresIn = clamp((p - 0.55) / 0.45, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px · fold`
    }, h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)'
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }), h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    }))))),
    // folding right page, hinged at the spine
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        width: winW / 2 - 60,
        height: H - 60,
        perspective: 900,
        transformStyle: 'preserve-3d',
        pointerEvents: 'none'
      }
    }, h('div', {
      style: {
        width: '100%',
        height: '100%',
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: `${8 + p * 20}px 0 ${16 + p * 24}px rgba(0,0,0,${0.25 + p * 0.2})`,
        transform: `rotateY(${foldDeg}deg)`,
        transformOrigin: 'left center',
        backfaceVisibility: 'hidden'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })),
    // back face (paper back)
    h('div', {
      style: {
        position: 'absolute',
        inset: 0,
        background: '#e8e1ce',
        border: `1px solid ${INK}`,
        transform: `rotateY(${foldDeg + 180}deg)`,
        transformOrigin: 'left center',
        backfaceVisibility: 'hidden'
      }
    })));
  }

  // ============================================================
  // Treatment C — SLIDE UNDER (right page slips beneath the left, like sliding a sheet under the top one)
  // ============================================================
  function SceneC() {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.9, 5.8, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const slideX = p * -(winW / 2 - 40);
    const figuresIn = clamp((p - 0.5) / 0.5, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px · slide-under`
    },
    // right page slides under: z-order below left, translates left + dims slightly
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18 + p * 8,
        transform: `translateX(${slideX}px) scale(${1 - p * 0.06})`,
        width: winW / 2 - 60,
        height: H - 60,
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)',
        opacity: 1 - p * 0.55,
        zIndex: 1,
        pointerEvents: 'none'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })), h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: `${p * 10}px 6px ${14 + p * 10}px rgba(0,0,0,.32)`,
        zIndex: 2
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }), h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    }))))));
  }
  function Caption({
    text,
    sub
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 34,
        textAlign: 'center'
      }
    }, h('div', {
      style: {
        font: '600 30px Fira Code, monospace',
        color: '#f3ece0'
      }
    }, text), h('div', {
      style: {
        font: '17px Fira Sans, sans-serif',
        color: 'rgba(243,236,224,.65)',
        marginTop: 6
      }
    }, sub));
  }
  function ReflowStudies() {
    const DUR = 24;
    return h(Stage, {
      width: 1440,
      height: 810,
      duration: DUR,
      background: '#4a4340',
      loop: true
    },
    // A
    h(Sprite, {
      start: 0,
      end: 8
    }, h(SceneA, null), h(Caption, {
      text: 'A · crossfade + re-stack',
      sub: 'right page fades ~120ms → figures slide into the column · cheap, interruptible — recommended for live resize'
    })),
    // B
    h(Sprite, {
      start: 8,
      end: 16
    }, h(SceneB, null), h(Caption, {
      text: 'B · page fold',
      sub: 'right page folds behind on a spine hinge · charming but heavy — better saved for deliberate page turns'
    })),
    // C
    h(Sprite, {
      start: 16,
      end: 24
    }, h(SceneC, null), h(Caption, {
      text: 'C · slide under',
      sub: 'right sheet slips beneath the left, column grows over it · middle ground, keeps paper physicality'
    })));
  }
  window.ReflowStudies = ReflowStudies;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "design-docs/reflow-studies.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notebook/ColorsSpread.jsx
try { (() => {
// Notebook UI kit — Colors spread (wireframe 4a) + shared page/chart bits
const DS = window.ColorToolDesignSystem_73584b;
const {
  Figure,
  BracketSelector,
  PaletteLedger,
  BucketStrip,
  BucketTile,
  PaperSlider,
  PaperCheckbox,
  TapedPhoto,
  PinnedCard,
  FoldedCorner
} = DS;
const {
  bars,
  ledger,
  polarDots,
  hlDots,
  IMG
} = window.CTNotebook;

// Page shells — full size: each page 794×958 (wf 353×426 ×2.25)
function LeftPage({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "nb-ruled-left",
    style: {
      background: 'var(--paper)',
      border: '1px solid var(--ink-line)',
      borderRight: 'none',
      padding: '34px 45px 22px 99px',
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      boxSizing: 'border-box',
      ...style
    }
  }, children);
}
function RightPage({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "nb-ruled-right",
    style: {
      background: 'var(--paper-right)',
      border: '1px solid var(--ink-line)',
      borderLeft: 'none',
      padding: '34px 40px 22px 36px',
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      gap: 25,
      boxSizing: 'border-box',
      ...style
    }
  }, children);
}
function PageTitle({
  title,
  filename,
  meta
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 25px var(--font-mono)',
      letterSpacing: '.06em'
    }
  }, title, " ", filename && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--muted-filename)'
    }
  }, "\xB7 ", filename)), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '14px var(--font-mono)',
      color: 'var(--text-55)'
    }
  }, meta));
}

// Ink charts (drawn as divs, like the wireframes)
function Histogram({
  height = 126,
  onZoom
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onZoom,
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 2,
      height,
      borderBottom: '1px solid var(--ink-line)',
      marginTop: 11,
      cursor: onZoom ? 'zoom-in' : 'default'
    }
  }, bars.map(([c, h], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: c
    }
  })));
}
function Polar({
  size = 234,
  onZoom,
  axisLabels = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onZoom,
    style: {
      width: size,
      height: size,
      position: 'relative',
      margin: '13px auto 0',
      cursor: onZoom ? 'zoom-in' : 'default'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: size * 0.058,
      borderRadius: '50%',
      border: '1px solid var(--ink-line)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: size * 0.23,
      borderRadius: '50%',
      border: '1px dashed var(--ink-30)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      top: '50%',
      height: 1,
      background: 'var(--ink-55)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: '50%',
      width: 1,
      background: 'var(--ink-55)'
    }
  }), axisLabels && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: size * 0.04,
      top: size * 0.11,
      font: '11px var(--font-mono)',
      transform: 'rotate(40deg)',
      color: 'var(--text-60)'
    }
  }, "\u2190 hue \u2192"), polarDots.map(([x, y, s, c], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: 'absolute',
      left: x + '%',
      top: y + '%',
      width: s,
      height: s,
      borderRadius: '50%',
      background: c
    }
  })));
}
function HueLightness({
  height = 216,
  onZoom,
  axisLabels = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onZoom,
    style: {
      height,
      borderLeft: '1px solid var(--ink-line)',
      borderBottom: '1px solid var(--ink-line)',
      position: 'relative',
      marginTop: 13,
      cursor: onZoom ? 'zoom-in' : 'default'
    }
  }, axisLabels && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: -8,
      top: 0,
      font: '11px var(--font-mono)',
      writingMode: 'vertical-rl',
      transform: 'rotate(180deg)',
      color: 'var(--text-60)'
    }
  }, "lightness"), axisLabels && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 0,
      bottom: -16,
      font: '11px var(--font-mono)',
      color: 'var(--text-60)'
    }
  }, "hue \xB0"), hlDots.map(([x, y, s, c], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: 'absolute',
      left: x + '%',
      top: y + '%',
      width: s,
      height: s,
      borderRadius: '50%',
      background: c
    }
  })));
}
function GroundWrap({
  ground,
  pin,
  rotate,
  children,
  style
}) {
  if (ground === 'pinned') return /*#__PURE__*/React.createElement(PinnedCard, {
    pin: pin,
    rotate: rotate,
    style: style
  }, children);
  return /*#__PURE__*/React.createElement("div", {
    style: style
  }, children);
}
function ColorsSpread({
  ground,
  onZoom,
  onTurnToBucket,
  loadedName,
  params,
  setParam
}) {
  const [sort, setSort] = React.useState('frequency');
  const [polarMode, setPolarMode] = React.useState('okhsv');
  const [hlMode, setHlMode] = React.useState('frequency');
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(LeftPage, null, /*#__PURE__*/React.createElement(PageTitle, {
    title: "COLORS",
    filename: loadedName,
    meta: "3840\xD72160"
  }), /*#__PURE__*/React.createElement(TapedPhoto, {
    style: {
      width: '86%',
      margin: '27px auto 0'
    },
    onClose: () => {}
  }, /*#__PURE__*/React.createElement("img", {
    src: IMG,
    alt: loadedName,
    style: {
      display: 'block',
      width: '100%',
      height: 275,
      objectFit: 'cover',
      border: '1px solid var(--ink-line)',
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      marginTop: 36
    }
  }, /*#__PURE__*/React.createElement(PaperSlider, {
    label: "Number of clusters",
    value: params.clusters,
    min: 1,
    max: 200,
    onChange: setParam('clusters')
  }), /*#__PURE__*/React.createElement(PaperSlider, {
    label: "Speed \u2190 \u2192 Quality",
    value: params.quality,
    min: 0,
    max: 4,
    onChange: setParam('quality')
  }), /*#__PURE__*/React.createElement(PaperSlider, {
    label: "Exclude top clusters",
    value: params.exclude,
    min: 0,
    max: 50,
    onChange: setParam('exclude')
  }), /*#__PURE__*/React.createElement(PaperSlider, {
    label: "Merge threshold \u0394E",
    value: params.merge,
    min: 0,
    max: 0.1,
    step: 0.01,
    format: v => v.toFixed(2),
    onChange: setParam('merge')
  }), /*#__PURE__*/React.createElement(PaperSlider, {
    label: "Symbol size",
    value: params.symbol,
    min: 0.5,
    max: 2,
    step: 0.1,
    format: v => v.toFixed(1),
    onChange: setParam('symbol')
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 40,
      alignItems: 'center',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(PaperCheckbox, {
    label: "Cluster outline",
    checked: params.outline,
    onChange: setParam('outline')
  }), /*#__PURE__*/React.createElement(PaperCheckbox, {
    label: "Axis labels",
    checked: params.axisLabels,
    onChange: setParam('axisLabels')
  }))), /*#__PURE__*/React.createElement(BucketStrip, {
    total: 7,
    onViewAll: onTurnToBucket,
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement(BucketTile, {
    src: IMG,
    active: true,
    alt: loadedName
  }), /*#__PURE__*/React.createElement(BucketTile, {
    chip: "\u25B6 02:01",
    alt: "pan-shot.mp4"
  }), /*#__PURE__*/React.createElement(BucketTile, {
    alt: "ref-cafe.jpg"
  }), /*#__PURE__*/React.createElement(BucketTile, {
    add: true,
    onClick: () => {}
  }))), /*#__PURE__*/React.createElement(RightPage, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 27
    }
  }, /*#__PURE__*/React.createElement(GroundWrap, {
    ground: ground,
    pin: "var(--pin-blue)",
    rotate: 0.8
  }, /*#__PURE__*/React.createElement(Figure, {
    number: "01",
    title: "polar",
    sub: "hue \xB7 saturation",
    control: /*#__PURE__*/React.createElement(BracketSelector, {
      options: ['oklch', 'okhsv', 'hsv'],
      value: polarMode,
      onChange: setPolarMode
    })
  }, /*#__PURE__*/React.createElement(Polar, {
    axisLabels: params.axisLabels,
    onZoom: () => onZoom({
      title: '01 · polar',
      meta: `oklch [${polarMode}] hsv · hue · saturation`,
      kind: 'polar'
    })
  }))), /*#__PURE__*/React.createElement(GroundWrap, {
    ground: ground,
    pin: "var(--pin-green)",
    rotate: -0.9
  }, /*#__PURE__*/React.createElement(Figure, {
    number: "02",
    title: "hue \xD7 lightness",
    sub: "rendered in oklch",
    control: /*#__PURE__*/React.createElement(BracketSelector, {
      options: ['frequency', 'chroma'],
      value: hlMode,
      onChange: setHlMode
    })
  }, /*#__PURE__*/React.createElement(HueLightness, {
    axisLabels: params.axisLabels,
    onZoom: () => onZoom({
      title: '02 · hue × lightness',
      meta: `[${hlMode}] chroma · rendered in oklch`,
      kind: 'hl'
    })
  })))), /*#__PURE__*/React.createElement(GroundWrap, {
    ground: ground,
    pin: "var(--pin-red)",
    rotate: -0.6
  }, /*#__PURE__*/React.createElement(Figure, {
    number: "03",
    title: "cluster histogram",
    caption: "486 ms \xB7 14 iterations \xB7 84,211 samples",
    divider: ground === 'flat',
    control: /*#__PURE__*/React.createElement(BracketSelector, {
      options: ['frequency', 'hue', 'lightness'],
      value: sort,
      onChange: setSort
    })
  }, /*#__PURE__*/React.createElement(Histogram, {
    onZoom: () => onZoom({
      title: '03 · cluster histogram',
      meta: `[${sort}] · 486 ms · 14 iter · 84,211 samples`,
      kind: 'histogram'
    })
  }))), /*#__PURE__*/React.createElement(GroundWrap, {
    ground: ground,
    pin: "var(--pin-brown)",
    rotate: 0.4,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Figure, {
    number: "04",
    title: "palette",
    divider: ground === 'flat',
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column'
    },
    control: /*#__PURE__*/React.createElement("span", {
      style: {
        font: '14px var(--font-mono)',
        color: 'var(--text-60)'
      }
    }, params.clusters, " clusters")
  }, /*#__PURE__*/React.createElement(PaletteLedger, {
    entries: ledger.map(([color, label]) => ({
      color,
      label
    })),
    moreCount: params.clusters - ledger.length,
    style: {
      marginTop: 11,
      flex: 1
    }
  }))), /*#__PURE__*/React.createElement(FoldedCorner, {
    onClick: onTurnToBucket
  })));
}
Object.assign(window, {
  LeftPage,
  RightPage,
  PageTitle,
  Histogram,
  Polar,
  HueLightness,
  GroundWrap,
  ColorsSpread
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notebook/ColorsSpread.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notebook/NotebookApp.jsx
try { (() => {
// Notebook UI kit — app shell: desk, spread, edge tabs, view switching, zoom overlay, ground toggle
const DS3 = window.ColorToolDesignSystem_73584b;
const {
  EdgeTabs: Tabs3,
  Spine: Spine3,
  ZoomOverlay: Zoom3,
  BracketSelector: Brackets3
} = DS3;
const TABS = ['Colors', 'Values', 'Batch', 'Exports'];
function ZoomContent({
  kind,
  axisLabels
}) {
  if (kind === 'polar') return /*#__PURE__*/React.createElement(window.Polar, {
    size: 430,
    axisLabels: axisLabels
  });
  if (kind === 'histogram') return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '86%'
    }
  }, /*#__PURE__*/React.createElement(window.Histogram, {
    height: 340
  }));
  if (kind === 'hl') return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '80%'
    }
  }, /*#__PURE__*/React.createElement(window.HueLightness, {
    height: 360,
    axisLabels: axisLabels
  }));
  if (kind === 'vhist') return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '86%',
      display: 'flex',
      alignItems: 'flex-end',
      gap: 4,
      height: 320,
      borderBottom: '1px solid var(--ink-line)'
    }
  }, window.CTNotebook.valueBars.map(([c, h], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: c
    }
  })));
  return /*#__PURE__*/React.createElement("img", {
    src: window.CTNotebook.IMG,
    alt: "zoomed",
    style: {
      maxWidth: '100%',
      maxHeight: '100%',
      border: '1px solid var(--ink-line)',
      filter: kind === 'neutral' ? 'grayscale(1)' : 'none'
    }
  });
}
function NotebookApp() {
  const [view, setView] = React.useState('Colors');
  const [bucketOpen, setBucketOpen] = React.useState(false);
  const [zoomed, setZoomed] = React.useState(null);
  const [ground, setGround] = React.useState('flat');
  const [loadedName, setLoadedName] = React.useState('study-014.png');
  const [params, setParams] = React.useState({
    clusters: 45,
    quality: 2,
    exclude: 0,
    merge: 0,
    symbol: 1.0,
    outline: false,
    axisLabels: true
  });
  const setParam = k => v => setParams(p => ({
    ...p,
    [k]: v
  }));
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') setZoomed(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const isSpread = !bucketOpen && (view === 'Colors' || view === 'Values' || view === 'Batch');
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": bucketOpen ? 'Media Bucket page' : view + ' view',
    style: {
      position: 'relative',
      width: 1720,
      height: 1030,
      background: 'var(--desk)',
      overflow: 'hidden',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 27,
      top: 18,
      font: '13px var(--font-mono)',
      color: 'rgba(255,255,255,.75)',
      display: 'flex',
      gap: 10,
      alignItems: 'center',
      zIndex: 3
    }
  }, /*#__PURE__*/React.createElement("span", null, "chart ground"), /*#__PURE__*/React.createElement(Brackets3, {
    options: ['flat', 'pinned'],
    value: ground,
    onChange: setGround,
    style: {
      color: 'rgba(255,255,255,.75)',
      filter: 'invert(1) hue-rotate(180deg)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      filter: 'var(--sheet-shadow)'
    }
  }, bucketOpen ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: -13,
      top: 4,
      bottom: 4,
      width: 13,
      background: '#e8e1ce',
      border: '1px solid var(--ink-35)',
      borderRight: 'none'
    }
  }), /*#__PURE__*/React.createElement(window.BucketPage, {
    onLoad: name => {
      setLoadedName(name);
      setBucketOpen(false);
      setView('Colors');
    },
    onBack: () => setBucketOpen(false)
  })) : isSpread ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1588,
      height: 958,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      position: 'relative'
    }
  }, view === 'Colors' && /*#__PURE__*/React.createElement(window.ColorsSpread, {
    ground: ground,
    onZoom: setZoomed,
    onTurnToBucket: () => setBucketOpen(true),
    loadedName: loadedName,
    params: params,
    setParam: setParam
  }), view === 'Values' && /*#__PURE__*/React.createElement(window.ValuesSpread, {
    onZoom: setZoomed
  }), view === 'Batch' && /*#__PURE__*/React.createElement(window.BatchSpread, {
    onZoom: setZoomed
  }), /*#__PURE__*/React.createElement(Spine3, {
    stitched: ground === 'pinned'
  })) : /*#__PURE__*/React.createElement(window.ExportsSheet, null), /*#__PURE__*/React.createElement(Tabs3, {
    tabs: TABS,
    active: bucketOpen ? '' : view,
    onSelect: t => {
      setBucketOpen(false);
      setView(t);
    }
  })), /*#__PURE__*/React.createElement(Zoom3, {
    open: !!zoomed,
    title: zoomed ? zoomed.title : '',
    meta: zoomed ? zoomed.meta : '',
    ground: ground,
    zoom: 100,
    onClose: () => setZoomed(null),
    onFit: () => {}
  }, zoomed && /*#__PURE__*/React.createElement(ZoomContent, {
    kind: zoomed.kind,
    axisLabels: params.axisLabels
  })));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(NotebookApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notebook/NotebookApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notebook/Views.jsx
try { (() => {
// Notebook UI kit — Values spread (5b), Exports sheet (5c), Batch spread (5d), Bucket page (3b)
const DS2 = window.ColorToolDesignSystem_73584b;
const {
  Figure: Fig2,
  BracketSelector: Brackets2,
  PaperSlider: Slider2,
  Scrubber,
  StampButton,
  FoldedCorner: Fold2,
  TapedPhoto: Taped2,
  BucketTile: Tile2
} = DS2;
const {
  valueBars,
  IMG: IMG2,
  bars: bars2,
  ledger: ledger2,
  polarDots: polar2
} = window.CTNotebook;
const MICRO = {
  font: '600 13px var(--font-mono)',
  letterSpacing: '.08em',
  color: 'var(--text-55)',
  marginBottom: 7
};
function ValuesSpread({
  onZoom
}) {
  const [t, setT] = React.useState(42);
  const [levels, setLevels] = React.useState(3);
  const shares = {
    2: [58, 42],
    3: [31, 46, 23],
    4: [24, 30, 27, 19],
    5: [18, 24, 25, 20, 13]
  }[levels];
  const tones = {
    2: ['#2a2926', '#e4dbc2'],
    3: ['#2a2926', '#837c69', '#e4dbc2'],
    4: ['#1c1a17', '#5a5548', '#a89f89', '#e4dbc2'],
    5: ['#1c1a17', '#454138', '#837c69', '#c2b9a1', '#eae1c8']
  }[levels];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.LeftPage, null, /*#__PURE__*/React.createElement(window.PageTitle, {
    title: "VALUES",
    filename: "pan-shot.mp4"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: MICRO
  }, "ORIGINAL"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: IMG2,
    alt: "frame @ 00:42",
    style: {
      display: 'block',
      width: '100%',
      height: 265,
      objectFit: 'cover',
      border: '1px solid var(--ink-line)',
      boxSizing: 'border-box',
      cursor: 'zoom-in'
    },
    onClick: () => onZoom({
      title: 'original',
      meta: 'frame @ 00:42',
      kind: 'image'
    })
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 7,
      bottom: 7,
      font: '11px var(--font-mono)',
      background: 'rgba(38,38,38,.75)',
      color: 'var(--tab-text)',
      padding: '1px 5px'
    }
  }, "frame @ 00:42"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 7,
      top: 7,
      width: 23,
      height: 23,
      border: '1px solid var(--ink-line)',
      borderRadius: 4,
      display: 'grid',
      placeItems: 'center',
      fontSize: 12,
      background: 'rgba(245,239,225,.85)'
    }
  }, "\u2702"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: MICRO
  }, "NEUTRAL VALUES"), /*#__PURE__*/React.createElement("img", {
    src: IMG2,
    alt: "neutral values",
    style: {
      display: 'block',
      width: '100%',
      height: 265,
      objectFit: 'cover',
      border: '1px solid var(--ink-line)',
      boxSizing: 'border-box',
      filter: 'grayscale(1)',
      cursor: 'zoom-in'
    },
    onClick: () => onZoom({
      title: 'neutral values',
      meta: 'oklab L channel',
      kind: 'neutral'
    })
  })), /*#__PURE__*/React.createElement(Scrubber, {
    time: t,
    duration: 121,
    onScrub: setT,
    onSnapshot: () => {},
    style: {
      marginTop: 20
    }
  })), /*#__PURE__*/React.createElement(window.RightPage, null, /*#__PURE__*/React.createElement(Fig2, {
    number: "01",
    title: "range finder",
    control: /*#__PURE__*/React.createElement("span", {
      style: {
        font: '13px var(--font-mono)',
        color: 'var(--text-60)'
      }
    }, "MID KEY \xB7 MODERATE CONTRAST")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 50,
      border: '1px solid var(--ink-line)',
      borderRadius: 99,
      background: 'linear-gradient(90deg,#2a2926,#f8f2e3)',
      position: 'relative',
      marginTop: 13,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: '2%',
      top: 4,
      bottom: 4,
      width: '95%',
      borderRadius: 99,
      background: 'rgba(38,38,38,.08)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: '14%',
      top: 11,
      bottom: 11,
      width: '68%',
      borderRadius: 99,
      background: 'rgba(38,38,38,.2)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: '2%',
      top: 2,
      bottom: 2,
      width: '95%',
      borderRadius: 99,
      border: '2px solid rgba(38,38,38,.75)',
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: '12px var(--font-mono)',
      color: 'var(--text-60)',
      marginTop: 7
    }
  }, /*#__PURE__*/React.createElement("span", null, "0"), /*#__PURE__*/React.createElement("span", null, "mass 14\u201382% \xB7 extremes 2\u201397%"), /*#__PURE__*/React.createElement("span", null, "100"))), /*#__PURE__*/React.createElement(Fig2, {
    number: "02",
    title: "values histogram"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 2,
      height: 117,
      borderBottom: '1px solid var(--ink-line)',
      marginTop: 11,
      cursor: 'zoom-in'
    },
    onClick: () => onZoom({
      title: '02 · values histogram',
      meta: '12 buckets · oklab L',
      kind: 'vhist'
    })
  }, valueBars.map(([c, h], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: h + '%',
      background: c
    }
  })))), /*#__PURE__*/React.createElement(Fig2, {
    number: "03",
    title: "simplified tones",
    divider: true,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column'
    },
    control: /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 11,
        font: '13px var(--font-mono)',
        color: 'rgba(38,38,38,.7)'
      }
    }, "levels", /*#__PURE__*/React.createElement(Slider2, {
      label: "",
      value: levels,
      min: 2,
      max: 5,
      onChange: setLevels,
      labelWidth: 0,
      valueWidth: 20,
      style: {
        width: 170
      }
    }))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      border: '1px solid var(--ink-40)',
      borderRadius: 9,
      overflow: 'hidden',
      marginTop: 16,
      height: 54
    }
  }, shares.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: s,
      background: tones[i],
      display: 'grid',
      placeItems: 'center',
      color: i < shares.length / 2 ? '#e8e2d2' : '#14120f',
      font: '600 13px var(--font-mono)',
      cursor: 'pointer'
    }
  }, s, "%"))), /*#__PURE__*/React.createElement("img", {
    src: IMG2,
    alt: "simplified preview",
    style: {
      display: 'block',
      width: '100%',
      flex: 1,
      minHeight: 126,
      objectFit: 'cover',
      border: '1px solid var(--ink-line)',
      boxSizing: 'border-box',
      marginTop: 18,
      filter: `grayscale(1) contrast(${0.7 + levels * 0.3})`
    }
  })), /*#__PURE__*/React.createElement(Fold2, {
    onClick: () => {}
  })));
}
function ExportRow({
  checked,
  label,
  note,
  dim
}) {
  const [on, setOn] = React.useState(checked);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: '15px var(--font-mono)',
      color: dim ? 'rgba(38,38,38,.4)' : 'inherit',
      cursor: dim ? 'default' : 'pointer'
    },
    onClick: dim ? undefined : () => setOn(!on)
  }, /*#__PURE__*/React.createElement("span", null, "[", on && !dim ? 'x' : ' ', "] ", label, " ", note && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-50)'
    }
  }, "(", note, ")")), /*#__PURE__*/React.createElement("span", {
    style: {
      color: dim ? 'inherit' : 'var(--tab-active)'
    }
  }, "\u2193"));
}
function ExportsSheet() {
  const [scale, setScale] = React.useState(2);
  const [fmt, setFmt] = React.useState('svg');
  const rule = {
    fontSize: 16,
    fontWeight: 600,
    borderBottom: '1px solid var(--ink-line)',
    paddingBottom: 7,
    fontFamily: 'var(--font-mono)'
  };
  const col = {
    display: 'flex',
    flexDirection: 'column',
    gap: 11,
    marginTop: 14
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "nb-ruled-left",
    style: {
      width: 909,
      height: 958,
      background: 'var(--paper)',
      border: '1px solid var(--ink-line)',
      position: 'relative',
      padding: '34px 40px 27px 99px',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      margin: '0 auto',
      fontFamily: 'var(--font-mono)'
    }
  }, /*#__PURE__*/React.createElement(window.PageTitle, {
    title: "EXPORTS",
    filename: "study-014"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '0 40px',
      marginTop: 22,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: rule
  }, "\u2500\u2500 colors \u2500\u2500"), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "source image"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "polar chart"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "cluster histogram",
    note: "+all sorts"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    label: "hue \xD7 lightness"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "palette strip",
    note: "top 20"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    label: "video barcode",
    dim: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      fontSize: 14,
      color: 'var(--tab-active)',
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("u", {
    style: {
      cursor: 'pointer'
    }
  }, "csv"), /*#__PURE__*/React.createElement("u", {
    style: {
      cursor: 'pointer'
    }
  }, ".ase"), /*#__PURE__*/React.createElement("u", {
    style: {
      cursor: 'pointer'
    }
  }, "json")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(StampButton, null, "Export Colors Composite"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: rule
  }, "\u2500\u2500 values \u2500\u2500"), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "neutral values",
    note: "+original"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "range finder"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    label: "values histogram"
  }), /*#__PURE__*/React.createElement(ExportRow, {
    checked: true,
    label: "simplified values",
    note: "+all studies"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(StampButton, {
    rotate: 0.5
  }, "Export Values Composite")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      borderTop: '1px dashed var(--ink-35)',
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement(Slider2, {
    label: "png scale",
    value: scale,
    min: 1,
    max: 4,
    onChange: setScale,
    labelWidth: 110,
    valueWidth: 40,
    format: v => v + '×'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center',
      fontSize: 13,
      color: 'var(--text-60)',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("span", null, "format:"), /*#__PURE__*/React.createElement(Brackets2, {
    options: ['svg', 'png'],
    value: fmt,
    onChange: setFmt
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-50)'
    }
  }, "saving to ~/art/studies/exports \xB7 ", /*#__PURE__*/React.createElement("u", {
    style: {
      color: 'var(--tab-active)',
      cursor: 'pointer'
    }
  }, "change")));
}
function BatchSpread({
  onZoom
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.LeftPage, null, /*#__PURE__*/React.createElement(window.PageTitle, {
    title: "BATCH",
    filename: "6 items \xB7 2 pinned"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 20,
      marginTop: 27
    }
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: 'relative',
      height: 144,
      border: i < 2 ? '3px solid var(--tab-active)' : '2px solid var(--ink-40)',
      background: `url(${IMG2}) ${20 * i}% center / cover`,
      boxSizing: 'border-box'
    }
  }, i < 2 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '50%',
      top: -9,
      transform: 'translateX(-50%)',
      width: 18,
      height: 18,
      borderRadius: '50%',
      background: 'var(--pin-red)',
      boxShadow: '0 2px 4px rgba(0,0,0,.3)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 144,
      border: '2px dashed var(--ink-40)',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--tab-active)',
      fontSize: 27,
      boxSizing: 'border-box'
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '12px var(--font-mono)',
      color: 'var(--text-55)',
      marginTop: 14
    }
  }, "pin \u25C9 = include in aggregate \xB7 click to open in Colors"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Slider2, {
    label: "Clusters per image",
    defaultValue: 45,
    min: 1,
    max: 200,
    labelWidth: 230
  }), /*#__PURE__*/React.createElement(Slider2, {
    label: "Speed \u2190 \u2192 Quality",
    defaultValue: 2,
    min: 0,
    max: 4,
    labelWidth: 230
  }))), /*#__PURE__*/React.createElement(window.RightPage, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 17px var(--font-mono)'
    }
  }, "aggregate \xB7 2 pinned images"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '14px var(--font-mono)',
      color: 'var(--text-60)',
      cursor: 'pointer'
    }
  }, "recompute \u21BB")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 27
    }
  }, /*#__PURE__*/React.createElement(Fig2, {
    number: "01",
    title: "combined polar"
  }, /*#__PURE__*/React.createElement(window.Polar, {
    size: 207,
    onZoom: () => onZoom({
      title: '01 · combined polar',
      meta: '2 pinned images',
      kind: 'polar'
    })
  })), /*#__PURE__*/React.createElement(Fig2, {
    number: "02",
    title: "combined histogram"
  }, /*#__PURE__*/React.createElement(window.Histogram, {
    height: 180,
    onZoom: () => onZoom({
      title: '02 · combined histogram',
      meta: '2 pinned images',
      kind: 'histogram'
    })
  }))), /*#__PURE__*/React.createElement(Fig2, {
    number: "03",
    title: "combined palette strip",
    divider: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: 45,
      border: '1px solid var(--ink-line)',
      overflow: 'hidden',
      marginTop: 11
    }
  }, [['#3c3f38', 12], ['#1c1a17', 10], ['#898575', 9], ['#d2c5af', 8], ['#603425', 7], ['#696955', 6], ['#9e5738', 5], ['#2f5b6e', 4], ['#dbd1ba', 3], ['#10130f', 3]].map(([c, f], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: f,
      background: c
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 117,
      border: '1px solid var(--ink-line)',
      background: 'var(--hatch)',
      display: 'grid',
      placeItems: 'center',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '13px var(--font-mono)',
      color: 'var(--hatch-text)'
    }
  }, "composite grid preview")), /*#__PURE__*/React.createElement(Fold2, {
    onClick: () => {}
  })));
}
function BucketPage({
  onLoad,
  onBack
}) {
  const items = [{
    name: 'study-014.png',
    loaded: true
  }, {
    name: 'ref-cafe.jpg'
  }, {
    name: 'pan-shot.mp4',
    video: true,
    chip: '02:01'
  }, {
    name: 'pan-shot_0042.png',
    chip: 'frame @ 00:42'
  }, {
    name: 'notan-ref.png'
  }, {
    name: 'plein-air-03.jpg'
  }, {
    name: 'paste-091412.png'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "nb-ruled-left",
    style: {
      width: 1320,
      height: 958,
      background: 'var(--paper)',
      border: '1px solid var(--ink-line)',
      position: 'relative',
      padding: '36px 45px 27px 50px',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      borderBottom: '1px solid var(--ink-line)',
      paddingBottom: 11
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 18px var(--font-mono)',
      letterSpacing: '.08em'
    }
  }, "MEDIA BUCKET \xB7 7 items"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '13px var(--font-mono)',
      color: 'var(--text-60)'
    }
  }, "drag to reorder \xB7 right-click to remove")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '27px 32px',
      marginTop: 32
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: it.name,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => onLoad(it.name),
    style: {
      height: 167,
      border: it.loaded ? '4px solid var(--tab-active)' : '2px solid var(--ink-40)',
      background: `url(${window.CTNotebook.IMG}) ${14 * i}% center / cover`,
      position: 'relative',
      cursor: 'pointer',
      boxSizing: 'border-box'
    }
  }, it.loaded && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 7,
      top: 7,
      font: '11px var(--font-mono)',
      background: 'var(--tab-active)',
      color: 'var(--tab-text)',
      padding: '1px 7px'
    }
  }, "loaded"), it.video && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      transform: 'translate(-50%,-50%)',
      width: 36,
      height: 36,
      border: '1px solid var(--ink-line)',
      borderRadius: '50%',
      display: 'grid',
      placeItems: 'center',
      fontSize: 16,
      background: 'rgba(245,239,225,.8)'
    }
  }, "\u25B6"), it.chip && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 7,
      bottom: 7,
      font: '11px var(--font-mono)',
      background: 'rgba(38,38,38,.7)',
      color: 'var(--tab-text)',
      padding: '1px 7px'
    }
  }, it.chip)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '13px var(--font-mono)',
      color: 'rgba(38,38,38,.75)'
    }
  }, it.name))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 167,
      border: '3px dashed var(--ink-40)',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--tab-active)',
      fontSize: 29,
      boxSizing: 'border-box',
      cursor: 'pointer'
    }
  }, "+")), /*#__PURE__*/React.createElement(window.CTFold, {
    corner: "bottom-left",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    onClick: onBack,
    style: {
      position: 'absolute',
      left: 90,
      bottom: 20,
      font: '15px var(--font-mono)',
      color: 'var(--tab-active)',
      cursor: 'pointer'
    }
  }, "\u2196 turn back to Colors"));
}
window.CTFold = Fold2;
Object.assign(window, {
  ValuesSpread,
  ExportsSheet,
  BatchSpread,
  BucketPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notebook/Views.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notebook/kit-data.js
try { (() => {
// Color Tool notebook UI kit — shared data (colors lifted from the wireframes' own values)
(function () {
  const bars = [['#3c3f38', 100], ['#1c1a17', 88], ['#292f2c', 86], ['#080f0d', 76], ['#898575', 74], ['#d2c5af', 73], ['#603425', 69], ['#dbd1ba', 65], ['#696955', 51], ['#4b523f', 44], ['#9e5738', 37], ['#5a5a58', 32], ['#b07a4e', 28], ['#2f5b6e', 25], ['#cfc4ae', 22], ['#3a4034', 19], ['#8a5a33', 16], ['#10130f', 14], ['#8fa04f', 12], ['#c79a6f', 10], ['#6e3a1f', 8], ['#b9b0a2', 7], ['#7d7d45', 5], ['#2a1408', 4]];
  const ledger = [['#3c3f38', '[60:63:56] · 594 px · 2.35%'], ['#1c1a17', '[28:26:23] · 522 px · 2.07%'], ['#292f2c', '[41:48:44] · 509 px · 2.02%'], ['#080f0d', '[8:15:13] · 453 px · 1.79%'], ['#898575', '[137:133:118] · 440 px · 1.74%'], ['#d2c5af', '[210:197:175] · 432 px · 1.71%'], ['#603425', '[96:52:37] · 411 px · 1.63%'], ['#dbd1ba', '[219:209:186] · 389 px · 1.54%'], ['#696955', '[105:105:85] · 305 px · 1.21%'], ['#4b523f', '[75:82:63] · 261 px · 1.03%'], ['#9e5738', '[158:87:56] · 222 px · 0.88%'], ['#5a5a58', '[90:90:88] · 188 px · 0.74%'], ['#b07a4e', '[176:122:78] · 164 px · 0.65%'], ['#2f5b6e', '[47:91:110] · 141 px · 0.56%']];
  const polarDots = [[55, 15, 20, '#6e3a1f'], [61, 26, 16, '#8a5a33'], [49, 33, 13, '#b07a4e'], [65, 36, 9, '#8fa04f'], [46, 44, 18, '#cfc4ae'], [52, 55, 22, '#3a4034'], [55, 69, 20, '#10130f'], [40, 62, 9, '#2f5b6e'], [36, 40, 11, '#898575']];
  const hlDots = [[10, 20, 11, '#d2c5af'], [16, 66, 18, '#603425'], [28, 48, 20, '#8a5a33'], [36, 30, 13, '#c79a6f'], [48, 56, 11, '#7d7d45'], [56, 40, 9, '#8fa04f'], [66, 74, 16, '#3a4034'], [78, 62, 11, '#2f5b6e'], [86, 84, 13, '#10130f']];
  const valueBars = [['#1c1a17', 8], ['#26241f', 16], ['#33302a', 30], ['#454138', 52], ['#5a5548', 72], ['#6e6858', 88], ['#837c69', 100], ['#98907b', 84], ['#ada58e', 62], ['#c2b9a1', 44], ['#d6cdb4', 28], ['#eae1c8', 14]];
  window.CTNotebook = {
    bars,
    ledger,
    polarDots,
    hlDots,
    valueBars,
    IMG: '../../assets/sample/tavern-reference.jpg'
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notebook/kit-data.js", error: String((e && e.message) || e) }); }

// uploads/UI review and feedback/animations.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// animations.jsx — timeline engine. Exports (on window): Stage, Sprite,
//   TextSprite, ImageSprite, RectSprite, VideoSprite, PlaybackBar,
//   useTime, useTimeline, useSprite, Easing, interpolate, animate, clamp.
//
//   <Stage width={1280} height={720} duration={10} background="#f6f4ef">
//     <Sprite start={0} end={3}>
//       <TextSprite text="Hello" x={100} y={300} size={72} color="#111" />
//     </Sprite>
//     <Sprite start={2} end={8}>
//       <ImageSprite src="hero.png" x={200} y={120} width={640} height={360} kenBurns />
//     </Sprite>
//   </Stage>
//
// Stage({width,height,duration,background,fps,loop,autoplay}) — auto-scales to
//   viewport; scrubber + play/pause + ←/→ seek + space + 0-reset; persists
//   playhead. The canvas is an <svg><foreignObject>, export-ready: Share →
//   Export → Video (or the PlaybackBar's download button) renders it to .mp4.
//   Screenshot tools DOM-rerender (not pixel-capture) and unwrap this wrapper
//   so captures should work — but if one comes back black, that's a capture
//   artifact, not a render bug; trust the live preview.
// Sprite({start,end,keepMounted}) — mounts children only while playhead is in
//   [start,end]. Children read {localTime, progress, duration} via useSprite().
// useTime() → seconds; useTimeline() → {time,duration,playing,setTime,setPlaying}.
// TextSprite({text,x,y,size,color,font,weight,align,entryDur,exitDur}) — fades/scales in+out.
// ImageSprite({src,x,y,width,height,fit,radius,kenBurns,placeholder}) — same, with optional ken-burns.
// RectSprite({x,y,width,height,color,radius}) — solid box with entry/exit.
// VideoSprite({src,start,end,speed,style}) — looped <video> clip synced to the
//   timeline; its audio is mixed into the exported video.
// Easing.{linear,easeIn/Out/InOut Quad/Cubic/Quart/Quint/Expo/Back, …}
// interpolate([t0,t1,…],[v0,v1,…],ease?) → (t)=>v  — piecewise tween.
// animate({from,to,start,end,ease}) → (t)=>v  — single tween.
//
// Build scenes by composing Sprites inside Stage. Absolutely-position elements.
//
// In a .dc.html project, put your scene in a sibling my-scene.jsx (reading
// {Stage, Sprite, useTime, Easing, …} from window is safe) and mount BOTH:
//   <x-import component-from-global-scope="MyScene"
//             from="./animations.jsx ./my-scene.jsx"></x-import>
// The two files in from= load in order, so my-scene.jsx can use the globals
// animations.jsx set.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

// ── Easing functions (hand-rolled, Popmotion-style) ─────────────────────────
// All easings take t ∈ [0,1] and return eased t ∈ [0,1] (may overshoot for back/elastic).
const Easing = {
  linear: t => t,
  // Quad
  easeInQuad: t => t * t,
  easeOutQuad: t => t * (2 - t),
  easeInOutQuad: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  // Cubic
  easeInCubic: t => t * t * t,
  easeOutCubic: t => --t * t * t + 1,
  easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
  // Quart
  easeInQuart: t => t * t * t * t,
  easeOutQuart: t => 1 - --t * t * t * t,
  easeInOutQuart: t => t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t,
  // Expo
  easeInExpo: t => t === 0 ? 0 : Math.pow(2, 10 * (t - 1)),
  easeOutExpo: t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  easeInOutExpo: t => {
    if (t === 0) return 0;
    if (t === 1) return 1;
    if (t < 0.5) return 0.5 * Math.pow(2, 20 * t - 10);
    return 1 - 0.5 * Math.pow(2, -20 * t + 10);
  },
  // Sine
  easeInSine: t => 1 - Math.cos(t * Math.PI / 2),
  easeOutSine: t => Math.sin(t * Math.PI / 2),
  easeInOutSine: t => -(Math.cos(Math.PI * t) - 1) / 2,
  // Back (overshoot)
  easeOutBack: t => {
    const c1 = 1.70158,
      c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  },
  easeInBack: t => {
    const c1 = 1.70158,
      c3 = c1 + 1;
    return c3 * t * t * t - c1 * t * t;
  },
  easeInOutBack: t => {
    const c1 = 1.70158,
      c2 = c1 * 1.525;
    return t < 0.5 ? Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2) / 2 : (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
  },
  // Elastic
  easeOutElastic: t => {
    const c4 = 2 * Math.PI / 3;
    if (t === 0) return 0;
    if (t === 1) return 1;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
  }
};

// ── Core interpolation helpers ──────────────────────────────────────────────

// Clamp a value to [min, max]
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

// interpolate([0, 0.5, 1], [0, 100, 50], ease?) -> fn(t)
// Popmotion-style: linearly maps t across input keyframes to output values,
// with optional easing per segment (single fn or array of fns).
function interpolate(input, output, ease = Easing.linear) {
  return t => {
    if (t <= input[0]) return output[0];
    if (t >= input[input.length - 1]) return output[output.length - 1];
    for (let i = 0; i < input.length - 1; i++) {
      if (t >= input[i] && t <= input[i + 1]) {
        const span = input[i + 1] - input[i];
        const local = span === 0 ? 0 : (t - input[i]) / span;
        const easeFn = Array.isArray(ease) ? ease[i] || Easing.linear : ease;
        const eased = easeFn(local);
        return output[i] + (output[i + 1] - output[i]) * eased;
      }
    }
    return output[output.length - 1];
  };
}

// animate({from, to, start, end, ease})(t) — simpler single-segment tween.
// Returns `from` before `start`, `to` after `end`.
function animate({
  from = 0,
  to = 1,
  start = 0,
  end = 1,
  ease = Easing.easeInOutCubic
}) {
  return t => {
    if (t <= start) return from;
    if (t >= end) return to;
    const local = (t - start) / (end - start);
    return from + (to - from) * ease(local);
  };
}

// ── Timeline context ────────────────────────────────────────────────────────

const TimelineContext = React.createContext({
  time: 0,
  duration: 10,
  playing: false
});
const useTime = () => React.useContext(TimelineContext).time;
const useTimeline = () => React.useContext(TimelineContext);

// ── Sprite ──────────────────────────────────────────────────────────────────
// Renders children only when the playhead is inside [start, end]. Provides
// a sub-context with `localTime` (seconds since start) and `progress` (0..1).
//
//   <Sprite start={2} end={5}>
//     {({ localTime, progress }) => <Thing x={progress * 100} />}
//   </Sprite>
//
// Or as a plain wrapper — children can call useSprite() themselves.

const SpriteContext = React.createContext({
  localTime: 0,
  progress: 0,
  duration: 0
});
const useSprite = () => React.useContext(SpriteContext);
function Sprite({
  start = 0,
  end = Infinity,
  children,
  keepMounted = false
}) {
  const {
    time
  } = useTimeline();
  const visible = time >= start && time <= end;
  if (!visible && !keepMounted) return null;
  const duration = end - start;
  const localTime = Math.max(0, time - start);
  const progress = duration > 0 && isFinite(duration) ? clamp(localTime / duration, 0, 1) : 0;
  const value = {
    localTime,
    progress,
    duration,
    visible
  };
  return /*#__PURE__*/React.createElement(SpriteContext.Provider, {
    value: value
  }, typeof children === 'function' ? children(value) : children);
}

// ── Sample sprite components ────────────────────────────────────────────────

// TextSprite: fades/slides text in on entry, holds, then fades out on exit.
// Props: text, x, y, size, color, font, entryDur, exitDur, align
function TextSprite({
  text,
  x = 0,
  y = 0,
  size = 48,
  color = '#111',
  font = 'Inter, system-ui, sans-serif',
  weight = 600,
  entryDur = 0.45,
  exitDur = 0.35,
  entryEase = Easing.easeOutBack,
  exitEase = Easing.easeInCubic,
  align = 'left',
  letterSpacing = '-0.01em'
}) {
  const {
    localTime,
    duration
  } = useSprite();
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let ty = 0;
  if (localTime < entryDur) {
    const t = entryEase(clamp(localTime / entryDur, 0, 1));
    opacity = t;
    ty = (1 - t) * 16;
  } else if (localTime > exitStart) {
    const t = exitEase(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    ty = -t * 8;
  }
  const translateX = align === 'center' ? '-50%' : align === 'right' ? '-100%' : '0';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      transform: `translate(${translateX}, ${ty}px)`,
      opacity,
      fontFamily: font,
      fontSize: size,
      fontWeight: weight,
      color,
      letterSpacing,
      whiteSpace: 'pre',
      lineHeight: 1.1,
      willChange: 'transform, opacity'
    }
  }, text);
}

// ImageSprite: scales + fades in; optional Ken Burns drift during hold.
function ImageSprite({
  src,
  x = 0,
  y = 0,
  width = 400,
  height = 300,
  entryDur = 0.6,
  exitDur = 0.4,
  kenBurns = false,
  kenBurnsScale = 1.08,
  radius = 12,
  fit = 'cover',
  placeholder = null // {label: string} for striped placeholder
}) {
  const {
    localTime,
    duration
  } = useSprite();
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let scale = 1;
  if (localTime < entryDur) {
    const t = Easing.easeOutCubic(clamp(localTime / entryDur, 0, 1));
    opacity = t;
    scale = 0.96 + 0.04 * t;
  } else if (localTime > exitStart) {
    const t = Easing.easeInCubic(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    scale = (kenBurns ? kenBurnsScale : 1) + 0.02 * t;
  } else if (kenBurns) {
    const holdSpan = exitStart - entryDur;
    const holdT = holdSpan > 0 ? (localTime - entryDur) / holdSpan : 0;
    scale = 1 + (kenBurnsScale - 1) * holdT;
  }
  const content = placeholder ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'repeating-linear-gradient(135deg, #e9e6df 0 10px, #dcd8cf 10px 20px)',
      color: '#6b6458',
      fontFamily: 'JetBrains Mono, ui-monospace, monospace',
      fontSize: 13,
      letterSpacing: '0.04em',
      textTransform: 'uppercase'
    }
  }, placeholder.label || 'image') : /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: fit,
      display: 'block'
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      width,
      height,
      opacity,
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      borderRadius: radius,
      overflow: 'hidden',
      willChange: 'transform, opacity'
    }
  }, content);
}

// RectSprite: simple rectangle that animates position/size/color via props.
// Useful demo primitive — takes a `render` fn for per-frame customization.
function RectSprite({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  color = '#111',
  radius = 8,
  entryDur = 0.4,
  exitDur = 0.3,
  render // optional: (ctx) => style overrides
}) {
  const spriteCtx = useSprite();
  const {
    localTime,
    duration
  } = spriteCtx;
  const exitStart = Math.max(0, duration - exitDur);
  let opacity = 1;
  let scale = 1;
  if (localTime < entryDur) {
    const t = Easing.easeOutBack(clamp(localTime / entryDur, 0, 1));
    opacity = clamp(localTime / entryDur, 0, 1);
    scale = 0.4 + 0.6 * t;
  } else if (localTime > exitStart) {
    const t = Easing.easeInQuad(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - t;
    scale = 1 - 0.15 * t;
  }
  const overrides = render ? render(spriteCtx) : {};
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: x,
      top: y,
      width,
      height,
      background: color,
      borderRadius: radius,
      opacity,
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      willChange: 'transform, opacity',
      ...overrides
    }
  });
}

// ── Font inlining ───────────────────────────────────────────────────────────
// Copy every @font-face rule from the page into a <style> inside the svg's
// foreignObject, with font URLs rewritten to data: URLs. Makes the svg
// self-describing so serializing it alone (video export fast path) still
// renders with the right fonts. Sets data-om-fonts-inlined on the svg when
// done so the exporter can wait for it.

function useInlineFontsInto(svgRef) {
  React.useEffect(() => {
    const svg = svgRef.current;
    const host = svg && svg.querySelector('foreignObject > div');
    if (!svg || !host) return;
    let cancelled = false;
    (async () => {
      const rules = [];
      for (const ss of document.styleSheets) {
        let cssRules;
        try {
          cssRules = ss.cssRules;
        } catch {
          // Cross-origin sheet without crossorigin attr (e.g. the standard
          // fonts.googleapis.com <link>) — fetch the CSS text directly and
          // regex-extract the @font-face blocks.
          if (ss.href) {
            try {
              const txt = await fetch(ss.href).then(r => {
                if (!r.ok) throw 0;
                return r.text();
              });
              for (const ff of txt.match(/@font-face\s*{[^}]*}/g) || []) rules.push({
                css: ff,
                base: ss.href
              });
            } catch {}
          }
          continue;
        }
        if (!cssRules) continue;
        for (const r of cssRules) {
          if (r.type === CSSRule.FONT_FACE_RULE) {
            rules.push({
              css: r.cssText,
              base: ss.href || location.href
            });
          }
        }
      }
      const toDataURL = url => fetch(url).then(r => {
        if (!r.ok) throw 0;
        return r.blob();
      }).then(b => new Promise(res => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.onerror = () => res(url);
        fr.readAsDataURL(b);
      })).catch(() => url);
      const parts = await Promise.all(rules.map(async ({
        css,
        base
      }) => {
        const re = /url\((['"]?)([^'")]+)\1\)/g;
        let out = css,
          m;
        while (m = re.exec(css)) {
          const u = m[2];
          if (u.startsWith('data:')) continue;
          let abs;
          try {
            abs = new URL(u, base).href;
          } catch {
            continue;
          }
          out = out.split(m[0]).join(`url("${await toDataURL(abs)}")`);
        }
        return out;
      }));
      if (cancelled || !parts.length) {
        svg.setAttribute('data-om-fonts-inlined', 'true');
        return;
      }
      const style = document.createElement('style');
      style.textContent = parts.join('\n');
      host.insertBefore(style, host.firstChild);
      svg.setAttribute('data-om-fonts-inlined', 'true');
    })();
    return () => {
      cancelled = true;
    };
  }, []);
}
function Stage({
  width = 1280,
  height = 720,
  duration = 10,
  background = '#f6f4ef',
  fps = 60,
  loop = true,
  autoplay = true,
  persistKey = 'animstage',
  children
}) {
  // Props arrive as strings when Stage is mounted via <x-import> (DC
  // projects) — coerce so style={{width}} gets a number React can px-ify.
  width = +width || 1280;
  height = +height || 720;
  duration = +duration || 10;
  fps = +fps || 60;
  if (typeof loop === 'string') loop = loop !== 'false';
  if (typeof autoplay === 'string') autoplay = autoplay !== 'false';
  const [time, setTime] = React.useState(() => {
    try {
      const v = parseFloat(localStorage.getItem(persistKey + ':t') || '0');
      return isFinite(v) ? clamp(v, 0, duration) : 0;
    } catch {
      return 0;
    }
  });
  const [playing, setPlaying] = React.useState(autoplay);
  const [hoverTime, setHoverTime] = React.useState(null);
  const [scale, setScale] = React.useState(1);
  const stageRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  const rafRef = React.useRef(null);
  const lastTsRef = React.useRef(null);

  // Persist playhead
  React.useEffect(() => {
    try {
      localStorage.setItem(persistKey + ':t', String(time));
    } catch {}
  }, [time, persistKey]);

  // Auto-scale to fit viewport
  React.useEffect(() => {
    if (!stageRef.current) return;
    const el = stageRef.current;
    const measure = () => {
      const barH = 44; // playback bar height
      const s = Math.min(el.clientWidth / width, (el.clientHeight - barH) / height);
      setScale(Math.max(0.05, s));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [width, height]);

  // Animation loop
  React.useEffect(() => {
    if (!playing) {
      lastTsRef.current = null;
      return;
    }
    const step = ts => {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;
      setTime(t => {
        let next = t + dt;
        if (next >= duration) {
          if (loop) next = next % duration;else {
            next = duration;
            setPlaying(false);
          }
        }
        return next;
      });
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
    };
  }, [playing, duration, loop]);

  // Keyboard: space = play/pause, ← → = seek
  React.useEffect(() => {
    const onKey = e => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setPlaying(p => !p);
      } else if (e.code === 'ArrowLeft') {
        setTime(t => clamp(t - (e.shiftKey ? 1 : 0.1), 0, duration));
      } else if (e.code === 'ArrowRight') {
        setTime(t => clamp(t + (e.shiftKey ? 1 : 0.1), 0, duration));
      } else if (e.key === '0' || e.code === 'Home') {
        setTime(0);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [duration]);

  // Video-export protocol: the exporter dispatches this event per frame;
  // pause + sync the playhead so the capture sees exactly that timestamp.
  React.useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const onSeek = e => {
      setPlaying(false);
      setTime(clamp(e.detail.time, 0, duration));
    };
    el.addEventListener('data-om-seek-to-time-frame', onSeek);
    return () => el.removeEventListener('data-om-seek-to-time-frame', onSeek);
  }, [duration]);

  // Inline @font-face rules into the svg's foreignObject so the svg is
  // self-describing — serializing it alone (for video export) then renders
  // with the right fonts. Sets data-om-fonts-inlined once done.
  useInlineFontsInto(canvasRef);
  const displayTime = hoverTime != null ? hoverTime : time;
  const ctxValue = React.useMemo(() => ({
    time: displayTime,
    duration,
    playing,
    setTime,
    setPlaying
  }), [displayTime, duration, playing]);
  return /*#__PURE__*/React.createElement("div", {
    ref: stageRef,
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      background: '#0a0a0a',
      fontFamily: 'Inter, system-ui, sans-serif'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    ref: canvasRef,
    width: width,
    height: height,
    "data-om-exportable-video-with-duration-secs": duration,
    style: {
      transform: `scale(${scale})`,
      transformOrigin: 'center',
      flexShrink: 0,
      boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("foreignObject", {
    x: "0",
    y: "0",
    width: "100%",
    height: "100%"
  }, /*#__PURE__*/React.createElement("div", {
    xmlns: "http://www.w3.org/1999/xhtml",
    style: {
      width,
      height,
      background,
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(TimelineContext.Provider, {
    value: ctxValue
  }, children))))), /*#__PURE__*/React.createElement(PlaybackBar, {
    time: displayTime,
    actualTime: time,
    duration: duration,
    playing: playing,
    onPlayPause: () => setPlaying(p => !p),
    onReset: () => {
      setTime(0);
    },
    onSeek: t => setTime(t),
    onHover: t => setHoverTime(t)
  }));
}

// ── Playback bar ────────────────────────────────────────────────────────────
// Play/pause, return-to-begin, scrub track, time display.
// Uses fixed-width time fields so layout doesn't thrash.

function PlaybackBar({
  time,
  duration,
  playing,
  onPlayPause,
  onReset,
  onSeek,
  onHover
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  const timeFromEvent = React.useCallback(e => {
    const rect = trackRef.current.getBoundingClientRect();
    const x = clamp((e.clientX - rect.left) / rect.width, 0, 1);
    return x * duration;
  }, [duration]);
  const onTrackMove = e => {
    if (!trackRef.current) return;
    const t = timeFromEvent(e);
    if (dragging) {
      onSeek(t);
    } else {
      onHover(t);
    }
  };
  const onTrackLeave = () => {
    if (!dragging) onHover(null);
  };
  const onTrackDown = e => {
    setDragging(true);
    const t = timeFromEvent(e);
    onSeek(t);
    onHover(null);
  };
  React.useEffect(() => {
    if (!dragging) return;
    const onUp = () => setDragging(false);
    const onMove = e => {
      if (!trackRef.current) return;
      const t = timeFromEvent(e);
      onSeek(t);
    };
    window.addEventListener('mouseup', onUp);
    window.addEventListener('mousemove', onMove);
    return () => {
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('mousemove', onMove);
    };
  }, [dragging, timeFromEvent, onSeek]);
  const pct = duration > 0 ? time / duration * 100 : 0;
  const fmt = t => {
    const total = Math.max(0, t);
    const m = Math.floor(total / 60);
    const s = Math.floor(total % 60);
    const cs = Math.floor(total * 100 % 100);
    return `${String(m).padStart(1, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
  };
  const mono = 'JetBrains Mono, ui-monospace, SFMono-Regular, monospace';
  return /*#__PURE__*/React.createElement("div", {
    "data-omelette-chrome": true,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '8px 16px',
      background: 'rgba(20,20,20,0.92)',
      borderTop: '1px solid rgba(255,255,255,0.08)',
      width: '100%',
      maxWidth: 680,
      alignSelf: 'center',
      borderRadius: 8,
      color: '#f6f4ef',
      fontFamily: 'Inter, system-ui, sans-serif',
      userSelect: 'none',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    onClick: onReset,
    title: "Return to start (0)"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 2v10M12 2L5 7l7 5V2z",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }))), /*#__PURE__*/React.createElement(IconButton, {
    onClick: onPlayPause,
    title: "Play/pause (space)"
  }, playing ? /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "2",
    width: "3",
    height: "10",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "8",
    y: "2",
    width: "3",
    height: "10",
    fill: "currentColor"
  })) : /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 2l9 5-9 5V2z",
    fill: "currentColor"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      width: 64,
      textAlign: 'right',
      color: '#f6f4ef'
    }
  }, fmt(time)), /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    onMouseMove: onTrackMove,
    onMouseLeave: onTrackLeave,
    onMouseDown: onTrackDown,
    style: {
      flex: 1,
      height: 22,
      position: 'relative',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      height: 4,
      background: 'rgba(255,255,255,0.12)',
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      width: `${pct}%`,
      height: 4,
      background: 'oklch(72% 0.12 250)',
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${pct}%`,
      top: '50%',
      width: 12,
      height: 12,
      marginLeft: -6,
      marginTop: -6,
      background: '#fff',
      borderRadius: 6,
      boxShadow: '0 2px 4px rgba(0,0,0,0.4)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: mono,
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      width: 64,
      textAlign: 'left',
      color: 'rgba(246,244,239,0.55)'
    }
  }, fmt(duration)), typeof VideoEncoder !== 'undefined' && /*#__PURE__*/React.createElement(IconButton, {
    title: "Export video",
    onClick: () => window.parent.postMessage({
      type: 'omelette:request-video-export'
    }, '*')
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 2v7m0 0L4 6m3 3l3-3M2 12h10",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))));
}
function IconButton({
  children,
  onClick,
  title
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    title: title,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 28,
      height: 28,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: hover ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.04)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: 6,
      color: '#f6f4ef',
      cursor: 'pointer',
      padding: 0,
      transition: 'background 120ms'
    }
  }, children);
}

// ── VideoSprite ─────────────────────────────────────────────────────────────
// Renders a <video> that loops within [start,end] of its source at `speed`,
// kept in sync with the Stage's playhead. Carries the
// data-om-exportable-video-play-* attrs so video export can mix its audio.
//
//   <VideoSprite src="clip.mp4" start={2} end={5} speed={1}
//     style={{ width: 640, height: 360 }} />

function VideoSprite({
  src,
  start = 0,
  end,
  speed = 1,
  style,
  ...rest
}) {
  start = +start || 0;
  speed = +speed || 1;
  if (end != null) end = +end || undefined;
  const t = useTime();
  const ref = React.useRef(null);
  const span = Math.max(0.001, (end ?? start + 1) - start);
  React.useEffect(() => {
    const v = ref.current;
    if (!v || v.readyState < 1) return;
    const target = start + t * speed % span;
    if (Math.abs(v.currentTime - target) > 0.05) v.currentTime = target;
  }, [t, start, span, speed]);
  return /*#__PURE__*/React.createElement("video", _extends({
    ref: ref,
    src: src,
    muted: true,
    playsInline: true,
    preload: "auto",
    "data-om-exportable-video-play-start": start,
    "data-om-exportable-video-play-end": end ?? start + span,
    "data-om-exportable-video-play-speed": speed,
    style: {
      display: 'block',
      objectFit: 'cover',
      ...style
    }
  }, rest));
}
Object.assign(window, {
  Easing,
  interpolate,
  animate,
  clamp,
  TimelineContext,
  useTime,
  useTimeline,
  Sprite,
  SpriteContext,
  useSprite,
  TextSprite,
  ImageSprite,
  RectSprite,
  VideoSprite,
  Stage,
  PlaybackBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/UI review and feedback/animations.jsx", error: String((e && e.message) || e) }); }

// uploads/UI review and feedback/reflow-studies.jsx
try { (() => {
// Reflow motion studies — three treatments of spread → single column
// Uses globals from animations.jsx: Stage, Sprite, useTime, useSprite, Easing, interpolate, clamp
(function () {
  const {
    Stage,
    Sprite,
    useSprite,
    Easing,
    interpolate,
    clamp
  } = window;
  const R = React;
  const h = R.createElement;

  // ---------- shared mini-page pieces (wireframe fills) ----------
  const CREAM = '#F5EFE1',
    CREAM2 = '#F8F2E5',
    INK = '#2b2926',
    DESK = '#6e6764';
  const hatch = (a, b, s) => `repeating-linear-gradient(45deg,${a},${a} ${s}px,${b} ${s}px,${b} ${s * 2}px)`;
  function Tabs({
    h: hh
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: 0,
        top: hh * 0.06,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, ['#7a5343', '#8d6a5a', '#8d6a5a', '#8d6a5a'].map((c, i) => h('div', {
      key: i,
      style: {
        width: i === 0 ? 9 : 7,
        height: hh * 0.11,
        background: c,
        borderRadius: '0 3px 3px 0'
      }
    })));
  }
  function ImgBlock({
    w,
    hh
  }) {
    return h('div', {
      style: {
        width: w,
        height: hh,
        border: `1.5px solid ${INK}`,
        background: hatch('#e5ddc9', '#ede6d4', 8),
        boxSizing: 'border-box'
      }
    });
  }
  function Sliders({
    w,
    n
  }) {
    return h('div', {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 9,
        width: w
      }
    }, Array.from({
      length: n
    }, (_, i) => h('div', {
      key: i,
      style: {
        height: 6,
        borderRadius: 99,
        background: '#ddd5c2',
        position: 'relative'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: `${25 + i * 18}%`,
        top: -3,
        width: 12,
        height: 12,
        borderRadius: '50%',
        background: '#fcf8ee',
        border: '1px solid rgba(43,41,38,.45)'
      }
    }))));
  }
  function Histo({
    w,
    hh
  }) {
    const bars = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#696955', '#9e5738', '#2f5b6e'];
    return h('div', {
      style: {
        width: w,
        height: hh,
        display: 'flex',
        alignItems: 'flex-end',
        gap: 2,
        borderBottom: `1.5px solid ${INK}`,
        boxSizing: 'border-box'
      }
    }, bars.map((c, i) => h('div', {
      key: i,
      style: {
        flex: 1,
        height: `${100 - i * 12}%`,
        background: c
      }
    })));
  }
  function Polar({
    d
  }) {
    return h('div', {
      style: {
        width: d,
        height: d,
        position: 'relative'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        inset: d * 0.06,
        borderRadius: '50%',
        border: `1.5px solid ${INK}`
      }
    }), h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: '50%',
        height: 1,
        background: 'rgba(43,41,38,.5)'
      }
    }), h('div', {
      style: {
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: '50%',
        width: 1,
        background: 'rgba(43,41,38,.5)'
      }
    }), [['56%', '18%', '#6e3a1f', 0.09], ['48%', '40%', '#cfc4ae', 0.08], ['54%', '58%', '#3a4034', 0.1], ['40%', '64%', '#2f5b6e', 0.05]].map((p, i) => h('div', {
      key: i,
      style: {
        position: 'absolute',
        left: p[0],
        top: p[1],
        width: d * p[3],
        height: d * p[3],
        borderRadius: '50%',
        background: p[2]
      }
    })));
  }
  function Ledger({
    w
  }) {
    const rows = ['#3c3f38', '#1c1a17', '#898575', '#d2c5af', '#603425', '#9e5738'];
    return h('div', {
      style: {
        width: w,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '4px 14px'
      }
    }, rows.map((c, i) => h('div', {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5
      }
    }, h('div', {
      style: {
        width: 16,
        height: 9,
        background: c,
        borderRadius: 2
      }
    }), h('div', {
      style: {
        flex: 1,
        height: 4,
        background: 'rgba(43,41,38,.25)',
        borderRadius: 99
      }
    }))));
  }

  // Left page content (fixed across all treatments)
  function LeftPageContent({
    pw,
    ph
  }) {
    return h('div', {
      style: {
        padding: `${ph * 0.055}px ${pw * 0.08}px`,
        paddingLeft: pw * 0.14,
        position: 'relative',
        height: '100%',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: ph * 0.05
      }
    }, h(Tabs, {
      h: ph
    }), h('div', {
      style: {
        width: '46%',
        height: 10,
        background: 'rgba(43,41,38,.55)',
        borderRadius: 2
      }
    }), h(ImgBlock, {
      w: '100%',
      hh: ph * 0.34
    }), h(Sliders, {
      w: '92%',
      n: 4
    }));
  }

  // Right page figures — rendered via a layout map so treatments can animate positions
  function RightFigures({
    pw,
    ph
  }) {
    return h('div', {
      style: {
        padding: `${ph * 0.055}px ${pw * 0.08}px`,
        height: '100%',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
        gap: ph * 0.055
      }
    }, h(Histo, {
      w: '100%',
      hh: ph * 0.24
    }), h('div', {
      style: {
        display: 'flex',
        gap: pw * 0.07,
        alignItems: 'flex-start'
      }
    }, h(Polar, {
      d: ph * 0.3
    }), h('div', {
      style: {
        flex: 1,
        height: ph * 0.3,
        borderLeft: `1.5px solid ${INK}`,
        borderBottom: `1.5px solid ${INK}`
      }
    })), h(Ledger, {
      w: '100%'
    }));
  }

  // window chrome that narrows over time
  function Win({
    w,
    hh,
    children,
    label
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%,-50%)',
        width: w,
        height: hh,
        background: DESK,
        borderRadius: 10,
        boxShadow: '0 18px 50px rgba(0,0,0,.45)',
        overflow: 'hidden'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        height: 26,
        background: '#3a3735',
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '0 12px'
      }
    }, ['#e0564f', '#e0a03c', '#57a45b'].map((c, i) => h('div', {
      key: i,
      style: {
        width: 9,
        height: 9,
        borderRadius: '50%',
        background: c
      }
    })), h('div', {
      style: {
        marginLeft: 'auto',
        font: '11px Fira Code, monospace',
        color: 'rgba(255,255,255,.55)'
      }
    }, label)), h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 26,
        bottom: 0
      }
    }, children));
  }

  // ============================================================
  // Treatment A — CROSSFADE + RE-STACK (recommended)
  // Right page fades, figures slide into the column, spine fades.
  // ============================================================
  function SceneA({
    t0
  }) {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    // window width narrows 0→2s, holds, widens 5.5→7.5s
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const compact = winW < 980;
    // reflow progress: 0 = spread, 1 = single column (with hysteresis feel)
    const p = interpolate([1.35, 1.95, 5.75, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const rightOpacity = 1 - clamp(p * 2.2, 0, 1); // right page fades early
    const figuresIn = clamp((p - 0.35) / 0.6, 0, 1); // figures slide in after
    const spineOp = 1 - clamp(p * 3, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px ${compact ? '· compact' : ''}`
    },
    // left page — grows into the single column
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)'
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }),
    // figures re-stacking into the column below the sliders
    h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    })))),
    // scroll hint in compact
    figuresIn > 0.9 && h('div', {
      style: {
        position: 'absolute',
        right: 5,
        top: 8,
        bottom: 8,
        width: 4,
        borderRadius: 99,
        background: 'rgba(43,41,38,.12)'
      }
    }, h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: '4%',
        height: '34%',
        borderRadius: 99,
        background: 'rgba(122,83,67,.55)'
      }
    }))),
    // spine
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: 'translateX(-50%)',
        width: 10,
        height: H - 60,
        background: 'linear-gradient(90deg,rgba(0,0,0,.08),rgba(0,0,0,.28),rgba(0,0,0,.08))',
        opacity: spineOp
      }
    }),
    // right page — fades + drifts left
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${p * -30}px)`,
        width: winW / 2 - 60,
        height: H - 60,
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)',
        opacity: rightOpacity,
        pointerEvents: 'none'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })));
  }

  // ============================================================
  // Treatment B — PAGE FOLD (the heavy one, for comparison)
  // Right page rotates behind the left on a perspective hinge.
  // ============================================================
  function SceneB() {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.85, 5.85, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const foldDeg = p * -168;
    const figuresIn = clamp((p - 0.55) / 0.45, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px · fold`
    }, h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)'
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }), h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    }))))),
    // folding right page, hinged at the spine
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        width: winW / 2 - 60,
        height: H - 60,
        perspective: 900,
        transformStyle: 'preserve-3d',
        pointerEvents: 'none'
      }
    }, h('div', {
      style: {
        width: '100%',
        height: '100%',
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: `${8 + p * 20}px 0 ${16 + p * 24}px rgba(0,0,0,${0.25 + p * 0.2})`,
        transform: `rotateY(${foldDeg}deg)`,
        transformOrigin: 'left center',
        backfaceVisibility: 'hidden'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })),
    // back face (paper back)
    h('div', {
      style: {
        position: 'absolute',
        inset: 0,
        background: '#e8e1ce',
        border: `1px solid ${INK}`,
        transform: `rotateY(${foldDeg + 180}deg)`,
        transformOrigin: 'left center',
        backfaceVisibility: 'hidden'
      }
    })));
  }

  // ============================================================
  // Treatment C — SLIDE UNDER (right page slips beneath the left, like sliding a sheet under the top one)
  // ============================================================
  function SceneC() {
    const {
      localTime
    } = useSprite();
    const t = localTime;
    const winW = interpolate([0.4, 2.0, 5.6, 7.2], [1180, 780, 780, 1180], Easing.easeInOutCubic)(t);
    const p = interpolate([1.35, 1.9, 5.8, 6.35], [0, 1, 1, 0], Easing.easeInOutCubic)(t);
    const H = 560;
    const pageW = interpolate([0, 1], [winW / 2 - 60, Math.min(winW - 160, 560)])(p);
    const slideX = p * -(winW / 2 - 40);
    const figuresIn = clamp((p - 0.5) / 0.5, 0, 1);
    return h(Win, {
      w: winW,
      hh: H + 26,
      label: `${Math.round(winW)}px · slide-under`
    },
    // right page slides under: z-order below left, translates left + dims slightly
    h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18 + p * 8,
        transform: `translateX(${slideX}px) scale(${1 - p * 0.06})`,
        width: winW / 2 - 60,
        height: H - 60,
        background: CREAM2,
        border: `1px solid ${INK}`,
        boxShadow: '0 4px 12px rgba(0,0,0,.3)',
        opacity: 1 - p * 0.55,
        zIndex: 1,
        pointerEvents: 'none'
      }
    }, h(RightFigures, {
      pw: winW / 2 - 60,
      ph: H - 60
    })), h('div', {
      style: {
        position: 'absolute',
        left: '50%',
        top: 18,
        transform: `translateX(${-pageW * (1 - p * 0.5)}px)`,
        width: pageW,
        height: H - 60,
        background: CREAM,
        border: `1px solid ${INK}`,
        boxShadow: `${p * 10}px 6px ${14 + p * 10}px rgba(0,0,0,.32)`,
        zIndex: 2
      }
    }, h(LeftPageContent, {
      pw: pageW,
      ph: (H - 60) * (1 - p * 0.42)
    }), h('div', {
      style: {
        position: 'absolute',
        left: '8%',
        right: '8%',
        bottom: 14,
        height: (H - 60) * 0.34,
        opacity: figuresIn,
        transform: `translateY(${(1 - figuresIn) * 40}px)`,
        display: figuresIn > 0.01 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: 10
      }
    }, h(Histo, {
      w: '100%',
      hh: (H - 60) * 0.16
    }), h('div', {
      style: {
        display: 'flex',
        gap: 16
      }
    }, h(Polar, {
      d: (H - 60) * 0.14
    }), h('div', {
      style: {
        flex: 1
      }
    }, h(Ledger, {
      w: '100%'
    }))))));
  }
  function Caption({
    text,
    sub
  }) {
    return h('div', {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 34,
        textAlign: 'center'
      }
    }, h('div', {
      style: {
        font: '600 30px Fira Code, monospace',
        color: '#f3ece0'
      }
    }, text), h('div', {
      style: {
        font: '17px Fira Sans, sans-serif',
        color: 'rgba(243,236,224,.65)',
        marginTop: 6
      }
    }, sub));
  }
  function ReflowStudies() {
    const DUR = 24;
    return h(Stage, {
      width: 1440,
      height: 810,
      duration: DUR,
      background: '#4a4340',
      loop: true
    },
    // A
    h(Sprite, {
      start: 0,
      end: 8
    }, h(SceneA, null), h(Caption, {
      text: 'A · crossfade + re-stack',
      sub: 'right page fades ~120ms → figures slide into the column · cheap, interruptible — recommended for live resize'
    })),
    // B
    h(Sprite, {
      start: 8,
      end: 16
    }, h(SceneB, null), h(Caption, {
      text: 'B · page fold',
      sub: 'right page folds behind on a spine hinge · charming but heavy — better saved for deliberate page turns'
    })),
    // C
    h(Sprite, {
      start: 16,
      end: 24
    }, h(SceneC, null), h(Caption, {
      text: 'C · slide under',
      sub: 'right sheet slips beneath the left, column grows over it · middle ground, keeps paper physicality'
    })));
  }
  window.ReflowStudies = ReflowStudies;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/UI review and feedback/reflow-studies.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BracketSelector = __ds_scope.BracketSelector;

__ds_ns.PaperCheckbox = __ds_scope.PaperCheckbox;

__ds_ns.PaperSlider = __ds_scope.PaperSlider;

__ds_ns.StampButton = __ds_scope.StampButton;

__ds_ns.BucketTile = __ds_scope.BucketTile;

__ds_ns.BucketStrip = __ds_scope.BucketStrip;

__ds_ns.Figure = __ds_scope.Figure;

__ds_ns.LedgerRow = __ds_scope.LedgerRow;

__ds_ns.PaletteLedger = __ds_scope.PaletteLedger;

__ds_ns.Scrubber = __ds_scope.Scrubber;

__ds_ns.EdgeTabs = __ds_scope.EdgeTabs;

__ds_ns.FoldedCorner = __ds_scope.FoldedCorner;

__ds_ns.Spine = __ds_scope.Spine;

__ds_ns.ZoomOverlay = __ds_scope.ZoomOverlay;

__ds_ns.ErrorSlip = __ds_scope.ErrorSlip;

__ds_ns.PinnedCard = __ds_scope.PinnedCard;

__ds_ns.PinHole = __ds_scope.PinHole;

__ds_ns.TapedPhoto = __ds_scope.TapedPhoto;

})();
