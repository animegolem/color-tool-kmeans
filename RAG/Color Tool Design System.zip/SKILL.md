---
name: color-tool-design
description: Use this skill to generate well-branded interfaces and assets for Color Tool (perceptual color & tonality analysis app for artists) in its notebook redesign idiom, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key facts — the notebook idiom: the app is a two-page paper spread (#F5EFE1 / #F8F2E5) on a dark desk (#6E6764); ink #2B2926/#262626 draws everything (hierarchy = ink alphas, no grays, no cards in the flat ground); nav = vertical edge tabs (#7A5343 active / #8D6A5A resting); Fira Code mono is the structural voice (numbered lowercase figure titles "01 · cluster histogram", bracket selectors "[frequency] hue lightness", ledger rows "[60:63:56] · 594 px · 2.35%"), Fira Sans for sentences; photos are taped, figures optionally pinned on white cards, errors are paper slips, big actions are rubber stamps, pages turn via a folded corner. No logo — set "Color Tool" in type. Source of truth: design-docs/UI Shell Wireframes.dc.html + Code Change Notes.md.
